"""Spider tick — orchestrates one pass of the tending loop:
   scan blockers → snapshot subgraph → classify with the head →
   stage suggestions when the prediction is a singleton at the
   review-ready threshold.

v1.1 scope: pair repair only. AddLink and MergeEntities are stageable
(they have HITL schema in mutations.py and a SUGGESTED_<TYPE> edge
contract); AddReflection / AdjustWeight / Deprecate predictions are
recorded but treated as escalations — their staged variants are
research lineage, not v1.1. Multi-element prediction sets are skipped
(they're abstain-shaped — by design).

A "review-ready singleton" stages a SUGGESTED_<TYPE> edge and a
(:Edit {status:'Staged'}) row. The canonical graph is *not* mutated
automatically — a reviewer must accept (`a`) for the canonical edge
to land. The phrase "auto-apply" is reserved for an explicit
autonomous mode that v1.1 does not ship.

The spider is loaded once per process; tick() is driven from cli.py:tend.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass

from .audit_log import StagedEdit, emit_staged, new_edit_id
from .blocking import all_blockers
from .mutations import AddLink, MergeEntities, to_cypher, to_promote_cypher, to_reject_cypher
from .probes import ProbeRow, new_probe_id, record_probe

log = logging.getLogger("orbweaver.spider")


# ---------- subgraph snapshot ----------


def subgraph_snapshot(driver_or_session, ids: list[str], *, depth: int = 1) -> str:
    """Render a 1-hop subgraph around `ids` as the CREATE-style Cypher the
    spider's classifier head was trained to read. Includes all nodes
    within `depth` hops of any seed id, plus all edges among them.
    Excludes orbweaver's own audit/ledger nodes (:Edit, :MutationLedgerEntry).

    Output is the same shape as `graph_snapshot_cypher` in data/v1.5/*.jsonl.
    """
    sess = _coerce_session(driver_or_session)

    q = (
        "UNWIND $ids AS sid MATCH (s {id:sid}) "
        f"OPTIONAL MATCH (s)-[*0..{int(depth)}]-(n) "
        "WHERE NOT n:Edit AND NOT n:MutationLedgerEntry "
        "  AND coalesce(n.deprecated, false) = false "
        "WITH collect(DISTINCT s) + collect(DISTINCT n) AS all_nodes "
        "UNWIND all_nodes AS x "
        "WITH collect(DISTINCT x) AS nodes "
        "OPTIONAL MATCH (a)-[r]->(b) "
        "WHERE a IN nodes AND b IN nodes "
        "  AND coalesce(r.deprecated, false) = false "
        "  AND NOT type(r) STARTS WITH 'SUGGESTED_' "
        "RETURN nodes, collect(DISTINCT [a.id, type(r), b.id, properties(r)]) AS rels"
    )
    with sess as s:
        row = s.run(q, ids=list(ids)).single()
    if row is None or not row["nodes"]:
        return ""

    lines: list[str] = []
    var_for: dict[str, str] = {}
    # Render nodes first.
    for i, node in enumerate(row["nodes"]):
        if node is None:
            continue
        var = f"n{i}"
        node_id = node.get("id")
        if not node_id:
            continue
        var_for[node_id] = var
        labels = ":".join(sorted(node.labels)) or "Entity"
        props = _render_props(dict(node))
        lines.append(f"CREATE ({var}:{labels} {props});")

    # Render rels — only between nodes we already CREATE'd.
    for triple in row["rels"]:
        if not triple or triple[0] is None or triple[1] is None or triple[2] is None:
            continue
        a_id, rel_type, b_id, rel_props = triple
        if a_id not in var_for or b_id not in var_for:
            continue
        if not rel_type or not rel_type.replace("_", "").isalnum():
            continue
        props = _render_props(dict(rel_props))
        lines.append(f"CREATE ({var_for[a_id]})-[:{rel_type} {props}]->({var_for[b_id]});")

    return "\n".join(lines)


def _render_props(d: dict) -> str:
    """Cypher map literal — only safe types, ids and names quoted, others
    coerced to strings. Drops orbweaver bookkeeping fields."""
    skip = {"deprecated", "deprecated_reason", "deprecated_at", "deprecated_by",
            "tick_id", "scenario_id", "from_edit_id", "edit_id"}
    parts: list[str] = []
    for k, v in d.items():
        if k in skip or v is None:
            continue
        if isinstance(v, bool):
            parts.append(f"{k}: {str(v).lower()}")
        elif isinstance(v, (int, float)):
            parts.append(f"{k}: {v}")
        elif isinstance(v, str):
            parts.append(f"{k}: {json.dumps(v)}")
        elif isinstance(v, list):
            parts.append(f"{k}: {json.dumps(v)}")
        else:
            parts.append(f"{k}: {json.dumps(str(v))}")
    return "{" + ", ".join(parts) + "}"


# ---------- tick ----------


@dataclass
class TickResult:
    candidates_seen: int = 0
    staged: int = 0
    skipped_abstain: int = 0
    skipped_unsupported_verb: int = 0
    edit_ids: list[str] = None  # filled if staged>0

    def __post_init__(self):
        if self.edit_ids is None:
            self.edit_ids = []


def tick(driver, spider, *, max_candidates: int = 50, max_stage: int = 20,
         applied_by: str = "orbweaver", record_probes: bool = True) -> TickResult:
    """One tending pass. Pulls candidates from blockers, classifies each
    via the spider, stages a suggestion when the prediction set is a
    singleton in {add_link, merge_entities}.

    `spider` is the loader.Spider returned by `dist/.../loader.load_spider()`.

    `record_probes`: when True (default), write a (:Probe) row for every
    scored candidate regardless of staging outcome. This is the ECHO-inspired
    weak-supervision substrate — see orbweaver/probes.py. Set False for
    benchmark loops that bypass the audit layer.
    """
    from importlib import import_module
    loader = import_module("dist.orbweaver-qwen3-4b-spider-v0.1.loader") \
        if False else _load_loader_safely()
    predict_set = loader.predict_set

    result = TickResult()
    tick_id = new_edit_id() if record_probes else ""

    for cp in all_blockers(driver, limit_per_blocker=max_candidates // 2):
        result.candidates_seen += 1
        if result.staged >= max_stage:
            break

        snapshot = subgraph_snapshot(driver, [cp.left_id, cp.right_id])
        if not snapshot:
            continue
        events = [{
            "type": "candidate_pair_review",
            "left_id": cp.left_id, "right_id": cp.right_id,
            "blocker": cp.blocker,
            "signals": cp.signals,
        }]
        scenario = {"graph_snapshot_cypher": snapshot,
                    "events_since_last_tick": events}

        try:
            pset = predict_set(spider, scenario)
        except Exception as e:
            log.warning("classify failed for %s/%s: %s", cp.left_id, cp.right_id, e)
            continue

        # pset is [(verb, prob), ...] in descending probability order
        top_verb, top_prob = (pset[0] if pset else ("abstain", 0.0))
        if len(pset) != 1:
            spider_action = "abstained"
        elif top_verb == "abstain":
            spider_action = "abstained"
        elif top_verb not in ("add_link", "merge_entities"):
            spider_action = "unsupported_verb"
        else:
            spider_action = "staged"

        signals_json = json.dumps(cp.signals, separators=(",", ":"))
        prediction_set_json = json.dumps(
            [{"verb": v, "prob": float(p)} for v, p in pset],
            separators=(",", ":"),
        )
        events_json_str = json.dumps(events, separators=(",", ":"))

        # ECHO-inspired: every scored candidate becomes a (:Probe) row, so
        # downstream graph evolution can weak-label what the reviewer never
        # saw. Best-effort — a probe-write failure must not break the tick.
        if record_probes:
            try:
                record_probe(driver, ProbeRow(
                    probe_id=new_probe_id(),
                    left_id=cp.left_id, right_id=cp.right_id,
                    blocker=cp.blocker, signals_json=signals_json,
                    prediction_set_json=prediction_set_json,
                    top_verb=top_verb, top_prob=float(top_prob),
                    graph_snapshot_cypher=snapshot,
                    events_json=events_json_str,
                    spider_action=spider_action,
                    tick_id=tick_id,
                ))
            except Exception as e:
                log.warning("probe write failed for %s/%s: %s", cp.left_id, cp.right_id, e)

        if spider_action == "abstained":
            result.skipped_abstain += 1
            continue
        if spider_action == "unsupported_verb":
            result.skipped_unsupported_verb += 1
            continue

        verb, prob = top_verb, top_prob
        edit_id = new_edit_id()

        if verb == "add_link":
            # Default rel_type when the model only outputs the verb: KNOWS
            # is a safe POLE+O default. v1.x: add a slot extractor or use
            # a verb-conditional rule layer to pick from {KNOWS, WORKS_WITH,
            # MENTIONS, etc.} based on node labels.
            m = AddLink(from_id=cp.left_id, to_id=cp.right_id,
                        rel_type="KNOWS", weight=float(prob),
                        rationale=f"blocker={cp.blocker}")
        else:
            m = MergeEntities(dup_id=cp.left_id, canonical_id=cp.right_id,
                              confidence=float(prob),
                              rationale=f"blocker={cp.blocker}")

        staged_cy, staged_params = to_cypher(
            m, tick_id=edit_id, applied_by=applied_by,
            staged=True, edit_id=edit_id, signals_json=signals_json,
        )
        promote_cy, promote_params = to_promote_cypher(
            m, edit_id=edit_id, applied_by=applied_by,
        )
        reject_cy, reject_params = to_reject_cypher(m, edit_id=edit_id)

        edit = StagedEdit(
            edit_id=edit_id, verb=m.verb,
            staged_cypher=staged_cy, staged_params=staged_params,
            promote_cypher=promote_cy, promote_params=promote_params,
            reject_cypher=reject_cy, reject_params=reject_params,
            confidence=float(prob),
            target_id=_target_id(m),
            rationale=m.rationale, signals_json=signals_json,
            graph_snapshot_cypher=snapshot,
            events_json=events_json_str,
            prediction_set_json=prediction_set_json,
            mutation_json=json.dumps(m.model_dump(), separators=(",", ":")),
        )
        try:
            emitted_id = emit_staged(driver, edit)
            if emitted_id == edit_id:
                result.staged += 1
                result.edit_ids.append(edit_id)
        except Exception as e:
            log.warning("emit_staged failed for %s: %s", edit_id, e)
            continue

    return result


def _target_id(m) -> str:
    if isinstance(m, AddLink):
        return f"{m.from_id}|{m.rel_type}|{m.to_id}"
    if isinstance(m, MergeEntities):
        return f"{m.dup_id}|SAME_AS|{m.canonical_id}"
    return ""


def _load_loader_safely():
    """Import dist/orbweaver-qwen3-4b-spider-v0.1/loader.py — the path
    contains a hyphen which makes it not a valid Python module name, so
    we go via importlib + spec loading. If the loader is already imported
    (cli.py:tend pre-loads it), reuse the existing module."""
    import sys
    if "orbweaver_loader" in sys.modules:
        return sys.modules["orbweaver_loader"]
    import importlib.util
    from pathlib import Path
    here = Path(__file__).resolve().parent.parent
    loader_path = here / "dist" / "orbweaver-qwen3-4b-spider-v0.1" / "loader.py"
    spec = importlib.util.spec_from_file_location("orbweaver_loader", loader_path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["orbweaver_loader"] = mod
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


def _coerce_session(x):
    if hasattr(x, "session"):
        return x.session()
    return x
