"""Typer CLI.

Three primary commands carry the v1.1 product story:

    orbweaver tend --once                   # scan, classify, stage suggestions
    orbweaver review                        # open the keyboard reviewer
    orbweaver demo                          # F1-delta sanity (no Neo4j tend, no model)

Everything else is research / advanced and only reachable via --help:

    orbweaver eval                          # [legacy] autoregressive eval — see docs/RESEARCH.md
    orbweaver train                         # invoke train.py
    orbweaver teacher-smoke                 # one Anthropic call to validate teacher prompt
    orbweaver build-dataset                 # teacher-distill a fresh training set
    orbweaver task-list / ingest-staged     # agent-teacher path
    orbweaver inspect-scenario <id>         # load one scenario into Neo4j for Bloom
    orbweaver load-pilot                    # load every scenario from a dataset version

We also route `python -m orbweaver.cli` here.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import typer
from rich import print as rprint

app = typer.Typer(add_completion=False, help="orbweaver — tiny spider that tends a Neo4j memory graph")


@app.command()
def demo(
    benchmark: str = typer.Option("small", help="which benchmark: small|medium|large"),
    apply_ideal: bool = typer.Option(True, help="apply the hand-curated ideal mutations"),
):
    """Load benchmark, apply the ideal mutations, print F1-delta.

    This proves the eval pipeline works end-to-end without needing a trained
    model. Useful as a smoke test and as a CI reproducibility check.
    """
    from .eval import f1_delta, QAPair
    from .mutations import validate_array

    root = Path(__file__).resolve().parent.parent
    cy = (root / "benchmarks" / f"{benchmark}.cypher").read_text()
    qa_raw = json.loads((root / "benchmarks" / f"{benchmark}_qa.json").read_text())["qa"]
    expected = json.loads((root / "benchmarks" / f"{benchmark}_expected.json").read_text())
    qa = [QAPair(q=x["q"], gold_node_ids=x["gold_node_ids"],
                 gold_rel_triples=[tuple(t) for t in x["gold_rel_triples"]]) for x in qa_raw]
    muts = validate_array(expected["after_ideal_tending_mutations"]) if apply_ideal else []

    rprint(f"[bold]orbweaver demo[/bold]  benchmark={benchmark}  apply_ideal={apply_ideal}")
    res = f1_delta(cy, qa, muts)
    rprint(f"f1_before:   {res.f1_before:.3f}")
    rprint(f"f1_after:    {res.f1_after:.3f}")
    rprint(f"[bold green]delta:       {res.delta:+.3f}[/bold green]")
    rprint(f"health_before {res.health_before}")
    rprint(f"health_after  {res.health_after}")

    expected_before = expected["baseline_f1"]["value"]
    expected_after = expected["after_ideal_tending_f1"]["value"]
    tol_before = expected["baseline_f1"]["tolerance"]
    tol_after = expected["after_ideal_tending_f1"]["tolerance"]
    ok = (abs(res.f1_before - expected_before) <= tol_before
          and abs(res.f1_after - expected_after) <= tol_after)
    rprint(f"expected     {expected_before:.3f} (±{tol_before}) -> {expected_after:.3f} (±{tol_after})  -> {'OK' if ok else 'DRIFT'}")
    raise typer.Exit(code=0 if ok else 1)


@app.command()
def eval(
    benchmark: str = typer.Option("small"),
    adapter: Path | None = typer.Option(None),
    base_model: str = typer.Option("mlx-community/Qwen3-4B-Instruct-2507-4bit"),
    max_new_tokens: int = typer.Option(1024),
):
    """[LEGACY] Autoregressive eval — generate mutations as JSON text, parse,
    apply, report F1-delta. This is the path that hit the 15% verb-accuracy
    ceiling and got abandoned in favour of the classifier head + conformal
    abstention now shipped via `orbweaver tend`. Preserved for archaeology
    only; see docs/RESEARCH.md.

    For the v1.1 product loop, use `orbweaver tend --once`.
    """
    rprint("[yellow]warning:[/yellow] `orbweaver eval` is the legacy autoregressive "
           "path (15% ceiling). The v1.1 product is `orbweaver tend --once`. See docs/RESEARCH.md.")
    from .data import build_chat_messages, Example
    from .eval import QAPair, f1_delta
    from .mutations import validate_array
    from .model import load_base, inference_logits_processors

    root = Path(__file__).resolve().parent.parent
    cy = (root / "benchmarks" / f"{benchmark}.cypher").read_text()
    qa_raw = json.loads((root / "benchmarks" / f"{benchmark}_qa.json").read_text())["qa"]
    qa = [QAPair(q=x["q"], gold_node_ids=x["gold_node_ids"],
                 gold_rel_triples=[tuple(t) for t in x["gold_rel_triples"]]) for x in qa_raw]

    # Turn the benchmark fixture into an orbweaver prompt.
    ex = Example(
        id=benchmark,
        graph_snapshot_cypher=cy,
        events=[],
        expected_mutations=[],
    )
    msgs = build_chat_messages(ex)[:-1]  # drop assistant prompt; model fills it in

    from mlx_lm import generate
    model, tokenizer = load_base(base_model, adapter_path=str(adapter) if adapter else None)
    prompt = tokenizer.apply_chat_template(msgs, add_generation_prompt=True, tokenize=False)
    out = generate(
        model, tokenizer, prompt=prompt, max_tokens=max_new_tokens,
        logits_processors=inference_logits_processors(),    # D-015: repetition penalty 1.5
    )

    rprint(f"[dim]raw output:[/dim] {out}")
    try:
        muts = validate_array(out)
    except Exception as e:
        rprint(f"[red]invalid mutation JSON:[/red] {e}")
        raise typer.Exit(code=2)

    res = f1_delta(cy, qa, muts)
    rprint(f"[bold green]f1_delta: {res.delta:+.3f}[/bold green]  ({res.f1_before:.3f} -> {res.f1_after:.3f})")


@app.command()
def train():
    """Runs train.py in-process. Hyperparameters live at the top of train.py."""
    import runpy
    root = Path(__file__).resolve().parent.parent
    runpy.run_path(str(root / "train.py"), run_name="__main__")


@app.command()
def tend(
    once: bool = typer.Option(True, "--once/--loop",
                              help="single tick (v1.0) or continuous loop (v1.x)"),
    graph_uri: str = typer.Option(None, envvar="ORBWEAVER_BOLT",
                                  help="bolt://...  (default $ORBWEAVER_BOLT or bolt://127.0.0.1:7689)"),
    user: str = typer.Option("neo4j", envvar="ORBWEAVER_NEO4J_USER"),
    password: str = typer.Option("orbweaver-dev", envvar="ORBWEAVER_NEO4J_PASS"),
    spider_dir: Path = typer.Option(
        Path("dist/orbweaver-qwen3-4b-spider-v0.1"),
        help="path to the trained spider artifact directory"),
    max_candidates: int = typer.Option(50, help="cap candidates per tick"),
    max_stage: int = typer.Option(20, help="cap suggestions staged per tick"),
    target_coverage: float = typer.Option(
        None,
        help="override the conformal target_coverage for this tick. The "
             "shipped v0.1 head was calibrated at 90%; a synthetic-trained "
             "head against an out-of-distribution graph will abstain on most "
             "candidates — week-4 retrain fixes this. For smoke testing, "
             "drop to 0.5 to see singletons land."),
):
    """Run one tick of the tending daemon: scan the graph via blockers,
    classify each candidate pair via the trained head, stage suggestions
    when the prediction set is a singleton in {add_link, merge_entities}.

    v1.0 week-2: blocking.py drives candidates (shared-1-hop + token-overlap),
    spider.py orchestrates the loop, the existing dist/.../loader runs the
    classifier head + conformal prediction. Other 3 verbs are skipped (their
    HITL schema lands week 2.5).
    """
    from neo4j import GraphDatabase
    from .audit_log import apply_schema_migration, reversal_rate_24h
    from .mutations import SCHEMA_MIGRATION_CYPHER
    from .spider import tick

    if not once:
        rprint("[yellow]--loop is v1.x[/yellow] — for v1.0 use --once with cron")
        raise typer.Exit(code=1)

    uri = graph_uri or "bolt://127.0.0.1:7689"
    driver = GraphDatabase.driver(uri, auth=(user, password))
    try:
        with driver.session() as s:
            for stmt in SCHEMA_MIGRATION_CYPHER:
                try:
                    s.run(stmt)
                except Exception:
                    pass
        apply_schema_migration(driver)

        # Load spider once per tick (heavy: ~10s for the 4B base + head).
        rprint(f"[dim]loading spider from {spider_dir}…[/dim]")
        import importlib.util
        import sys as _sys
        loader_path = Path(spider_dir) / "loader.py"
        if not loader_path.exists():
            rprint(f"[red]no loader.py at {loader_path}[/red]")
            raise typer.Exit(code=2)
        spec = importlib.util.spec_from_file_location("orbweaver_loader", loader_path)
        loader_mod = importlib.util.module_from_spec(spec)
        # Register in sys.modules BEFORE exec_module — dataclasses defined
        # inside the loader resolve their __module__ via sys.modules at
        # field-introspection time. Without this, dataclass(...) raises
        # AttributeError on 'NoneType'.__dict__.
        _sys.modules["orbweaver_loader"] = loader_mod
        spec.loader.exec_module(loader_mod)  # type: ignore[union-attr]
        spider = loader_mod.load_spider(str(spider_dir))

        if target_coverage is not None:
            spider.target_coverage = float(target_coverage)
            rprint(f"[dim]target_coverage override: {spider.target_coverage:.2f}[/dim]")

        result = tick(driver, spider, max_candidates=max_candidates,
                      max_stage=max_stage)

        canary = reversal_rate_24h(driver)
        rprint(f"[bold green]tick complete[/bold green]  "
               f"candidates={result.candidates_seen}  staged={result.staged}  "
               f"skipped_abstain={result.skipped_abstain}  "
               f"skipped_unsupported_verb={result.skipped_unsupported_verb}")
        rprint(f"  reversal_rate_24h: {canary:.2%}")
        if result.edit_ids:
            rprint(f"  first staged edit_ids: {result.edit_ids[:3]}")
    finally:
        driver.close()


@app.command()
def review(
    graph_uri: str = typer.Option(None, envvar="ORBWEAVER_BOLT",
                                  help="bolt://...  (default $ORBWEAVER_BOLT or bolt://127.0.0.1:7689)"),
    user: str = typer.Option("neo4j", envvar="ORBWEAVER_NEO4J_USER"),
    password: str = typer.Option("orbweaver-dev", envvar="ORBWEAVER_NEO4J_PASS"),
    host: str = typer.Option("127.0.0.1"),
    port: int = typer.Option(7878,
                             help="default 7878 (Neo4j Browser owns 7474/7475/7476)"),
    open_browser: bool = typer.Option(True, "--browser/--no-browser"),
):
    """Start the single-page reviewer at http://localhost:<port>/. j/k navigates,
    a/r accept/reject, u undoes Applied edits. Polls /audit every 2s.

    The whole reviewer is two files: orbweaver/review.html (vanilla JS +
    Tailwind via CDN) and orbweaver/review.py (~80 LOC http.server). No
    FastAPI, no build step.
    """
    import webbrowser
    from neo4j import GraphDatabase
    from .audit_log import apply_schema_migration
    from .review import start_server

    uri = graph_uri or "bolt://127.0.0.1:7689"
    driver = GraphDatabase.driver(uri, auth=(user, password))
    apply_schema_migration(driver)
    server = start_server(driver, host=host, port=port)
    url = f"http://{host}:{port}/"
    rprint(f"[bold green]orbweaver review[/bold green]  serving {url}")
    rprint(f"  graph: {uri}")
    rprint("  press [bold]?[/bold] in the browser for shortcuts; Ctrl-C here to stop")
    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        rprint("\n[dim]shutting down[/dim]")
        server.shutdown()
    finally:
        driver.close()


@app.command("build-dataset")
def build_dataset(
    out_version: str = typer.Option("v1", help="dataset version tag"),
    per_type: int = typer.Option(50, help="scenarios per scenario type"),
    poll_every: int = typer.Option(60, help="seconds between batch polls"),
    sync: bool = typer.Option(False, "--sync",
                              help="run synchronously (no Batch API, no 50% discount). "
                                   "Use for small pilots where the 1h+ batch wait would hurt feedback."),
):
    """Generate an SFT dataset by calling the teacher, F1-filtering, and
    writing train/val/test JSONL + a manifest. Requires ANTHROPIC_API_KEY."""
    from .dataset_build import build
    manifest = build(out_version=out_version, per_type=per_type,
                     poll_every=poll_every, sync=sync)
    rprint(manifest)


@app.command("task-list")
def task_list_cmd(
    out_version: str = typer.Option("v1.1", help="dataset version"),
    per_type: int = typer.Option(10, help="scenarios per scenario type"),
):
    """Generate a task list for an agent-teacher session (no API calls).

    Writes `data/<out_version>/tasks.jsonl` with (custom_id, scenario_type,
    theme) triples. A fresh Claude Code session can work through them
    using the Write tool to stage one scenario per file."""
    from .agent_teacher import generate_tasks, write_task_list, build_kickoff_prompt
    root = Path(__file__).resolve().parent.parent
    out_dir = root / "data" / out_version
    tasks = generate_tasks(per_type)
    path = write_task_list(tasks, out_dir)
    rprint(f"[green]wrote {len(tasks)} tasks → {path}[/green]")
    rprint(f"  scenario types: {len(set(t['scenario_type'] for t in tasks))}")
    rprint(f"  themes used: {len(set(t['theme'] for t in tasks))}")
    rprint("\n[bold]Kickoff prompt for the agent session:[/bold]\n")
    rprint("─" * 72)
    print(build_kickoff_prompt(out_version, per_type))
    rprint("─" * 72)


@app.command("ingest-staged")
def ingest_staged_cmd(
    out_version: str = typer.Option("v1.1", help="dataset version"),
):
    """Validate every staged scenario JSON, F1-filter, write train/val/test
    splits + manifest. The complement of `task-list` in the agent-teacher
    workflow."""
    from .agent_teacher import ingest
    manifest = ingest(out_version)
    rprint(manifest)


@app.command("teacher-smoke")
def teacher_smoke(
    scenario_type: str = typer.Option("implicit_link"),
    theme: str = typer.Option("tech startup engineering team"),
):
    """Single teacher call (not batch). Verifies the system prompt + schema
    produce valid output before spending on a full batch. Requires ANTHROPIC_API_KEY."""
    from .teacher import single_call_smoke
    scen = single_call_smoke(scenario_type=scenario_type, theme=theme)
    rprint(f"[bold green]OK[/bold green] — scenario parsed. "
           f"{len(scen.expected_mutations)} mutations, "
           f"{len(scen.qa_pairs)} QA pairs.")
    rprint(scen.model_dump())


@app.command("inspect-scenario")
def inspect_scenario(
    scenario_id: str = typer.Argument(..., help="e.g. 'cluster_reflection_0001' or path to a JSONL"),
    dataset: str = typer.Option("v1.0", help="dataset version under data/"),
    apply_mutations: bool = typer.Option(True, "--apply/--no-apply",
                                         help="apply the expected_mutations after loading"),
    keep: bool = typer.Option(True, "--keep/--no-keep",
                              help="leave the graph in place for Bloom/Browser inspection"),
):
    """Load a training scenario into the live Neo4j for human inspection in
    Bloom or Neo4j Browser. Reuses the sandbox plumbing but with keep_on_exit
    so the graph survives process exit.

    Connection:
      bolt:   $ORBWEAVER_BOLT  (defaults to bolt://127.0.0.1:7689)
      http:   http://127.0.0.1:7475  (Neo4j Browser for the brew install)
      user:   neo4j
      pass:   $ORBWEAVER_NEO4J_PASS  (defaults to 'orbweaver-dev')
    """
    import os
    from .neo4j_sandbox import sandbox, load_cypher, apply_mutations as apply_muts
    from .mutations import validate_array

    # Find the scenario
    root = Path(__file__).resolve().parent.parent
    scenario_row = None
    for split in ("train", "val", "test"):
        path = root / "data" / dataset / f"{split}.jsonl"
        if not path.exists():
            continue
        for line in path.read_text().splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            if row["id"] == scenario_id:
                scenario_row = row
                break
        if scenario_row:
            break
    if scenario_row is None:
        rprint(f"[red]scenario {scenario_id!r} not found in data/{dataset}/*.jsonl[/red]")
        raise typer.Exit(code=2)

    meta = scenario_row.get("_meta", {})
    rprint(f"[bold]Loading[/bold] {scenario_id}  type={meta.get('scenario_type')}  "
           f"theme={meta.get('theme')}  expected_f1_delta={meta.get('teacher_f1_delta'):+.3f}")

    with sandbox(keep_on_exit=keep) as db:
        load_cypher(db, scenario_row["graph_snapshot_cypher"])
        if apply_mutations and scenario_row["expected_mutations"]:
            muts = validate_array(scenario_row["expected_mutations"])
            apply_muts(db, muts, tick_id=f"inspect-{scenario_id}", ledger=True, dry_run=False)
            rprint(f"  applied {len(muts)} mutations")
        # Counts after load
        with db.session() as s:
            n = s.run("MATCH (n) WHERE coalesce(n.deprecated,false)=false RETURN count(n) AS c").single()["c"]
            r = s.run("MATCH ()-[r]->() WHERE coalesce(r.deprecated,false)=false RETURN count(r) AS c").single()["c"]
            dn = s.run("MATCH (n) WHERE coalesce(n.deprecated,false)=true RETURN count(n) AS c").single()["c"]
            dr = s.run("MATCH ()-[r]->() WHERE coalesce(r.deprecated,false)=true RETURN count(r) AS c").single()["c"]

    rprint(f"\n[bold green]Graph loaded[/bold green]  live={n} nodes / {r} rels  deprecated={dn} nodes / {dr} rels")
    if keep:
        uri = os.getenv("ORBWEAVER_BOLT", "bolt://127.0.0.1:7689")
        port = uri.rsplit(":", 1)[-1]
        # Map common bolt → http ports by project convention:
        #   brew orbweaver:    7688 bolt → 7475 http
        #   Desktop orbweaver: 7689 bolt → 7476 http
        http_port = {"7687": "7474", "7688": "7475", "7689": "7476"}.get(port, "7474")
        rprint("\n[bold]Browse it:[/bold]")
        rprint(f"  Neo4j Browser:  http://127.0.0.1:{http_port}")
        rprint(f"  Bolt URI:       {uri}")
        rprint("  User:           neo4j")
        rprint(f"  Password:       {os.getenv('ORBWEAVER_NEO4J_PASS', 'orbweaver-dev')}")
        rprint("\n  Try: MATCH (n) RETURN n LIMIT 50")
        rprint("\n[yellow]The graph will remain until the next 'inspect-scenario' or 'build-dataset' run (both wipe).[/yellow]")
    else:
        rprint("[dim]--no-keep: graph wiped on exit[/dim]")


@app.command("load-pilot")
def load_pilot(
    dataset: str = typer.Option("v1.0", help="dataset version under data/"),
    apply_mutations: bool = typer.Option(True, "--apply/--no-apply"),
    target_db: str = typer.Option("neo4j", "--db", help="target database (must exist)"),
):
    """Load every scenario from a pilot dataset into one Neo4j database for
    Bloom browsing. Each node gets a `scenario_id` property so scenarios
    can be filtered in the UI or via Cypher.

    Design choice: one DB, not one-DB-per-scenario. Cross-scenario queries
    become natural (`MATCH (r:Reflection) RETURN r.scenario_id, r.summary`),
    the Desktop UI stays clean, and the shape matches the eventual
    production graph (which is always one graph, tended over time).
    """
    from .neo4j_sandbox import load_cypher, apply_mutations as apply_muts, SandboxHandle
    from .mutations import validate_array, SCHEMA_MIGRATION_CYPHER
    from neo4j import GraphDatabase

    root = Path(__file__).resolve().parent.parent
    rows = []
    for split in ("train", "val", "test"):
        p = root / "data" / dataset / f"{split}.jsonl"
        if not p.exists():
            continue
        for line in p.read_text().splitlines():
            if line.strip():
                rows.append(json.loads(line))
    if not rows:
        rprint(f"[red]no rows found under data/{dataset}[/red]")
        raise typer.Exit(code=2)

    uri = os.getenv("ORBWEAVER_BOLT", "bolt://127.0.0.1:7689")
    user = os.getenv("ORBWEAVER_NEO4J_USER", "neo4j")
    pw = os.getenv("ORBWEAVER_NEO4J_PASS", "orbweaver-dev")
    driver = GraphDatabase.driver(uri, auth=(user, pw))

    handle = SandboxHandle(driver=driver, database=target_db, bolt_uri=uri,
                           username=user, password=pw)

    # Wipe the target DB once; apply orbweaver's schema migration.
    with handle.session() as s:
        s.run("MATCH (n) DETACH DELETE n")
        for stmt in SCHEMA_MIGRATION_CYPHER:
            try:
                s.run(stmt)
            except Exception:
                pass

    try:
        for r in rows:
            sid = r["id"]
            load_cypher(handle, r["graph_snapshot_cypher"])
            if apply_mutations and r.get("expected_mutations"):
                apply_muts(handle, validate_array(r["expected_mutations"]),
                           tick_id=f"pilot-{sid}", ledger=True, dry_run=False)
            # Tag every un-tagged node with scenario_id — order matters: do
            # this AFTER mutations so Reflection/MutationLedgerEntry nodes
            # created by apply_mutations get the correct scenario_id.
            with handle.session() as s:
                s.run("MATCH (n) WHERE n.scenario_id IS NULL SET n.scenario_id=$sid", sid=sid)
            rprint(f"  [green]loaded[/green] {sid}")
    finally:
        driver.close()

    rprint(f"\n[bold green]Done[/bold green]: {len(rows)} scenarios in db `{target_db}`")
    rprint("\n  Filter a scenario in Bloom/Browser:")
    rprint('    MATCH (n {scenario_id: "cluster_reflection_0001"}) RETURN n')
    rprint("\n  Or compare across scenarios:")
    rprint("    MATCH (r:Reflection) RETURN r.scenario_id, r.summary ORDER BY r.scenario_id")


if __name__ == "__main__":
    app()
