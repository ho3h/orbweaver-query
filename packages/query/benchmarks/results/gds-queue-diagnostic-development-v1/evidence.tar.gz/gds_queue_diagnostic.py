"""Identify global topN queue overhead using exact native per-source requests."""

import argparse
import json
import os
import random
import shutil
import sys
import time
from pathlib import Path

import gds_quality
import gds_ranking as ranking
from structural_neo4j import checked, import_graph, read, runtime_identity, sha, write


def freeze(run, reference):
    original = checked(reference)
    previous = read(reference/'workers/0000.json')
    if previous['job'] != {'dataset': 'friendship', 'threads': 1, 'replicate': 1}:
        raise ValueError('Diagnostic must use the first declared friendship worker')
    if previous['manifest_sha256'] != sha(reference/'manifest.json'):
        raise ValueError('Prior worker belongs to another manifest')
    if sha(reference/'workers/0000-scores.npz') != previous['full_scores_sha256']:
        raise ValueError('Prior raw scores changed')
    run.mkdir(parents=True, exist_ok=False)
    package = Path(__file__).resolve().parents[2]
    shutil.copytree(package/'src/orbweaver_query', run/'source/orbweaver_query',
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for name in ('gds_queue_diagnostic.py', 'gds_quality.py', 'gds_ranking.py',
                 'structural_neo4j.py', 'GDS_QUEUE_DIAGNOSTIC.md'):
        shutil.copyfile(Path(__file__).with_name(name), run/name)
    shutil.copyfile(package/'tools/disposable_neo4j.py', run/'disposable_neo4j.py')
    shutil.copyfile(reference/'friendship-outer.npz', run/'graph.npz')
    shutil.copyfile(reference/'friendship-development.npz', run/'development.npz')
    shutil.copyfile(reference/'workers/0000.json', run/'previous-worker.json')
    shutil.copyfile(reference/'workers/0000-scores.npz', run/'previous-scores.npz')
    write(run/'manifest.json', {'format': 'orbweaver-gds-queue-diagnostic-v1',
        'files': {str(p.relative_to(run)): sha(p) for p in sorted(run.rglob('*')) if p.is_file()},
        'runtime_identity': original['runtime_identity'], 'reference_manifest_sha256': sha(reference/'manifest.json'),
        'threads': 1, 'gds_config': gds_quality.GDS_CONFIGS['baseline'], 'k': 16,
        'arms': ['global', 'partitioned'], 'warmup': 1, 'samples': 3, 'order_seed': 7620,
        'heap_megabytes': 8192, 'neo4j_version': '2026.09.0', 'gds_version': '2026.09.0',
        'confirmation_contents_read': False, 'timing_scope': 'single-process descriptive diagnostic'})
    return {'manifest_sha256': sha(run/'manifest.json')}


def worker(run, neo4j_home, java, gds_jar):
    sys.path.insert(0, str(run/'source'))
    sys.path.insert(0, str(run))
    import numpy as np
    from disposable_neo4j import disposable_database
    from neo4j import GraphDatabase
    from orbweaver_query import GraphSnapshot
    from orbweaver_query.neo4j import Neo4jSource

    manifest = checked(run)
    if runtime_identity(neo4j_home, java, gds_jar) != manifest['runtime_identity']:
        raise ValueError('Native runtime differs')
    if any(os.environ.get(key) != '1' for key in gds_quality.THREADS):
        raise ValueError('Diagnostic requires one-thread numeric-library ceilings')
    graph = GraphSnapshot.load(run/'graph.npz')
    with np.load(run/'development.npz', allow_pickle=False) as file:
        sources = file['sources']
    heads = [graph.node_ids[i] for i in sources]
    candidate_mask = ranking.candidate_mask(graph, sources)
    capacity = int(candidate_mask.sum())
    unique = capacity-int(candidate_mask[:, sources].sum())//2
    copy_lower_bound = 24*(unique*capacity-unique*(unique+1)//2)
    setup, records = {}, []

    def phase(name, begin):
        setup[name] = time.perf_counter()-begin
        print(name, round(setup[name], 3), file=sys.stderr, flush=True)

    begin = time.perf_counter()
    with (disposable_database(neo4j_home, java, gds_jar=gds_jar,
            heap_megabytes=manifest['heap_megabytes'], entrypoint='org.neo4j.server.Neo4jCommunity',
            transaction_timeout='900s') as uri, GraphDatabase.driver(uri, auth=None) as driver):
        phase('database_start', begin)

        def query(cypher, **parameters):
            return [r.data() for r in driver.execute_query(cypher, parameters_=parameters)[0]]

        versions = query('CALL dbms.components() YIELD versions '
                         'RETURN versions[0] AS neo4j,gds.version() AS gds')[0]
        if versions != {key: manifest[key+'_version'] for key in ('neo4j', 'gds')}:
            raise ValueError('Database versions differ')
        begin = time.perf_counter()
        import_graph(driver, graph)
        phase('import', begin)
        begin = time.perf_counter()
        query('UNWIND $heads AS id MATCH (n:Node {id:id}) SET n:Query', heads=heads)
        specs = ranking.prepare_source_specs(query, heads)
        query("CALL gds.graph.project('graph',$labels,{LINK:{orientation:'UNDIRECTED'}})",
              labels=['Node', 'Query', *[s['source_label'] for s in specs]])
        phase('labels_and_projection', begin)
        begin = time.perf_counter()
        trained = ranking.fit_gds(query, manifest['gds_config'], 1)
        phase('fit', begin)
        source = Neo4jSource(driver, fetch_size=1000)
        params = {'heads': heads, 'k': manifest['k'], 'threads': 1, 'candidate_count': capacity}
        begin = time.perf_counter()
        scores = ranking.from_stream(source.iter_candidates(ranking.gds_query(full=True), params), graph, sources)
        expected = ranking.rank_scores(scores, graph, sources, manifest['k'])
        phase('full_score_audit', begin)
        with np.load(run/'previous-scores.npz', allow_pickle=False) as file:
            prior = file['gds']
        if not np.array_equal(np.isfinite(scores), np.isfinite(prior)):
            raise ValueError('Prior and current candidate coverage differ')
        previous_max_error = float(np.max(np.abs(scores[candidate_mask]-prior[candidate_mask])))
        np.savez_compressed(run/'scores.npz', scores=scores)
        order = list(manifest['arms'])
        random.Random(manifest['order_seed']).shuffle(order)
        for arm in order:
            samples, counters = [], []
            for repeat in range(manifest['warmup']+manifest['samples']):
                begin = time.perf_counter()
                if arm == 'global':
                    output = list(source.iter_candidates(ranking.gds_query(), params))
                    count = {'procedure_calls': 1, 'max_top_n': capacity}
                else:
                    output, count = ranking.partitioned_request(source, specs, 1, manifest['k'])
                json.dumps(output, sort_keys=True, allow_nan=False)
                elapsed = time.perf_counter()-begin
                if output != expected:
                    write(run/'mismatch.json', {'arm': arm, 'repeat': repeat, 'expected': expected, 'actual': output})
                    raise ValueError('Native request differs from the complete-score reference')
                if repeat >= manifest['warmup']:
                    samples.append(elapsed)
                    counters.append(count)
                print(arm, repeat, round(elapsed, 3), count, file=sys.stderr, flush=True)
            records.append({'arm': arm, 'samples_seconds': samples, 'counters': counters, 'output': output})
    report = {'format': manifest['format'], 'manifest_sha256': sha(run/'manifest.json'),
        'setup_seconds': setup, 'records': records, 'model_training': trained,
        'candidate_count': capacity, 'unique_undirected_predictions': unique,
        'global_queue_logical_copy_bytes_lower_bound': copy_lower_bound,
        'lower_bound_scope': 'source-derived logical array-copy bytes, not measured DRAM traffic or elapsed-time attribution',
        'previous_model_max_absolute_score_difference': previous_max_error,
        'all_outputs_match_complete_score_reference': True, 'full_scores_sha256': sha(run/'scores.npz'),
        'single_process_diagnostic': True, 'confirmation_contents_read': False}
    write(run/'results.json', report)
    return {'all_outputs_match_complete_score_reference': True,
            'median_seconds': {r['arm']: float(np.median(r['samples_seconds'])) for r in records},
            'previous_model_max_absolute_score_difference': previous_max_error}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('freeze', 'worker'))
    parser.add_argument('run', type=Path)
    parser.add_argument('--reference', type=Path)
    for name in ('neo4j-home', 'java', 'gds-jar'):
        parser.add_argument('--'+name, type=Path)
    args = parser.parse_args()
    run = args.run.resolve()
    if args.command == 'freeze':
        result = freeze(run, args.reference)
    else:
        result = worker(run, args.neo4j_home, args.java, args.gds_jar)
    print(json.dumps(result, allow_nan=False))
