"""Driver: turn teacher-generated scenarios into a validated SFT dataset.

Pipeline (Karpathy-style — small, linear, one script):

    1. plan:       build a list of (scenario_type, theme) pairs → batch requests
    2. submit:     send as a Claude Opus batch
    3. poll:       wait for 'ended'
    4. parse:      each successful result → Pydantic `TrainingScenario`
    5. filter:     apply mutations in a sandbox, keep only F1-delta-helpful ones
    6. split:      80/10/10 by hash of (scenario_type + theme + seq)
    7. write:      data/v{N}/{train,val,test}.jsonl + manifest.json

CLI:

    orbweaver build-dataset --out-version v1 --per-type 50

Cost: ~$0.15-0.30 per scenario with Claude Opus 4.7 batch (50% off). For
300 scenarios, budget ~$50 including retries and Q&A answerer calls.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from dataclasses import dataclass
from pathlib import Path

from .eval import QAPair, f1_delta
from .mutations import validate_array
from .teacher import (
    SCENARIO_TYPES,
    THEMES,
    TrainingScenario,
    build_batch_request,
    iter_results,
    parse_scenario,
    poll_until_done,
    submit_batch,
)


# ---------- plan ----------

def build_plan(per_type: int = 50) -> list[dict]:
    """Produce a list of batch-request dicts spanning all scenario types and
    themes. Themes rotate per scenario type."""
    requests: list[dict] = []
    for stype in SCENARIO_TYPES:
        for i in range(per_type):
            theme = THEMES[i % len(THEMES)]
            custom_id = f"{stype}_{i:04d}"
            requests.append(build_batch_request(
                custom_id=custom_id, scenario_type=stype, theme=theme,
            ))
    return requests


# ---------- filter ----------

@dataclass
class FilteredExample:
    id: str
    scenario_type: str
    theme: str
    graph_snapshot_cypher: str
    events_since_last_tick: list[dict]
    expected_mutations: list[dict]
    qa_pairs: list[dict]
    teacher_f1_delta: float
    rationale: str
    teacher_model: str
    teacher_prompt_hash: str

    def to_training_row(self) -> dict:
        """The JSONL shape train.py expects (see orbweaver/data.py). Also
        carries `qa_pairs` and teacher metadata so we can re-validate F1-delta
        offline after sandbox or eval changes, without re-calling the teacher."""
        return {
            "id": self.id,
            "graph_snapshot_cypher": self.graph_snapshot_cypher,
            "events_since_last_tick": self.events_since_last_tick,
            "expected_mutations": self.expected_mutations,
            # Persisted for offline re-validation — loader ignores unknown keys
            "qa_pairs": self.qa_pairs,
            "_meta": {
                "scenario_type": self.scenario_type,
                "theme": self.theme,
                "teacher_f1_delta": self.teacher_f1_delta,
                "rationale": self.rationale,
                "teacher_model": self.teacher_model,
                "teacher_prompt_hash": self.teacher_prompt_hash,
            },
        }


def filter_scenario(
    custom_id: str, scenario: TrainingScenario, *,
    epsilon: float = -0.01, teacher_model: str = "claude-opus-4-7",
    prompt_hash: str = "",
) -> FilteredExample | None:
    """Validate mutations, apply in sandbox, measure F1-delta, keep iff helpful.

    no_op scenarios with zero mutations are kept without running the sandbox
    (they teach restraint; F1-delta is zero by construction).
    """
    # Mutation-shape validation (structural only; rejects unknown verbs etc.)
    try:
        muts = validate_array(scenario.expected_mutations)
    except Exception as e:
        print(f"[filter] {custom_id}: invalid mutations: {e}", flush=True)
        return None

    # no_op: keep with delta 0.0 — the model must learn to do nothing sometimes.
    if not muts:
        if scenario.scenario_type != "no_op":
            print(f"[filter] {custom_id}: empty mutations but scenario_type={scenario.scenario_type}; drop", flush=True)
            return None
        return _as_filtered(custom_id, scenario, 0.0, teacher_model, prompt_hash)

    qa = [
        QAPair(q=p.q, gold_node_ids=p.gold_node_ids,
               gold_rel_triples=[tuple(t) for t in p.gold_rel_triples])
        for p in scenario.qa_pairs
    ]

    try:
        res = f1_delta(scenario.graph_snapshot_cypher, qa, muts)
    except Exception as e:
        print(f"[filter] {custom_id}: sandbox eval failed: {e}", flush=True)
        return None

    if res.delta < epsilon:
        print(f"[filter] {custom_id}: delta {res.delta:+.3f} < {epsilon}; drop", flush=True)
        return None

    return _as_filtered(custom_id, scenario, res.delta, teacher_model, prompt_hash)


def _as_filtered(
    custom_id: str, s: TrainingScenario, delta: float,
    teacher_model: str, prompt_hash: str,
) -> FilteredExample:
    return FilteredExample(
        id=custom_id,
        scenario_type=s.scenario_type,
        theme=s.theme,
        graph_snapshot_cypher=s.graph_snapshot_cypher,
        events_since_last_tick=s.events_since_last_tick,
        expected_mutations=s.expected_mutations,
        qa_pairs=[p.model_dump() for p in s.qa_pairs],
        teacher_f1_delta=delta,
        rationale=s.rationale,
        teacher_model=teacher_model,
        teacher_prompt_hash=prompt_hash,
    )


# ---------- split + write ----------

def _split_bucket(example_id: str, *, train_pct: float = 0.8, val_pct: float = 0.1) -> str:
    """Deterministic split by hash of example id. 80/10/10."""
    h = int(hashlib.sha256(example_id.encode()).hexdigest(), 16) % 1000
    if h < int(train_pct * 1000):
        return "train"
    if h < int((train_pct + val_pct) * 1000):
        return "val"
    return "test"


def write_splits(examples: list[FilteredExample], out_dir: Path) -> dict:
    """Write train/val/test JSONL files and return split counts."""
    out_dir.mkdir(parents=True, exist_ok=True)
    buckets: dict[str, list[FilteredExample]] = {"train": [], "val": [], "test": []}
    for ex in examples:
        buckets[_split_bucket(ex.id)].append(ex)

    counts = {}
    for name, items in buckets.items():
        path = out_dir / f"{name}.jsonl"
        with path.open("w") as f:
            for ex in items:
                f.write(json.dumps(ex.to_training_row(), separators=(",", ":")) + "\n")
        counts[name] = len(items)
    return counts


def write_manifest(out_dir: Path, **kwargs) -> Path:
    manifest_path = out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(kwargs, indent=2))
    return manifest_path


# ---------- driver ----------

def build(out_version: str = "v1", per_type: int = 50,
          poll_every: int = 60, sync: bool = False) -> dict:
    """Build a dataset version.

    `sync=True` runs requests sequentially (no Batch API). Fast feedback for
    small pilots (D-010 3b.0 is 12 scenarios — batch would wait 1h+ for
    something that runs synchronously in ~5 min). `sync=False` uses the
    Batch API for 50% discount on the full 300-scenario run.
    """
    import os
    if not os.getenv("ANTHROPIC_API_KEY"):
        raise SystemExit("ANTHROPIC_API_KEY not set — export it before running.")

    from .teacher import SYSTEM_PROMPT, MODEL
    import hashlib
    prompt_hash = "sha256:" + hashlib.sha256(SYSTEM_PROMPT.encode()).hexdigest()[:16]

    # 1. plan
    reqs = build_plan(per_type=per_type)
    print(f"[build] planned {len(reqs)} requests across "
          f"{len(SCENARIO_TYPES)} scenario types × {per_type}/type "
          f"(mode={'sync' if sync else 'batch'})", flush=True)

    t0 = time.time()
    results_iter = _run_sync(reqs) if sync else _run_batch(reqs, poll_every)

    # 4. parse + 5. filter
    kept: list[FilteredExample] = []
    drop_invalid = drop_f1 = drop_err = 0
    for custom_id, status, content_or_err, usage in results_iter:
        if status != "succeeded":
            drop_err += 1
            print(f"[build] {custom_id}: {status}: {content_or_err}", flush=True)
            continue

        try:
            text = next(b.text for b in content_or_err if b.type == "text")
            scen = parse_scenario(text)
        except Exception as e:
            drop_invalid += 1
            print(f"[build] {custom_id}: parse failed: {e}", flush=True)
            continue

        fx = filter_scenario(custom_id, scen, teacher_model=MODEL, prompt_hash=prompt_hash)
        if fx is None:
            drop_f1 += 1
            continue
        kept.append(fx)
        print(f"[build] {custom_id}: KEPT  muts={len(scen.expected_mutations)} "
              f"f1_delta={fx.teacher_f1_delta:+.3f}", flush=True)

    # 6. split + 7. write
    out_dir = Path(__file__).resolve().parent.parent / "data" / out_version
    counts = write_splits(kept, out_dir)
    manifest = {
        "version": out_version,
        "teacher_model": MODEL,
        "teacher_prompt_hash": prompt_hash,
        "mode": "sync" if sync else "batch",
        "scenario_types": SCENARIO_TYPES,
        "themes_used": THEMES,
        "per_type": per_type,
        "requests_sent": len(reqs),
        "drop_invalid": drop_invalid,
        "drop_f1_filter": drop_f1,
        "drop_request_errors": drop_err,
        "kept_total": len(kept),
        "split_counts": counts,
        "f1_delta_mean": (sum(e.teacher_f1_delta for e in kept) / max(1, len(kept))),
        "wall_clock_s": int(time.time() - t0),
    }
    write_manifest(out_dir, **manifest)
    print(f"[build] DONE  kept={len(kept)}  splits={counts}  -> {out_dir}", flush=True)
    return manifest


def _run_batch(reqs, poll_every):
    batch = submit_batch(reqs)
    print(f"[build] submitted batch {batch.id}", flush=True)
    batch = poll_until_done(batch.id, poll_every=poll_every)
    print(f"[build] batch ended  succeeded={batch.request_counts.succeeded}  "
          f"errored={batch.request_counts.errored}", flush=True)
    yield from iter_results(batch.id)


def _run_sync(reqs):
    """Execute requests sequentially via the Messages API (no Batch, no 50%
    discount). Yields (custom_id, status, content, usage) tuples matching
    the batch iterator contract.
    """
    import anthropic
    client = anthropic.Anthropic()
    for i, r in enumerate(reqs, 1):
        try:
            msg = client.messages.create(**r["params"])
            print(f"[build] {r['custom_id']} ({i}/{len(reqs)}): "
                  f"in={msg.usage.input_tokens} out={msg.usage.output_tokens} "
                  f"cache_read={getattr(msg.usage, 'cache_read_input_tokens', 0)}",
                  flush=True)
            yield r["custom_id"], "succeeded", msg.content, msg.usage
        except Exception as e:
            yield r["custom_id"], "errored", str(e), None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-version", default="v1")
    ap.add_argument("--per-type", type=int, default=50)
    ap.add_argument("--poll-every", type=int, default=60)
    ap.add_argument("--sync", action="store_true",
                    help="run synchronously (no Batch API). Use for small pilots.")
    args = ap.parse_args()
    build(out_version=args.out_version, per_type=args.per_type,
          poll_every=args.poll_every, sync=args.sync)


if __name__ == "__main__":
    main()
