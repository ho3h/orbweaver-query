"""Thin wrapper around mlx-lm for loading the base + attaching LoRA.

We deliberately keep these thin so the training loop (`train.py`) owns the
optimizer, step, and logging. That matches the autoresearch-text2cypher
aesthetic: one file has the whole experiment; modules are utilities, not
frameworks.

Base model per D-014: `mlx-community/Qwen3-4B-Instruct-2507-4bit`.
LoRA targets per D-015: attention projections + MLP projections.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any


DEFAULT_MODEL = "mlx-community/Qwen3-4B-Instruct-2507-4bit"


def load_base(model_path: str = DEFAULT_MODEL, *, adapter_path: str | None = None):
    """Load base model + tokenizer via mlx-lm. If adapter_path is given, it
    is overlaid on top of the base (frozen base, trainable adapter).

    A pre-quantised 4-bit checkpoint auto-enables QLoRA: `mlx_lm.load`
    keeps the base in int4, `attach_lora` overlays bf16 trainable
    adapters. No explicit QLoRA flag needed.
    """
    from mlx_lm import load
    model, tokenizer = load(model_path, adapter_path=adapter_path)
    return model, tokenizer


def attach_lora(
    model,
    *,
    rank: int = 16,
    alpha: int = 32,
    dropout: float = 0.05,
    target_modules: list[str] | None = None,
    num_layers: int = -1,
):
    """Attach LoRA adapters in-place.

    `target_modules` are **full in-layer paths** like `self_attn.q_proj`,
    because `mlx_lm.tuner.utils.linear_to_lora_layers` matches against the
    names returned by `layer.named_modules()`. Leaf-only names like
    `q_proj` will silently match nothing — verified against mlx-lm 0.31.

    `num_layers=-1` means all layers.

    Defaults include MLP projections per D-015 — attention-only LoRA
    under-expresses structured-JSON fine-tunes.
    """
    from mlx_lm.tuner.utils import linear_to_lora_layers

    keys = target_modules or [
        "self_attn.q_proj",
        "self_attn.k_proj",
        "self_attn.v_proj",
        "self_attn.o_proj",
        "mlp.gate_proj",
        "mlp.up_proj",
        "mlp.down_proj",
    ]
    config: dict[str, Any] = {
        "rank": rank,
        "alpha": alpha,
        "dropout": dropout,
        "scale": 2.0,
        "keys": keys,
    }

    # Order matters: attach LoRA BEFORE freeze. linear_to_lora_layers replaces
    # modules in-place; the new LoRA adapter sub-params are trainable by
    # default. We then freeze the whole model and unfreeze only lora_a/lora_b.
    linear_to_lora_layers(model, num_layers=num_layers, config=config)
    model.freeze()
    model.unfreeze(recurse=True, keys="lora_a")
    model.unfreeze(recurse=True, keys="lora_b")

    return model, None


def save_adapter(model, path: str | Path) -> None:
    """Save only the trainable (LoRA) parameters to a safetensors file."""
    import mlx.core as mx
    from mlx.utils import tree_flatten
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    trainable = dict(tree_flatten(model.trainable_parameters()))
    mx.save_safetensors(str(path), trainable)


def merge_and_save(base_path: str, adapter_path: str, out_path: str,
                   *, de_quantize: bool = False) -> None:
    """Fuse LoRA back into the base and write a standalone safetensors bundle.
    Uses mlx-lm's CLI-exposed fuse helper under the hood.

    When fusing from a 4-bit base (our default per D-014), GGUF export
    fails unless `de_quantize=True` is passed — GGUF can't round-trip
    a quantised MLX checkpoint. Phase 7 concern; safe default is False
    (produces an MLX-native fused bundle).
    """
    import subprocess
    cmd = ["python", "-m", "mlx_lm", "fuse",
           "--model", base_path,
           "--adapter-path", adapter_path,
           "--save-path", out_path]
    if de_quantize:
        cmd.append("--de-quantize")
    subprocess.run(cmd, check=True)


def inference_logits_processors(repetition_penalty: float = 1.5,
                                 repetition_context_size: int = 20):
    """Return mlx-lm logits-processors configured with Qwen-recommended
    repetition suppression (D-015).

    Qwen3 model cards warn against greedy decoding on quantised variants
    and recommend a ~1.5 presence penalty. mlx-lm's closest native knob
    is `repetition_penalty` via `make_logits_processors`. Returns an
    empty list if mlx-lm's sampler utilities aren't importable, so
    callers can pass the result unconditionally.
    """
    try:
        from mlx_lm.sample_utils import make_logits_processors
    except ImportError:
        return []
    return make_logits_processors(
        repetition_penalty=repetition_penalty,
        repetition_context_size=repetition_context_size,
    )
