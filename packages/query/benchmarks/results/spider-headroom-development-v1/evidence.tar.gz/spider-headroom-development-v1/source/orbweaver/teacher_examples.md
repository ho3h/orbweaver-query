
# Worked examples

The following three scenarios are vetted outputs from prior runs; each
passed the downstream F1-delta filter. Two notes before you read them:

- **Characters across examples are INDEPENDENT.** If the name "Priya
  Raman" appears in Example 1 (a tech company) and also in Example 2
  (a biology lab), treat them as different people in unrelated
  scenarios. In YOUR output, INVENT FRESH NAMES — do not copy any
  name or id from the examples.
- **IDs across examples are INDEPENDENT.** Do not reuse any id string
  (like `priya_raman`, `svc_ingest`, `raman_lab`, `marsh_lab`, etc.)
  from these examples in your output. Mint fresh ids per request.


## Example 1 — scenario_type=implicit_link, theme=tech startup engineering team

```json
{
  "scenario_type": "implicit_link",
  "theme": "tech startup engineering team",
  "graph_snapshot_cypher": "CREATE (p1:Person {id: 'priya_raman', name: 'Priya Raman', role: 'Staff Engineer'});\nCREATE (p2:Person {id: 'marcus_hoang', name: 'Marcus Hoang', role: 'Backend Engineer'});\nCREATE (p3:Person {id: 'lena_osei', name: 'Lena Osei', role: 'SRE Lead'});\nCREATE (p4:Person {id: 'dmitri_volkov', name: 'Dmitri Volkov', role: 'Engineering Manager'});\nCREATE (p5:Person {id: 'sara_feldman', name: 'Sara Feldman', role: 'Frontend Engineer'});\nCREATE (o1:Org {id: 'lattice_signal', name: 'Lattice Signal'});\nCREATE (o2:Org {id: 'platform_team', name: 'Platform Team'});\nCREATE (o3:Org {id: 'growth_team', name: 'Growth Team'});\nCREATE (obj1:Object {id: 'svc_ingest', name: 'ingest-gateway service'});\nCREATE (obj2:Object {id: 'svc_billing', name: 'billing-core service'});\nCREATE (obj3:Object {id: 'runbook_oncall', name: 'On-call Runbook v4'});\nCREATE (ev1:Event {id: 'incident_2411', name: 'INC-2411 ingest outage', date: '2025-02-14'});\nCREATE (ev2:Event {id: 'postmortem_2411', name: 'INC-2411 Postmortem', date: '2025-02-17'});\nCREATE (pl1:Place {id: 'hq_berlin', name: 'Berlin HQ'});\nCREATE (m1:Message {id: 'msg_pager_1', content: 'Page: ingest-gateway p99 latency > 5s, error budget blown'});\nCREATE (m2:Message {id: 'msg_slack_1', content: 'Priya pushed the hotfix to ingest-gateway at 02:14 UTC, traffic recovered'});\nCREATE (p1)-[:EMPLOYED_BY {weight: 0.95}]->(o1);\nCREATE (p2)-[:EMPLOYED_BY {weight: 0.95}]->(o1);\nCREATE (p3)-[:EMPLOYED_BY {weight: 0.95}]->(o1);\nCREATE (p4)-[:EMPLOYED_BY {weight: 0.95}]->(o1);\nCREATE (p5)-[:EMPLOYED_BY {weight: 0.95}]->(o1);\nCREATE (p1)-[:MEMBER_OF {weight: 0.9}]->(o2);\nCREATE (p2)-[:MEMBER_OF {weight: 0.9}]->(o2);\nCREATE (p3)-[:MEMBER_OF {weight: 0.9}]->(o2);\nCREATE (p5)-[:MEMBER_OF {weight: 0.9}]->(o3);\nCREATE (p4)-[:KNOWS {weight: 0.8}]->(p1);\nCREATE (p4)-[:KNOWS {weight: 0.8}]->(p2);\nCREATE (o1)-[:LOCATED_AT {weight: 1.0}]->(pl1);\nCREATE (o2)-[:OWNS {weight: 1.0}]->(obj1);\nCREATE (o2)-[:OWNS {weight: 1.0}]->(obj2);\nCREATE (ev1)-[:OCCURRED_AT {weight: 1.0}]->(pl1);\nCREATE (ev1)-[:MENTIONS {weight: 0.9}]->(obj1);\nCREATE (p3)-[:PARTICIPATED_IN {weight: 0.9}]->(ev1);\nCREATE (p2)-[:PARTICIPATED_IN {weight: 0.7}]->(ev1);\nCREATE (ev2)-[:RELATED_TO {weight: 0.95}]->(ev1);\nCREATE (p3)-[:PARTICIPATED_IN {weight: 0.9}]->(ev2);\nCREATE (p4)-[:PARTICIPATED_IN {weight: 0.8}]->(ev2);\nCREATE (m1)-[:MENTIONS {weight: 0.9}]->(obj1);\nCREATE (m2)-[:MENTIONS {weight: 0.9}]->(obj1);\nCREATE (m2)-[:MENTIONS {weight: 0.85}]->(p1);\nCREATE (obj3)-[:MENTIONS {weight: 0.7}]->(obj1)",
  "events_since_last_tick": [
    {
      "t": "2025-02-17T10:30:00Z",
      "kind": "postmortem_note",
      "entity_ids": [
        "postmortem_2411",
        "priya_raman",
        "svc_ingest"
      ],
      "text": "Postmortem confirms Priya authored and deployed the hotfix for ingest-gateway during INC-2411; she is also listed as the current code owner of the service."
    },
    {
      "t": "2025-02-17T11:05:00Z",
      "kind": "chat_message",
      "entity_ids": [
        "msg_slack_1",
        "priya_raman",
        "svc_ingest"
      ],
      "text": "Dmitri: 'Priya owns ingest-gateway going forward \u2014 she wrote most of it and led the recovery.'"
    }
  ],
  "expected_mutations": [
    {
      "verb": "add_link",
      "from_id": "priya_raman",
      "to_id": "svc_ingest",
      "rel_type": "OWNS",
      "weight": 0.85,
      "rationale": "Postmortem and manager's Slack message both identify Priya as the code owner of ingest-gateway; she authored the hotfix during INC-2411."
    },
    {
      "verb": "add_link",
      "from_id": "priya_raman",
      "to_id": "incident_2411",
      "rel_type": "PARTICIPATED_IN",
      "weight": 0.9,
      "rationale": "Priya deployed the hotfix at 02:14 UTC during INC-2411 per msg_slack_1 and the postmortem, so she participated in the incident response."
    },
    {
      "verb": "add_link",
      "from_id": "priya_raman",
      "to_id": "postmortem_2411",
      "rel_type": "PARTICIPATED_IN",
      "weight": 0.8,
      "rationale": "The postmortem note directly attributes the hotfix authorship to Priya, indicating she contributed to the postmortem record."
    }
  ],
  "qa_pairs": [
    {
      "q": "Who owns the ingest-gateway service?",
      "gold_node_ids": [
        "priya_raman",
        "svc_ingest"
      ],
      "gold_rel_triples": [
        [
          "priya_raman",
          "OWNS",
          "svc_ingest"
        ]
      ]
    },
    {
      "q": "Who participated in incident INC-2411?",
      "gold_node_ids": [
        "priya_raman",
        "incident_2411"
      ],
      "gold_rel_triples": [
        [
          "priya_raman",
          "PARTICIPATED_IN",
          "incident_2411"
        ]
      ]
    }
  ],
  "rationale": "The postmortem and manager's message implicitly establish Priya as the owner of ingest-gateway and a participant in both the incident and its postmortem, but no such edges exist in the graph. Adding these links lets downstream queries about service ownership and incident responders resolve correctly."
}
```

## Example 2 — scenario_type=cluster_reflection, theme=molecular biology research group

```json
{
  "scenario_type": "cluster_reflection",
  "theme": "molecular biology research group",
  "graph_snapshot_cypher": "CREATE (p1:Person {id: 'priya_raman', name: 'Priya Raman', role: 'PI'})\n;\nCREATE (p2:Person {id: 'lukas_vogt', name: 'Lukas Vogt', role: 'postdoc'})\n;\nCREATE (p3:Person {id: 'mei_tanaka', name: 'Mei Tanaka', role: 'PhD student'})\n;\nCREATE (p4:Person {id: 'daniel_okafor', name: 'Daniel Okafor', role: 'PhD student'})\n;\nCREATE (p5:Person {id: 'sara_elkhoury', name: 'Sara El-Khoury', role: 'lab manager'})\n;\nCREATE (o1:Org {id: 'raman_lab', name: 'Raman Lab'})\n;\nCREATE (o2:Org {id: 'eth_zurich', name: 'ETH Zurich'})\n;\nCREATE (pl1:Place {id: 'hci_building', name: 'HCI Building, Hoenggerberg'})\n;\nCREATE (obj1:Object {id: 'crispr_screen_v3', name: 'CRISPR-Cas12a tiling screen v3'})\n;\nCREATE (obj2:Object {id: 'hek293_line', name: 'HEK293T parental line'})\n;\nCREATE (obj3:Object {id: 'rnaseq_pipeline', name: 'nf-core/rnaseq v3.14'})\n;\nCREATE (f1:Fact {id: 'fact_tp53_hit', content: 'TP53 scored as a top synthetic-lethal hit in MTAP-null context (FDR 0.002)'})\n;\nCREATE (f2:Fact {id: 'fact_prmt5_hit', content: 'PRMT5 confirmed as second-ranked hit in MTAP-null context (FDR 0.004)'})\n;\nCREATE (f3:Fact {id: 'fact_mat2a_hit', content: 'MAT2A enrichment reproduces prior Mavrakis 2016 finding'})\n;\nCREATE (e1:Event {id: 'lab_meeting_0917', name: 'Lab meeting 2024-09-17', topic: 'MTAP synthetic lethality screen readout'})\n;\nCREATE (m1:Message {id: 'msg_slack_0915', content: 'Priya: the MTAP-null arm is showing three clean hits \u2014 TP53, PRMT5, MAT2A. Need to discuss validation priorities Tuesday.'})\n;\nCREATE (m2:Message {id: 'msg_email_0918', content: 'Lukas to Mei: I will take PRMT5 arrayed validation if you cover MAT2A knockdown timecourse.'})\n;\nCREATE (p1)-[:EMPLOYED_BY {weight: 0.95}]->(o2)\n;\nCREATE (p1)-[:MEMBER_OF {weight: 1.0}]->(o1)\n;\nCREATE (p2)-[:MEMBER_OF {weight: 1.0}]->(o1)\n;\nCREATE (p3)-[:MEMBER_OF {weight: 1.0}]->(o1)\n;\nCREATE (p4)-[:MEMBER_OF {weight: 1.0}]->(o1)\n;\nCREATE (p5)-[:MEMBER_OF {weight: 1.0}]->(o1)\n;\nCREATE (o1)-[:LOCATED_AT {weight: 0.9}]->(pl1)\n;\nCREATE (p2)-[:USES {weight: 0.8}]->(obj1)\n;\nCREATE (p3)-[:USES {weight: 0.8}]->(obj1)\n;\nCREATE (p4)-[:USES {weight: 0.7}]->(obj3)\n;\nCREATE (obj1)-[:USES {weight: 0.6}]->(obj2)\n;\nCREATE (f1)-[:RELATED_TO {weight: 0.85}]->(obj1)\n;\nCREATE (f2)-[:RELATED_TO {weight: 0.85}]->(obj1)\n;\nCREATE (f3)-[:RELATED_TO {weight: 0.8}]->(obj1)\n;\nCREATE (e1)-[:OCCURRED_AT {weight: 0.9}]->(pl1)\n;\nCREATE (p1)-[:PARTICIPATED_IN {weight: 1.0}]->(e1)\n;\nCREATE (p2)-[:PARTICIPATED_IN {weight: 1.0}]->(e1)\n;\nCREATE (p3)-[:PARTICIPATED_IN {weight: 1.0}]->(e1)\n;\nCREATE (p4)-[:PARTICIPATED_IN {weight: 1.0}]->(e1)\n;\nCREATE (m1)-[:MENTIONS {weight: 0.9}]->(f1)\n;\nCREATE (m1)-[:MENTIONS {weight: 0.9}]->(f2)\n;\nCREATE (m1)-[:MENTIONS {weight: 0.9}]->(f3)\n;\nCREATE (m2)-[:MENTIONS {weight: 0.8}]->(f2)\n;\nCREATE (m2)-[:MENTIONS {weight: 0.8}]->(f3)",
  "events_since_last_tick": [
    {
      "t": "2024-09-17T14:00:00Z",
      "kind": "meeting",
      "entity_ids": [
        "e1",
        "priya_raman",
        "lukas_vogt",
        "mei_tanaka",
        "daniel_okafor"
      ],
      "text": "Lab meeting concluded: consensus to pursue TP53, PRMT5, MAT2A as MTAP-null synthetic lethal candidates for arrayed validation."
    },
    {
      "t": "2024-09-18T09:22:00Z",
      "kind": "email",
      "entity_ids": [
        "msg_email_0918",
        "lukas_vogt",
        "mei_tanaka"
      ],
      "text": "Work split assigned between Lukas and Mei for validation of PRMT5 and MAT2A respectively."
    }
  ],
  "expected_mutations": [
    {
      "verb": "add_reflection",
      "reflection_id": "refl_mtap_synthlethal_hits",
      "summary": "The Raman Lab's CRISPR-Cas12a tiling screen v3 in MTAP-null HEK293T identified a coherent cluster of three synthetic-lethal hits \u2014 TP53, PRMT5, and MAT2A \u2014 discussed at the 2024-09-17 lab meeting and now entering arrayed validation (Lukas: PRMT5; Mei: MAT2A).",
      "source_ids": [
        "fact_tp53_hit",
        "fact_prmt5_hit",
        "fact_mat2a_hit",
        "crispr_screen_v3",
        "lab_meeting_0917"
      ],
      "rationale": "Three screen hits, the screen object itself, and the decisional meeting form a natural cluster; reflecting on them lets future queries resolve 'MTAP synthetic-lethal program' in one hop."
    },
    {
      "verb": "add_link",
      "from_id": "refl_mtap_synthlethal_hits",
      "to_id": "raman_lab",
      "rel_type": "REFLECTS_ON",
      "weight": 0.7,
      "rationale": "The program belongs to the Raman Lab; linking the reflection to the lab supports org-scoped retrieval."
    }
  ],
  "qa_pairs": [
    {
      "q": "What MTAP synthetic-lethal program is the Raman Lab pursuing?",
      "gold_node_ids": [
        "refl_mtap_synthlethal_hits",
        "raman_lab",
        "fact_tp53_hit",
        "fact_prmt5_hit",
        "fact_mat2a_hit"
      ],
      "gold_rel_triples": [
        [
          "refl_mtap_synthlethal_hits",
          "REFLECTS_ON",
          "raman_lab"
        ]
      ]
    },
    {
      "q": "Which lab is running the CRISPR-Cas12a tiling screen v3?",
      "gold_node_ids": [
        "raman_lab",
        "crispr_screen_v3"
      ],
      "gold_rel_triples": []
    }
  ],
  "rationale": "The three MTAP-null hit facts, the screen object, and the lab meeting that converted them into a validation plan form a tight thematic cluster. Creating a Reflection that summarises this program and linking it to the Raman Lab gives downstream retrieval a single high-signal node that answers program-level questions without having to traverse individual fact/message nodes."
}
```

## Example 3 — scenario_type=no_op, theme=molecular biology research group

```json
{
  "scenario_type": "no_op",
  "theme": "molecular biology research group",
  "graph_snapshot_cypher": "CREATE (p1:Person {id:'dr_elena_marsh', name:'Dr. Elena Marsh', role:'Principal Investigator'});\nCREATE (p2:Person {id:'rohan_patel', name:'Rohan Patel', role:'Postdoctoral Researcher'});\nCREATE (p3:Person {id:'yuki_tanaka', name:'Yuki Tanaka', role:'PhD Student'});\nCREATE (p4:Person {id:'mira_osei', name:'Mira Osei', role:'Lab Technician'});\nCREATE (o1:Org {id:'marsh_lab', name:'Marsh Laboratory for RNA Biology'});\nCREATE (o2:Org {id:'uc_davis_mcb', name:'UC Davis Department of Molecular and Cellular Biology'});\nCREATE (pl1:Place {id:'briggs_hall_314', name:'Briggs Hall Room 314'});\nCREATE (pl2:Place {id:'uc_davis_campus', name:'UC Davis Campus'});\nCREATE (obj1:Object {id:'confocal_microscope_lsm980', name:'Zeiss LSM 980 Confocal Microscope'});\nCREATE (obj2:Object {id:'qpcr_cfx96', name:'Bio-Rad CFX96 qPCR System'});\nCREATE (f1:Fact {id:'fact_crispr_protocol', content:'Lab standard CRISPR-Cas13 knockdown protocol uses 50nM gRNA in HEK293T cells'});\nCREATE (f2:Fact {id:'fact_lab_meeting', content:'Weekly lab meetings occur Tuesdays at 10am in Briggs Hall 314'});\nCREATE (ev1:Event {id:'lab_meeting_2024_11_12', name:'Weekly Lab Meeting', date:'2024-11-12'});\nCREATE (pref1:Preference {id:'elena_pref_slack', content:'Dr. Marsh prefers Slack over email for quick questions'});\nCREATE (p1)-[:EMPLOYED_BY {weight:0.95}]->(o2);\nCREATE (p2)-[:MEMBER_OF {weight:0.9}]->(o1);\nCREATE (p3)-[:MEMBER_OF {weight:0.9}]->(o1);\nCREATE (p4)-[:MEMBER_OF {weight:0.9}]->(o1);\nCREATE (p1)-[:MEMBER_OF {weight:1.0}]->(o1);\nCREATE (o1)-[:SUBSIDIARY_OF {weight:0.9}]->(o2);\nCREATE (o1)-[:LOCATED_AT {weight:1.0}]->(briggs_hall_314);\nCREATE (briggs_hall_314)-[:LOCATED_AT {weight:1.0}]->(pl2);\nCREATE (o1)-[:OWNS {weight:0.8}]->(obj1);\nCREATE (o1)-[:OWNS {weight:0.8}]->(obj2);\nCREATE (p3)-[:USES {weight:0.7}]->(obj1);\nCREATE (p2)-[:USES {weight:0.7}]->(obj2);\nCREATE (ev1)-[:OCCURRED_AT {weight:1.0}]->(briggs_hall_314);\nCREATE (p1)-[:PARTICIPATED_IN {weight:1.0}]->(ev1);\nCREATE (p2)-[:PARTICIPATED_IN {weight:1.0}]->(ev1);\nCREATE (p3)-[:PARTICIPATED_IN {weight:1.0}]->(ev1);\nCREATE (p4)-[:PARTICIPATED_IN {weight:1.0}]->(ev1);\nCREATE (ev1)-[:MENTIONS {weight:0.6}]->(f1);\nCREATE (f2)-[:RELATED_TO {weight:0.8}]->(briggs_hall_314)",
  "events_since_last_tick": [
    {
      "t": "2024-11-19T10:00:00-08:00",
      "kind": "calendar_event",
      "entity_ids": [
        "lab_meeting_2024_11_12",
        "briggs_hall_314"
      ],
      "text": "Weekly lab meeting held as scheduled in Briggs Hall 314; attendance matched prior week."
    },
    {
      "t": "2024-11-19T14:30:00-08:00",
      "kind": "instrument_log",
      "entity_ids": [
        "yuki_tanaka",
        "confocal_microscope_lsm980"
      ],
      "text": "Yuki booked the LSM 980 for routine imaging of HEK293T samples, consistent with ongoing thesis work."
    }
  ],
  "expected_mutations": [],
  "qa_pairs": [
    {
      "q": "Who is the PI of the Marsh Laboratory?",
      "gold_node_ids": [
        "dr_elena_marsh",
        "marsh_lab"
      ],
      "gold_rel_triples": []
    },
    {
      "q": "What microscope is Yuki using for imaging?",
      "gold_node_ids": [
        "yuki_tanaka",
        "confocal_microscope_lsm980"
      ],
      "gold_rel_triples": []
    }
  ],
  "rationale": "The incoming events (routine weekly meeting, routine microscope booking) are fully consistent with edges already in the graph. No new links, merges, reflections, or weight adjustments are warranted since every entity and relationship implied by the events is already accurately represented."
}
```

# Final instruction

Emit one JSON object matching the schema above. No markdown fences, no commentary.
