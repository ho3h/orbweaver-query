"""Teacher-model client: asks Claude Opus 4.7 to invent structured training
scenarios for orbweaver.

Design choices:
- **Claude Opus 4.7** — adaptive thinking, no sampling params.
- **Prompt caching** on the large fixed system prompt. `cache_control:
  {type: "ephemeral"}` is set on the system block. Since D-013, the system
  prompt is ~6.6K tokens (base rules + 3 few-shot pilot examples loaded
  from `teacher_examples.md`), comfortably over Opus 4.7's 4096-token
  cacheable-prefix minimum. Expect `cache_read_input_tokens > 0` after
  the first call.
- **Batch API** — 50% cost reduction, results within 1h typically. Fine for
  an overnight dataset build.
- **Structured outputs via prompt-only JSON** (no `output_config.format`) +
  Pydantic validation on the client side. Anthropic's strict JSON-schema
  mode requires `additionalProperties: false` on every object, which
  collides with our open-shape events and mutation union. The prompt is
  tight enough that Opus 4.7 emits valid JSON without the constraint.
- **Diversity via theme + request_id** — Opus 4.7 has no temperature, so
  deterministic-input gives deterministic output. We vary the user prompt
  with theme strings and unique request ids to get scenario diversity.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path

from pydantic import BaseModel, Field


# ---------- Pydantic schemas ----------

class QAPair(BaseModel):
    """A Q&A pair grounded in the scenario graph. Used to measure F1-delta."""
    q: str
    gold_node_ids: list[str] = Field(description="node ids that SHOULD be retrieved")
    gold_rel_triples: list[list[str]] = Field(
        default_factory=list,
        description="[[from_id, rel_type, to_id], ...] that should be retrieved",
    )


class TrainingScenario(BaseModel):
    """One training example. The teacher returns this; we validate, F1-filter,
    then pack into our SFT JSONL format."""
    scenario_type: str
    theme: str
    graph_snapshot_cypher: str = Field(description="valid Cypher CREATE statements separated by ';\\n'")
    events_since_last_tick: list[dict] = Field(
        description="recent activity motivating the mutations",
    )
    expected_mutations: list[dict] = Field(
        description="five-verb mutation array; each dict has `verb` and verb-specific fields",
    )
    qa_pairs: list[QAPair] = Field(
        min_length=2, max_length=5,
        description="Q&A that the mutations should help retrieval answer",
    )
    rationale: str = Field(description="why these mutations help")


# ---------- config ----------

MODEL = "claude-opus-4-7"

SCENARIO_TYPES: list[str] = [
    "implicit_link",        # two nodes should be linked; orbweaver adds add_link
    "duplicate_entity",     # two nodes are the same; orbweaver adds merge_entities
    "cluster_reflection",   # dense cluster; orbweaver adds a Reflection node
    "weight_reinforcement", # existing edge accumulated evidence; adjust_weight
    "stale_deprecation",    # fact became obsolete; deprecate
    "no_op",                # nothing warrants a change (teaches restraint)
]

THEMES: list[str] = [
    "tech startup engineering team",
    "molecular biology research group",
    "family household with teenagers",
    "local newsroom",
    "hospital ward nursing staff",
    "university physics department",
    "nonprofit fundraising campaign",
    "small law firm partner meetings",
    "restaurant daily operations",
    "indie game studio design chats",
    "freelance UX designer client portfolio",
    "open-source library maintainers",
    "community bookclub",
    "apartment building residents",
    "youth soccer club coaches",
    "podcast production team",
]


# ---------- system prompt (the cached prefix) ----------

SYSTEM_PROMPT = """\
You are the teacher for orbweaver, a Neo4j-graph memory specialist. Your only
job here is to INVENT realistic training scenarios in a strict schema. Each
scenario will be used both as supervised training data and validated via
downstream retrieval-F1 measurement.

# The five-verb mutation vocabulary

orbweaver may emit ONLY these mutations. Every one is invertible; no DELETE.

1. add_link
   {"verb": "add_link", "from_id": str, "to_id": str, "rel_type": "UPPER_SNAKE",
    "weight": float 0.0-1.0, "rationale": str}
   Adds a directed relationship. Use when two existing nodes should be
   connected based on evidence in the graph or events.

2. add_reflection
   {"verb": "add_reflection", "reflection_id": str, "summary": str,
    "source_ids": [str, ...] (>=2), "rationale": str}
   Creates a new :Reflection node that summarises a cluster of related
   nodes. The source_ids list the nodes it reflects on.

3. merge_entities
   {"verb": "merge_entities", "dup_id": str, "canonical_id": str,
    "confidence": float 0.0-1.0, "rationale": str}
   Asserts dup_id and canonical_id are the same entity. Soft merge via
   SAME_AS edge; the original nodes stay in place.

4. adjust_weight
   {"verb": "adjust_weight", "from_id": str, "to_id": str, "rel_type": str,
    "delta": float (additive, can be negative), "rationale": str}
   Reinforces or decays an existing edge. The edge must exist.

5. deprecate
   {"verb": "deprecate", "target_kind": "node" | "relationship",
    "target_id": str (for relationships: "from_id|REL_TYPE|to_id"),
    "reason": str, "rationale": str}
   Soft-deletes. Subsequent reads can filter by the `deprecated=true` flag.

# POLE+O schema (use these labels and relationship types)

Node labels: Person, Org, Place, Event, Object, Message, Preference, Fact,
             Reflection (only created by orbweaver; do not pre-seed).

Relationship types: KNOWS, EMPLOYED_BY, MEMBER_OF, LOCATED_AT, PARTICIPATED_IN,
                    OCCURRED_AT, OWNS, USES, MENTIONS, RELATED_TO, SAME_AS,
                    ALIAS_OF, SUBSIDIARY_OF, PARTNER_WITH, REFLECTS_ON.

Every node must have an `id` property (lowercase snake_case, unique within the
scenario) and, for Persons/Orgs/Places, a `name`. Messages have `content`.
Every relationship may carry a `weight` in [0,1].

# Scenario shape

You return a TrainingScenario JSON object with these fields:

- scenario_type: one of implicit_link | duplicate_entity | cluster_reflection
                 | weight_reinforcement | stale_deprecation | no_op
- theme: a short tag, e.g. "newsroom"
- graph_snapshot_cypher: valid Cypher CREATE statements, 8 to 25 nodes, no
  trailing semicolons; separate statements with ';\\n' exactly. Do NOT create
  any Reflection nodes; orbweaver does that.
- events_since_last_tick: 1-3 items, each {"t": ISO8601, "kind": str,
  "entity_ids": [str], optionally "text": str}. These motivate the mutations.
- expected_mutations: 0-5 mutation objects (see vocabulary above). For `no_op`
  scenarios, return an empty list. All referenced ids must exist in the graph
  (exceptions: add_reflection.reflection_id is new).
- qa_pairs: 2-5 Q&A objects that the mutations should help answer. Each has
  `q`, `gold_node_ids` (node ids), `gold_rel_triples` ([[from,type,to]]).
- rationale: 1-3 sentences explaining why the mutations help.

# Critical rules

- Emit JSON only, no markdown fences, no commentary.
- Every id used in mutations or qa_pairs MUST exist in the graph snapshot
  (or, for add_reflection, be unique and not conflict).
- Keep rel_types UPPER_SNAKE_CASE only.
- Favor realism: use natural-sounding names, plausible dates, coherent
  relationships. Avoid Alice/Bob/Charlie unless the theme calls for it.
- For `no_op` scenarios, the graph must be internally consistent with no
  obvious gaps to close; the events describe benign activity.

If you cannot satisfy the schema, return a minimal valid scenario rather than
invalid output. The downstream pipeline will reject examples whose mutations
fail validation or fail to improve retrieval F1.
"""

# Load 3 few-shot examples (pulled from validated pilot outputs). Appending
# them pushes the prompt past Opus 4.7's 4096-token cacheable-prefix floor
# so cache hits activate from the second call onwards (D-013). Examples are
# kept in a separate file to keep this module scannable.
_FEW_SHOT = (Path(__file__).parent / "teacher_examples.md").read_text()
SYSTEM_PROMPT = SYSTEM_PROMPT.rstrip() + "\n\n" + _FEW_SHOT


# ---------- request building ----------

def _user_prompt(scenario_type: str, theme: str, request_id: str) -> str:
    return (
        f"# Request\n\n"
        f"request_id: {request_id}\n"
        f"scenario_type: {scenario_type}\n"
        f"theme: {theme}\n\n"
        f"Invent one scenario matching the schema. Be concrete and specific. "
        f"Emit only the JSON object, nothing else."
    )


def build_batch_request(*, custom_id: str, scenario_type: str, theme: str) -> dict:
    """Produce a Batches API Request dict.

    We intentionally do NOT pass `output_config.format` here. Anthropic's
    strict JSON-schema mode requires `additionalProperties: false` on every
    object, which forces us to fully specify each of the five verb shapes
    as a discriminated `oneOf` plus fixed event shapes. Not worth the schema
    maintenance for a dataset builder that already validates with Pydantic
    downstream. The system prompt instructs JSON-only output; Opus 4.7
    follows this reliably. Malformed outputs are simply dropped by the
    filter step."""
    request_id = uuid.uuid4().hex[:12]
    params = {
        "model": MODEL,
        "max_tokens": 16000,
        "thinking": {"type": "adaptive"},
        "output_config": {"effort": "high"},
        "system": [
            {
                "type": "text",
                "text": SYSTEM_PROMPT,
                "cache_control": {"type": "ephemeral"},  # silent no-op below 4096 tokens (see docstring)
            }
        ],
        "messages": [
            {
                "role": "user",
                "content": _user_prompt(scenario_type, theme, request_id),
            }
        ],
    }
    return {"custom_id": custom_id, "params": params}


# ---------- response parsing ----------

def extract_json_text(message_content: list[dict]) -> str:
    """Pull the JSON payload out of an Anthropic message content list."""
    for block in message_content:
        btype = block.get("type") if isinstance(block, dict) else getattr(block, "type", None)
        if btype == "text":
            return block.get("text") if isinstance(block, dict) else block.text
    raise ValueError("no text block in message content")


def parse_scenario(raw_text: str) -> TrainingScenario:
    """Parse raw JSON text into a validated TrainingScenario.

    Handles the common case of the model wrapping output in markdown code
    fences despite the system prompt's explicit "no fences" rule — we strip
    them rather than reject."""
    t = raw_text.strip()
    if t.startswith("```"):
        # Strip opening fence (possibly with language tag) and closing fence
        first_nl = t.find("\n")
        if first_nl > 0:
            t = t[first_nl + 1:]
        if t.endswith("```"):
            t = t[: -3].rstrip()
    data = json.loads(t)
    return TrainingScenario.model_validate(data)


# ---------- batch orchestration ----------

def submit_batch(requests: list[dict]):
    """Submit a batch and return the SDK batch object. Lazy-imports anthropic
    so the module imports cleanly without the `teacher` extra."""
    import anthropic
    from anthropic.types.message_create_params import MessageCreateParamsNonStreaming
    from anthropic.types.messages.batch_create_params import Request

    client = anthropic.Anthropic()

    sdk_requests = [
        Request(
            custom_id=r["custom_id"],
            params=MessageCreateParamsNonStreaming(**r["params"]),
        )
        for r in requests
    ]
    return client.messages.batches.create(requests=sdk_requests)


def poll_until_done(batch_id: str, *, poll_every: int = 60):
    """Poll a batch until it finishes. Returns the final batch object."""
    import anthropic
    client = anthropic.Anthropic()
    while True:
        b = client.messages.batches.retrieve(batch_id)
        if b.processing_status == "ended":
            return b
        counts = b.request_counts
        print(
            f"[teacher] batch {batch_id} status={b.processing_status} "
            f"processing={counts.processing} succeeded={counts.succeeded} "
            f"errored={counts.errored}",
            flush=True,
        )
        time.sleep(poll_every)


def iter_results(batch_id: str):
    """Stream batch results. Yields (custom_id, status, content_or_error, usage)."""
    import anthropic
    client = anthropic.Anthropic()
    for result in client.messages.batches.results(batch_id):
        rtype = result.result.type
        if rtype == "succeeded":
            msg = result.result.message
            # msg.content is a list of blocks; keep usage for cache-hit reporting
            yield result.custom_id, "succeeded", msg.content, msg.usage
        else:
            err = getattr(result.result, "error", None)
            yield result.custom_id, rtype, err, None


# ---------- smoke-test entry point (single-request, not batch) ----------

def single_call_smoke(scenario_type: str = "implicit_link", theme: str = THEMES[0]) -> TrainingScenario:
    """One synchronous call for smoke-testing the prompt. Use this to verify
    the teacher emits valid JSON before spending on a 300-request batch."""
    import anthropic
    client = anthropic.Anthropic()
    req = build_batch_request(custom_id="smoke", scenario_type=scenario_type, theme=theme)
    msg = client.messages.create(**req["params"])
    print(f"[teacher] usage: input={msg.usage.input_tokens} "
          f"output={msg.usage.output_tokens} "
          f"cache_read={getattr(msg.usage, 'cache_read_input_tokens', 0)} "
          f"cache_creation={getattr(msg.usage, 'cache_creation_input_tokens', 0)}",
          flush=True)
    text = next(b.text for b in msg.content if b.type == "text")
    return parse_scenario(text)


if __name__ == "__main__":
    # python -m orbweaver.teacher → single smoke-test request
    if not os.getenv("ANTHROPIC_API_KEY"):
        raise SystemExit("ANTHROPIC_API_KEY not set")
    scen = single_call_smoke()
    print(json.dumps(scen.model_dump(), indent=2)[:2000])
