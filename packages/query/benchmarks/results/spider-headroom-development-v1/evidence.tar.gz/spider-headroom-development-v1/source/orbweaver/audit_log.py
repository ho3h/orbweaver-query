"""HITL audit-node primitive — the (:Edit) backbone of orbweaver's reviewer
queue. Per third compass artifact §1, then pivoted v1.0 to preview-first
semantics:

  Staged    — the daemon proposed an edit; SUGGESTED_<TYPE> artifacts (or
              proposal properties) live in the graph; canonical state is
              UNCHANGED. Awaiting review.
  Applied   — reviewer accepted; promote_cypher ran, canonical edge now
              live, SUGGESTED_ artifacts deleted. decided_by/decided_ts set.
  Rejected  — reviewer rejected; reject_cypher ran, SUGGESTED_ artifacts
              deleted; canonical state never touched. decided_by/decided_ts
              and rejection_reason set.

Why preview-first instead of trust-fall: a reviewer queue means the human
is the source of authority. We do not mutate canonical state on stage, only
on accept. This is what makes the (:Edit) row auditable BEFORE the change
lands rather than after. See docs/PROTOCOL.md.

## Transaction semantics

emit_staged(): one transaction. Run staged_cypher (writes SUGGESTED_), then
              CREATE (:Edit {status:'Staged', staged_cypher, promote_cypher,
              reject_cypher, signals_json, ...}).

promote():    one transaction. Run promote_cypher (translates SUGGESTED_<T>
              into canonical T, deletes the SUGGESTED_ rel), then SET the
              :Edit status='Applied', decided_by, decided_ts.

reject():     one transaction. Run reject_cypher (deletes SUGGESTED_
              artifacts), then SET status='Rejected', decided_by,
              decided_ts, rejection_reason.

All three are ACID at single-database scope — exactly what AuraDB Free
supports without paid CDC or custom JARs.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

# Schema migration — run once via apply_schema_migration() on a fresh
# Neo4j instance to install the constraints + index that the audit
# pattern depends on.
SCHEMA_MIGRATION_CYPHER: list[str] = [
    "CREATE CONSTRAINT orbweaver_edit_id IF NOT EXISTS "
    "FOR (e:Edit) REQUIRE e.id IS UNIQUE",
    "CREATE INDEX orbweaver_edit_status IF NOT EXISTS "
    "FOR (e:Edit) ON (e.status)",
    "CREATE INDEX orbweaver_edit_ts IF NOT EXISTS "
    "FOR (e:Edit) ON (e.ts)",
]


@dataclass
class StagedEdit:
    """An edit the daemon has proposed. Caller builds the three Cypher
    strings via mutations.to_cypher(staged=True), to_promote_cypher(), and
    to_reject_cypher() — this dataclass is purely a transport object.
    """
    edit_id: str
    verb: str
    staged_cypher: str
    staged_params: dict[str, Any]
    promote_cypher: str
    promote_params: dict[str, Any]
    reject_cypher: str
    reject_params: dict[str, Any]
    confidence: float
    target_id: str = ""
    subgraph_id: str = ""
    rationale: str = ""
    signals_json: str = "{}"
    graph_snapshot_cypher: str = ""
    events_json: str = "[]"
    prediction_set_json: str = "[]"
    mutation_json: str = "{}"
    status: str = "Staged"
    ts: float = field(default_factory=time.time)
    extras: dict[str, Any] = field(default_factory=dict)

    def to_props(self) -> dict[str, Any]:
        """Properties for the (:Edit) node. Stored as primitives + JSON
        blobs so AuraDB's property-type constraints stay happy."""
        return {
            "id": self.edit_id,
            "verb": self.verb,
            "staged_cypher": self.staged_cypher,
            "staged_params_json": json.dumps(self.staged_params, separators=(",", ":")),
            "promote_cypher": self.promote_cypher,
            "promote_params_json": json.dumps(self.promote_params, separators=(",", ":")),
            "reject_cypher": self.reject_cypher,
            "reject_params_json": json.dumps(self.reject_params, separators=(",", ":")),
            "confidence": float(self.confidence),
            "target_id": self.target_id,
            "subgraph_id": self.subgraph_id,
            "rationale": self.rationale[:1024],
            "signals_json": self.signals_json,
            "graph_snapshot_cypher": self.graph_snapshot_cypher,
            "events_json": self.events_json,
            "prediction_set_json": self.prediction_set_json,
            "mutation_json": self.mutation_json,
            "status": self.status,
            "ts": float(self.ts),
            "extras_json": json.dumps(self.extras, separators=(",", ":")),
        }


def new_edit_id() -> str:
    """ULID-shaped id (timestamp-prefixed for ordering)."""
    return f"orb-{int(time.time()*1000):014d}-{uuid.uuid4().hex[:10]}"


# ---------- driver-agnostic interface ----------
#
# We don't bind to neo4j.GraphDatabase here so this module works under
# both the official Python driver and any test stub that exposes
# `.session()` + `session.run(query, **params)`.

def apply_schema_migration(driver_or_session) -> None:
    """Run the (:Edit) + (:Probe) constraints + indexes. Idempotent.

    (:Probe) is the ECHO-inspired weak-supervision substrate added in v1.2;
    see orbweaver/probes.py for the full conceptual lineage.
    """
    from .probes import PROBE_SCHEMA_MIGRATION_CYPHER
    sess = _coerce_session(driver_or_session)
    with sess as s:
        for stmt in SCHEMA_MIGRATION_CYPHER:
            s.run(stmt)
        for stmt in PROBE_SCHEMA_MIGRATION_CYPHER:
            s.run(stmt)


def emit_staged(driver_or_session, edit: StagedEdit) -> str:
    """Run staged_cypher (writes SUGGESTED_ artifacts) + create (:Edit) audit
    node, both in one transaction. Returns the edit_id. Raises on Cypher
    errors (transaction rolls back; nothing applied).

    v1.1 idempotency: an active edit with the same verb+target wins. This
    keeps cron-driven `tend --once` from restaging the same suggestion with a
    fresh id on every tick.
    """
    sess = _coerce_session(driver_or_session)
    with sess as s:
        with s.begin_transaction() as tx:
            if edit.target_id:
                existing = tx.run(
                    "MATCH (e:Edit) "
                    "WHERE e.verb = $verb AND e.target_id = $target_id "
                    "  AND e.status IN ['Staged', 'Applied'] "
                    "RETURN e.id AS id ORDER BY e.ts DESC LIMIT 1",
                    verb=edit.verb, target_id=edit.target_id,
                ).single()
                if existing is not None:
                    tx.commit()
                    return existing["id"]
            tx.run(edit.staged_cypher, **edit.staged_params)
            tx.run("CREATE (e:Edit $props)", props=edit.to_props())
            tx.commit()
    return edit.edit_id


def list_staged(driver_or_session, limit: int = 100) -> list[dict]:
    sess = _coerce_session(driver_or_session)
    with sess as s:
        result = s.run(
            "MATCH (e:Edit {status: 'Staged'}) "
            "RETURN e ORDER BY e.ts DESC LIMIT $limit",
            limit=int(limit),
        )
        return [dict(r["e"]) for r in result]


def promote(driver_or_session, edit_id: str, *, decided_by: str = "reviewer") -> None:
    """Staged → Applied. Runs the stored promote_cypher (translates
    SUGGESTED_<T> → canonical T, deletes the SUGGESTED_ rel), then sets
    status=Applied, decided_by, decided_ts.
    """
    sess = _coerce_session(driver_or_session)
    with sess as s:
        with s.begin_transaction() as tx:
            row = tx.run(
                "MATCH (e:Edit {id: $id, status: 'Staged'}) "
                "RETURN e.promote_cypher AS cy, e.promote_params_json AS params",
                id=edit_id,
            ).single()
            if row is None:
                raise LookupError(f"no staged edit with id {edit_id!r}")
            promote_cypher = row["cy"]
            promote_params = json.loads(row["params"]) if row["params"] else {}
            if promote_cypher:
                tx.run(promote_cypher, **promote_params)
            tx.run(
                "MATCH (e:Edit {id: $id}) "
                "SET e.status = 'Applied', "
                "    e.decided_by = $decided_by, "
                "    e.decided_ts = timestamp() / 1000.0",
                id=edit_id, decided_by=decided_by[:128],
            )
            tx.commit()


def reject(driver_or_session, edit_id: str, *, decided_by: str = "reviewer",
           reason: str = "") -> None:
    """Staged → Rejected. Runs the stored reject_cypher (deletes SUGGESTED_
    artifacts), then sets status=Rejected, decided_by, decided_ts,
    rejection_reason. Canonical graph is untouched (staged Cypher never
    wrote it under HITL semantics).
    """
    sess = _coerce_session(driver_or_session)
    with sess as s:
        with s.begin_transaction() as tx:
            row = tx.run(
                "MATCH (e:Edit {id: $id, status: 'Staged'}) "
                "RETURN e.reject_cypher AS cy, e.reject_params_json AS params",
                id=edit_id,
            ).single()
            if row is None:
                raise LookupError(f"no staged edit with id {edit_id!r}")
            reject_cypher = row["cy"]
            reject_params = json.loads(row["params"]) if row["params"] else {}
            if reject_cypher:
                tx.run(reject_cypher, **reject_params)
            tx.run(
                "MATCH (e:Edit {id: $id}) "
                "SET e.status = 'Rejected', "
                "    e.decided_by = $decided_by, "
                "    e.decided_ts = timestamp() / 1000.0, "
                "    e.rejection_reason = $reason",
                id=edit_id, decided_by=decided_by[:128], reason=reason[:512],
            )
            tx.commit()


def undo(driver_or_session, edit_id: str, *, decided_by: str = "reviewer") -> None:
    """Applied → Undone. Reverses an already-promoted edit. Reads the
    promoted edge metadata (recorded via from_edit_id) and deletes the
    canonical edge — leaving the (:Edit) row marked Undone for forensic
    history. Caller is responsible for ensuring the canonical edge actually
    exists; if it was further mutated, undo may fail or partial-undo.
    """
    sess = _coerce_session(driver_or_session)
    with sess as s:
        with s.begin_transaction() as tx:
            row = tx.run(
                "MATCH (e:Edit {id: $id, status: 'Applied'}) "
                "RETURN e.verb AS verb, e.staged_params_json AS params",
                id=edit_id,
            ).single()
            if row is None:
                raise LookupError(f"no applied edit with id {edit_id!r}")
            _ = row["verb"]  # could dispatch per-verb undo logic in v1.x
            # Find and delete the canonical edge that carries this edit_id
            # as its from_edit_id property. Generic across verbs that produce
            # an edge tied back to the (:Edit).
            tx.run(
                "MATCH ()-[r {from_edit_id: $id}]->() DELETE r",
                id=edit_id,
            )
            tx.run(
                "MATCH (e:Edit {id: $id}) "
                "SET e.status = 'Undone', "
                "    e.undone_by = $decided_by, "
                "    e.undone_ts = timestamp() / 1000.0",
                id=edit_id, decided_by=decided_by[:128],
            )
            tx.commit()


def stats(driver_or_session) -> dict[str, int]:
    """Counts by status — useful for the daily reversal-rate canary."""
    sess = _coerce_session(driver_or_session)
    with sess as s:
        result = s.run(
            "MATCH (e:Edit) "
            "RETURN e.status AS status, count(*) AS n"
        )
        return {row["status"]: int(row["n"]) for row in result}


def reversal_rate_24h(driver_or_session) -> float:
    """Compass §2 canary: trip the kill switch if rolling 24h reversal > 5%.

    Counts edits emitted in the last 24h, then computes
        (rejected + undone) / total
    """
    sess = _coerce_session(driver_or_session)
    cutoff = time.time() - 24 * 3600
    with sess as s:
        result = s.run(
            "MATCH (e:Edit) WHERE e.ts >= $cutoff "
            "RETURN e.status AS status, count(*) AS n",
            cutoff=cutoff,
        )
        counts = {row["status"]: int(row["n"]) for row in result}
    total = sum(counts.values())
    if total == 0:
        return 0.0
    return (counts.get("Rejected", 0) + counts.get("Undone", 0)) / total


# ---------- helper ----------

def _coerce_session(x):
    """Accept either a driver or a session-context-manager. Returns
    something that behaves like a context manager yielding a session."""
    if hasattr(x, "session"):
        return x.session()
    return x
