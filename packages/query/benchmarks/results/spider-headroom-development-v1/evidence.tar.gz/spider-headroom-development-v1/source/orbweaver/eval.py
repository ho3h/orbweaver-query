"""The one metric: retrieval-F1 delta before vs after applying mutations.

This is the training signal AND the production health signal. Keep it
deterministic and cheap — we call it thousands of times during RL.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .mutations import Mutation
from .neo4j_sandbox import SandboxHandle, apply_mutations, load_cypher, sandbox


@dataclass
class QAPair:
    q: str
    # Ground-truth: list of node ids (and/or relationship (from,type,to) triples)
    # that SHOULD be in the retrieved context for this question.
    gold_node_ids: list[str] = field(default_factory=list)
    gold_rel_triples: list[tuple[str, str, str]] = field(default_factory=list)


@dataclass
class EvalResult:
    # Primary metric: Recall@K. Monotone non-decreasing when orbweaver fills
    # real gaps (as long as retrieval budget K isn't exhausted). This is the
    # training and production health signal.
    f1_before: float       # recall-based "F1" — retained name for backcompat, computed via _score
    f1_after: float
    delta: float
    per_q_before: list[float]
    per_q_after: list[float]
    health_before: dict
    health_after: dict


# ---------- retrieval scorer ----------

def retrieve(handle: SandboxHandle, question: str, *, k: int = 20) -> dict:
    """Minimal retrieval: find seed nodes whose name/summary/content contains
    a question keyword; include their 1-hop non-deprecated neighbours and the
    edges between seeds and neighbours.

    Dumber than a real vector-retrieval pipeline, but deterministic and it
    actually rewards orbweaver for the right things — adding a KNOWS edge
    pulls a new triple into the retrieved set; adding a SAME_AS edge ditto.
    Swap this out for `MemoryClient.get_context()` when wiring up to the
    real `neo4j-labs/agent-memory`.
    """
    keywords = [w for w in _tokenize(question) if len(w) > 2]
    if not keywords:
        return {"node_ids": [], "rel_triples": []}
    with handle.session() as s:
        rec = s.run(
            """
            MATCH (n)
            WHERE coalesce(n.deprecated, false) = false
              AND any(kw IN $kw WHERE
                    toLower(coalesce(n.name, '')) CONTAINS kw OR
                    toLower(coalesce(n.summary, '')) CONTAINS kw OR
                    toLower(coalesce(n.content, '')) CONTAINS kw)
            WITH collect(DISTINCT n) AS seeds
            UNWIND seeds AS s
            OPTIONAL MATCH (s)-[r]-(m)
            WHERE r IS NULL OR (coalesce(r.deprecated, false) = false
                                 AND coalesce(m.deprecated, false) = false)
            WITH collect(DISTINCT s.id) AS seed_ids,
                 collect(DISTINCT m.id) AS neighbor_ids,
                 collect(DISTINCT
                   CASE WHEN r IS NOT NULL
                        THEN [startNode(r).id, type(r), endNode(r).id]
                        ELSE NULL END
                 ) AS triples
            RETURN seed_ids[..$k] + neighbor_ids[..$k] AS node_ids,
                   [t IN triples WHERE t IS NOT NULL][..$k] AS triples
            """,
            kw=keywords, k=k,
        ).single()
        node_ids = [x for x in (rec["node_ids"] if rec else []) if x]
        triples = [tuple(t) for t in (rec["triples"] if rec else [])]
    return {"node_ids": node_ids, "rel_triples": triples}


def f1_one(gold_nodes: list[str], gold_rels: list[tuple[str, str, str]],
           ret_nodes: list[str], ret_rels: list[tuple[str, str, str]],
           *, k: int = 50) -> float:
    """Primary metric. Recall@K with mild precision penalty for overflowing K.

    Honest retrieval scoring on a graph where the upstream retriever is dumb
    (keyword + 1-hop) has to tolerate over-retrieval. Pure F1 would punish
    orbweaver for adding any edge, since the stub retriever surfaces all
    1-hop edges whether they help the question or not. Pure recall would
    reward orbweaver for dumping the whole graph. The compromise: recall
    up to K retrieved items, then degrade smoothly.
    """
    gold = set(gold_nodes) | {f"{a}|{t}|{b}" for a, t, b in gold_rels}
    pred = set(ret_nodes) | {f"{a}|{t}|{b}" for a, t, b in ret_rels}
    if not gold:
        return 1.0 if not pred else 0.0
    if not pred:
        return 0.0
    # Recall@K: what fraction of gold is in the top-K of pred (we treat all
    # retrieved items as equally ranked, so K is a hard cap).
    recall = len(gold & pred) / len(gold)
    # Smooth overflow penalty: no penalty while |pred| <= K, then linear decay
    # reaching 0.5× at |pred|=2K, floor at 0.25×.
    if len(pred) <= k:
        overflow = 1.0
    else:
        overflow = max(0.25, 1.0 - 0.5 * (len(pred) - k) / k)
    return recall * overflow


def run_qa(handle: SandboxHandle, qa: list[QAPair]) -> tuple[float, list[float]]:
    per_q = []
    for pair in qa:
        ret = retrieve(handle, pair.q)
        per_q.append(f1_one(pair.gold_node_ids, pair.gold_rel_triples,
                            ret["node_ids"], ret["rel_triples"]))
    return (sum(per_q) / len(per_q)) if per_q else 0.0, per_q


# ---------- graph health ----------

def graph_health(handle: SandboxHandle) -> dict:
    """Lightweight graph-health snapshot. Each metric is its own query; keeps
    the logic readable and avoids Cypher's brittle chained aggregations."""
    with handle.session() as s:
        nc = s.run("MATCH (n) WHERE coalesce(n.deprecated,false)=false RETURN count(n) AS c").single()["c"]
        rc = s.run(
            "MATCH ()-[r]->() WHERE coalesce(r.deprecated,false)=false RETURN count(r) AS c"
        ).single()["c"]
        oc = s.run(
            "MATCH (n) WHERE coalesce(n.deprecated,false)=false AND NOT (n)--() "
            "RETURN count(n) AS c"
        ).single()["c"]
        dc = s.run("MATCH (n) WHERE coalesce(n.deprecated,false)=true RETURN count(n) AS c").single()["c"]
    return {
        "node_count": nc,
        "relationship_count": rc,
        "orphan_ratio": (oc / nc) if nc else 0.0,
        "deprecated_ratio": (dc / (nc + dc)) if (nc + dc) else 0.0,
    }


# ---------- the one function ----------

def f1_delta(seed_cypher: str, qa: list[QAPair], muts: list[Mutation]) -> EvalResult:
    """seed → clone → score → apply → score → compute delta."""
    with sandbox() as db:
        load_cypher(db, seed_cypher)
        health_before = graph_health(db)
        f1_before, per_q_before = run_qa(db, qa)
        apply_mutations(db, muts, tick_id="eval", ledger=False)
        health_after = graph_health(db)
        f1_after, per_q_after = run_qa(db, qa)
    return EvalResult(
        f1_before=f1_before, f1_after=f1_after, delta=f1_after - f1_before,
        per_q_before=per_q_before, per_q_after=per_q_after,
        health_before=health_before, health_after=health_after,
    )


# ---------- helpers ----------

_STOP = {"what", "which", "who", "where", "when", "how", "the", "and", "about", "with", "did", "does"}

def _tokenize(s: str) -> list[str]:
    import re
    return [t for t in re.findall(r"[a-zA-Z0-9_]+", s.lower()) if t not in _STOP]
