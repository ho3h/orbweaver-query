"""Independent library check of both complete edge-quality evaluations."""

import hashlib
import json
from pathlib import Path

import sklearn
from sklearn.metrics import classification_report, confusion_matrix

run = Path(__file__).resolve().parent
read = lambda name: json.loads((run / name).read_text())
gold = read("truth.json")["labels"]
results = read("results.json")
labels = ["SUPPORT", "CONTRADICT", "NOT_ENOUGH_INFO"]
arms = {"qwen3": read("qwen-predictions.json"),
        "verisci": [json.loads(p.read_text()) for p in sorted((run / "label").glob("*.json"))]}
for name, rows in arms.items():
    assert [r["index"] for r in rows] == list(range(len(gold)))
    predicted = [r["label"] for r in rows]
    report = classification_report(gold, predicted, labels=labels, output_dict=True, zero_division=0)
    assert abs(report["macro avg"]["f1-score"]-results[name]["macro_f1"]) < 1e-12
    assert confusion_matrix(gold, predicted, labels=labels).tolist() == results[name]["confusion_gold_rows"]
    for label in labels:
        for field, reported in (("precision", "precision"), ("recall", "recall"), ("f1-score", "f1")):
            assert abs(report[label][field]-results[name]["classes"][label][reported]) < 1e-12
receipt = {"sklearn_version": sklearn.__version__, "complete_rows_per_arm": len(gold),
           "arms": list(arms), "all_metrics_matched": True,
           "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (run / "independent-metrics.json").open("x") as output:
    json.dump(receipt, output, indent=2, sort_keys=True)
    output.write("\n")
print(json.dumps(receipt))
