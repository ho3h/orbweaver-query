"""External-data composition for Phase 3c per D-016.

Translates bass-materials (Pellissier-Tanon/Suchanek, ESWC 2021) TSV
constraint-correction rows into orbweaver TrainingScenarios. The
bass-materials row schema:

    1  constraint id (statement URI)
    2  revision that fixed the violation
    3  first violation triple subject (Wikidata URI)
    4  first violation triple predicate (Wikidata URI)
    5  first violation triple object (URI or literal)
    6-8 second violation triple (often empty)
    9  separator ("->")
    10-12 first correction triple (subject, predicate, object)
    13 correction type: "<...#addition>" or "<...#deletion>"
    14-16 second correction triple (often empty)
    17 second correction type (often empty)
    18 JSON description of first violation subject
    19 JSON description of first violation object (or "" for literals)
    20 JSON description of second-triple term (or "")

We target the `type` constraint type first — "X has property P with value Y
requires X to be an instance of class C". Corrections are `addition`
operations that add an `instance of` (P31) triple, mapping 1:1 onto our
`add_link` verb with rel_type=INSTANCE_OF.
"""
from __future__ import annotations

import gzip
import json
from pathlib import Path
from typing import Iterator

from .teacher import QAPair, TrainingScenario


# ---------- URI / id helpers ----------

_WD_ENTITY = "http://www.wikidata.org/entity/"
_WD_PROP = "http://www.wikidata.org/prop/direct/"
_ADDITION = "<http://wikiba.se/history/ontology#addition>"
_DELETION = "<http://wikiba.se/history/ontology#deletion>"


def uri_to_id(uri: str) -> str:
    """`<http://...Q123>` -> `q123`. Literals pass through stripped of quotes."""
    s = uri.strip()
    if s.startswith("<") and s.endswith(">"):
        s = s[1:-1]
    for prefix in (_WD_ENTITY, _WD_PROP):
        if s.startswith(prefix):
            return s[len(prefix):].lower()
    # literal: strip wrapping quotes
    return s.strip('"').strip()


def is_literal(uri: str) -> bool:
    s = uri.strip()
    return not (s.startswith("<") and s.endswith(">"))


# ---------- POLE+O label inference ----------
#
# Heuristic P31 → POLE+O label. Uses a small set of common Wikidata classes;
# falls back to Object. The label is used for the Cypher CREATE statement;
# retrieval F1 doesn't depend on the label being exactly right, only on the
# id being consistent, so "good enough" is good enough here.

_TYPE_MAP = {
    # Person
    "q5": "Person", "q215627": "Person",
    # Org
    "q43229": "Org", "q4830453": "Org", "q783794": "Org", "q2085381": "Org",
    "q163740": "Org", "q48204": "Org", "q3918": "Org", "q7278": "Org",
    # Place
    "q486972": "Place", "q515": "Place", "q56061": "Place", "q532": "Place",
    "q3957": "Place", "q1549591": "Place", "q1248784": "Place",
    "q1093829": "Place", "q3957512": "Place", "q735428": "Place",
    # Event
    "q1656682": "Event", "q1190554": "Event",
    # Fact (citations, identifiers, facts)
    "q271": "Fact",
    # Object (films, books, taxons, proteins, ...)
    # Everything not matched falls through to "Object"
}


def infer_pole_label(entity_json: dict) -> str:
    facts = entity_json.get("facts", {}) if entity_json else {}
    p31_vals = facts.get("<http://www.wikidata.org/prop/direct/P31>", []) or []
    for v in p31_vals:
        qid = uri_to_id(v)
        if qid in _TYPE_MAP:
            return _TYPE_MAP[qid]
    return "Object"


def english_name(entity_json: dict) -> str:
    if not entity_json:
        return "?"
    labels = entity_json.get("labels", {})
    for key in ("en", "en-GB", "en-CA"):
        if key in labels:
            return labels[key]
    # Any language
    for v in labels.values():
        return v
    return "?"


# ---------- property / rel_type ----------

# Whitelist of Wikidata properties → POLE+O rel_type. Top-50 most common
# (by appearance in bass-materials train set + general Wikidata frequency).
# Per D-017: ONLY these properties are translated; others are skipped.
# Rationale: synthetic `PROP_P1346` labels poisoned iter 2's verb distribution.
_PROP_REL = {
    # Structural
    "p31": "INSTANCE_OF", "p279": "SUBCLASS_OF",
    "p361": "PART_OF", "p527": "HAS_PART",
    "p463": "MEMBER_OF", "p155": "FOLLOWS", "p156": "FOLLOWED_BY",
    # Geography / location
    "p17": "IN_COUNTRY", "p131": "LOCATED_IN_ADMIN",
    "p150": "CONTAINS_ADMIN", "p625": "HAS_COORDINATES",
    "p625_": "HAS_COORDINATES",  # redundancy-safe
    # Biography / person
    "p569": "BIRTH_DATE", "p570": "DEATH_DATE",
    "p27": "CITIZEN_OF", "p19": "BORN_IN", "p20": "DIED_IN",
    "p106": "OCCUPATION", "p108": "EMPLOYED_BY", "p69": "EDUCATED_AT",
    "p166": "AWARD", "p21": "SEX",
    "p22": "FATHER", "p25": "MOTHER", "p26": "SPOUSE", "p40": "CHILD",
    "p1066": "STUDENT_OF", "p802": "STUDENT",
    "p102": "PARTY_MEMBER", "p39": "HELD_POSITION",
    # Creative works
    "p50": "AUTHOR", "p86": "COMPOSER", "p57": "DIRECTOR",
    "p170": "CREATOR", "p161": "CAST_MEMBER",
    "p175": "PERFORMER", "p264": "RECORD_LABEL",
    "p136": "GENRE", "p577": "PUBLICATION_DATE",
    "p180": "DEPICTS", "p921": "MAIN_SUBJECT", "p800": "NOTABLE_WORK",
    "p138": "NAMED_AFTER", "p840": "NARRATIVE_LOCATION",
    # Politics / org
    "p6": "HEAD_OF_GOVERNMENT", "p35": "HEAD_OF_STATE",
    "p530": "DIPLOMATIC_REL_WITH",
    # Sport
    "p641": "SPORT", "p54": "PLAYED_FOR", "p413": "POSITION", "p118": "LEAGUE",
    # Taxonomy / science (common in Wikidata)
    "p105": "TAXON_RANK", "p171": "PARENT_TAXON",
    "p225": "TAXON_NAME", "p703": "FOUND_IN_TAXON",
    "p680": "MOLECULAR_FUNCTION", "p681": "CELL_COMPONENT",
    "p682": "BIOLOGICAL_PROCESS",
}


def prop_to_rel(prop_uri: str) -> str | None:
    """Whitelist-strict: returns None for any property outside _PROP_REL.
    Callers must skip rows returning None (per D-017)."""
    pid = uri_to_id(prop_uri)
    return _PROP_REL.get(pid)


# ---------- translation ----------

def _literal_value(lit: str) -> str:
    """Clean Wikidata literal like `"OL6074086A"` or `"value"^^<...>` → plain text."""
    s = lit.strip()
    # Split off the datatype suffix
    if "^^" in s:
        s = s.split("^^", 1)[0]
    return s.strip('"')


def _parse_entity_json(raw: str) -> dict:
    if not raw or not raw.strip():
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def translate_type_row(cols: list[str]) -> TrainingScenario | None:
    """`type` constraint: violation (s, p_viol, o_viol) + correction adds
    (s, P31, o_corr) — s should be an instance of o_corr's required class.

    Maps to: orbweaver graph pre-state = violation triple + loose context;
    expected_mutation = single add_link(s, o_corr, INSTANCE_OF).

    Column indices are 0-based. Real bass-materials rows have 16 columns
    (not 20 — the README's column numbering was 1-based and included
    fields that only appear when there's a second violation/correction
    triple):
        0  statement id    1  revision     2-4  violation triple
        5-7  second violation (empty for `type`)   8  "->" separator
        9-11 correction triple                     12 correction type
        13 subject JSON    14 object JSON   15 (empty for single correction)
    """
    if len(cols) < 15:
        return None

    v_subj_uri = cols[2]
    v_pred_uri = cols[3]
    v_obj_raw = cols[4]
    c_subj_uri = cols[9]
    c_pred_uri = cols[10]
    c_obj_raw = cols[11]
    ctype = cols[12].strip()

    # Only addition corrections for `type` (should be all of them).
    if _ADDITION not in ctype:
        return None
    # Only P31 corrections (instance-of).
    if uri_to_id(c_pred_uri) != "p31":
        return None
    # Skip correction objects that are literals (shouldn't happen for P31 but safe).
    if is_literal(c_obj_raw):
        return None

    subj_json = _parse_entity_json(cols[13])
    viol_obj_json = _parse_entity_json(cols[14])

    s_id = uri_to_id(v_subj_uri)
    v_obj_id = uri_to_id(v_obj_raw)  # Wikidata id OR stripped literal
    c_obj_id = uri_to_id(c_obj_uri := c_obj_raw)

    # Core labels + names
    s_label = infer_pole_label(subj_json)
    s_name = english_name(subj_json) or s_id
    # Violation object
    v_obj_is_literal = is_literal(v_obj_raw)
    v_obj_label = "Object" if v_obj_is_literal else infer_pole_label(viol_obj_json)
    v_obj_name = (_literal_value(v_obj_raw) if v_obj_is_literal
                  else (english_name(viol_obj_json) or v_obj_id))
    # Correction object (the required class)
    c_obj_label = "Object"  # Wikidata classes map loosely; keep it simple
    c_obj_name = c_obj_id

    viol_rel = prop_to_rel(v_pred_uri)
    if viol_rel is None:
        return None  # violation predicate not in whitelist — skip row

    # Cypher snapshot — minimal but realistic. Use stable variables.
    #
    # Subject node with a couple of useful facts (if available) to give the
    # model a non-trivial subgraph. Limit to 2-3 extra facts so the context
    # is meaningful but not enormous. Extra facts are also whitelist-gated
    # so every edge in the snapshot has a real POLE+O rel_type.
    extra_nodes_cypher: list[str] = []
    extra_edges_cypher: list[str] = []
    extra_ids: list[str] = []
    subj_facts = subj_json.get("facts", {}) if subj_json else {}
    picked = 0
    for prop, values in subj_facts.items():
        if picked >= 2:
            break
        if not values or not isinstance(values, list):
            continue
        val0 = values[0]
        if is_literal(val0):
            continue
        if uri_to_id(prop) == "p31":
            continue
        extra_id = uri_to_id(val0)
        if extra_id == s_id or extra_id == v_obj_id or extra_id == c_obj_id:
            continue
        rel = prop_to_rel(prop)
        if rel is None:
            continue  # extra-fact predicate not in whitelist — skip
        extra_nodes_cypher.append(
            f"CREATE (x{picked}:Object {{id: '{extra_id}', name: '{extra_id}'}})"
        )
        extra_edges_cypher.append(
            f"CREATE (s)-[:{rel} {{weight: 0.9}}]->(x{picked})"
        )
        extra_ids.append(extra_id)
        picked += 1

    viol_obj_var = "vo"
    corr_obj_var = "co"

    cypher_statements = [
        f"CREATE (s:{s_label} {{id: '{s_id}', name: {json.dumps(s_name)}}})",
        (f"CREATE ({viol_obj_var}:{v_obj_label} "
         f"{{id: '{v_obj_id}', name: {json.dumps(v_obj_name)}}})"),
        (f"CREATE ({corr_obj_var}:{c_obj_label} "
         f"{{id: '{c_obj_id}', name: {json.dumps(c_obj_name)}}})"),
    ] + extra_nodes_cypher + [
        f"CREATE (s)-[:{viol_rel} {{weight: 0.9}}]->({viol_obj_var})",
    ] + extra_edges_cypher

    graph_cypher = ";\n".join(cypher_statements)

    # Event: describe the constraint violation that triggers the fix.
    rev_raw = cols[1].strip("<>") if cols[1] else ""
    revision = rev_raw.rsplit("/", 1)[-1] if rev_raw else "unknown"
    events = [{
        "t": "2022-01-01T00:00:00Z",
        "kind": "constraint_violation",
        "entity_ids": [s_id, v_obj_id, c_obj_id],
        "text": (f"Type constraint violation: {s_name} has "
                 f"{viol_rel} → {v_obj_name} but is missing an "
                 f"INSTANCE_OF edge to its required class."),
    }]

    # The correction as an orbweaver mutation
    expected_mutations = [{
        "verb": "add_link",
        "from_id": s_id,
        "to_id": c_obj_id,
        "rel_type": "INSTANCE_OF",
        "weight": 0.95,
        "rationale": (f"Wikidata `type` constraint repair (revision {revision}): "
                      f"adding INSTANCE_OF so the {viol_rel} edge to {v_obj_name} "
                      f"passes its type check."),
    }]

    qa_pairs = [
        QAPair(
            q=f"What class is {s_name} an instance of?",
            gold_node_ids=[s_id, c_obj_id],
            gold_rel_triples=[[s_id, "INSTANCE_OF", c_obj_id]],
        ),
        QAPair(
            q=f"How is {s_name} related to {v_obj_name}?",
            gold_node_ids=[s_id, v_obj_id],
            gold_rel_triples=[[s_id, viol_rel, v_obj_id]],
        ),
    ]

    return TrainingScenario(
        scenario_type="implicit_link",
        theme="wikidata constraint repair (type)",
        graph_snapshot_cypher=graph_cypher,
        events_since_last_tick=events,
        expected_mutations=expected_mutations,
        qa_pairs=qa_pairs,
        rationale=(f"Wikidata `type` constraint repair: subject has a "
                   f"{viol_rel} edge but lacked the INSTANCE_OF edge that "
                   f"the constraint requires. Adding the INSTANCE_OF edge "
                   f"resolves the violation and improves retrieval of "
                   f"class-level queries about this subject."),
    )


# ---------- file-level translation ----------

def iter_bass_rows(path: Path) -> Iterator[list[str]]:
    """Yield tab-split rows from a gzipped bass-materials TSV."""
    with gzip.open(path, "rt", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if line:
                yield line.split("\t")


def translate_type_file(path: Path, limit: int | None = None) -> Iterator[TrainingScenario]:
    """Translate a `type` constraint-corrections file, one scenario per row."""
    count = 0
    for cols in iter_bass_rows(path):
        if limit is not None and count >= limit:
            return
        try:
            scen = translate_type_row(cols)
        except Exception:
            continue
        if scen is None:
            continue
        yield scen
        count += 1


# ---------- single-value constraint → deprecate ----------

def translate_single_row(cols: list[str]) -> TrainingScenario | None:
    """`single` constraint: property must have at most one value. Violation
    is "kept" value, correction deletes an extra. Maps to orbweaver's
    `deprecate` (target_kind=relationship).

    We require the violation object AND correction object to be entity
    URIs (not literals) so the pre-state graph has concrete nodes to
    target. Rows with literal objects are skipped — simpler scope.
    """
    if len(cols) < 15:
        return None
    v_subj_uri = cols[2]
    v_pred_uri = cols[3]
    v_obj_raw = cols[4]
    c_obj_raw = cols[11]
    ctype = cols[12].strip()

    if _DELETION not in ctype:
        return None
    # Need entity objects on both sides for a clean relationship deprecate
    if is_literal(v_obj_raw) or is_literal(c_obj_raw):
        return None
    # The violation and correction must share subject + predicate (the
    # "too many values" scenario); skip anything else.
    if uri_to_id(v_subj_uri) != uri_to_id(cols[9]):
        return None
    if uri_to_id(v_pred_uri) != uri_to_id(cols[10]):
        return None
    # Skip trivial self-deletion (violation == correction — appears in the
    # dataset; likely a data-quality artefact)
    if uri_to_id(v_obj_raw) == uri_to_id(c_obj_raw):
        return None

    subj_json = _parse_entity_json(cols[13])
    viol_obj_json = _parse_entity_json(cols[14])

    s_id = uri_to_id(v_subj_uri)
    kept_obj_id = uri_to_id(v_obj_raw)
    dup_obj_id = uri_to_id(c_obj_raw)

    s_label = infer_pole_label(subj_json)
    s_name = english_name(subj_json) or s_id
    kept_label = infer_pole_label(viol_obj_json)
    kept_name = english_name(viol_obj_json) or kept_obj_id
    dup_name = dup_obj_id  # no JSON for the duplicate in most rows

    rel = prop_to_rel(v_pred_uri)
    if rel is None:
        return None  # predicate not whitelisted — skip row
    rev_raw = cols[1].strip("<>") if cols[1] else ""
    revision = rev_raw.rsplit("/", 1)[-1] if rev_raw else "unknown"

    cypher_statements = [
        f"CREATE (s:{s_label} {{id: '{s_id}', name: {json.dumps(s_name)}}})",
        f"CREATE (k:{kept_label} {{id: '{kept_obj_id}', name: {json.dumps(kept_name)}}})",
        f"CREATE (d:Object {{id: '{dup_obj_id}', name: {json.dumps(dup_name)}}})",
        f"CREATE (s)-[:{rel} {{weight: 0.9}}]->(k)",
        f"CREATE (s)-[:{rel} {{weight: 0.6}}]->(d)",
    ]
    graph_cypher = ";\n".join(cypher_statements)

    events = [{
        "t": "2022-01-01T00:00:00Z",
        "kind": "constraint_violation",
        "entity_ids": [s_id, kept_obj_id, dup_obj_id],
        "text": (f"Single-value constraint violation: {s_name} has {rel} "
                 f"edges to both {kept_name} and {dup_name}; only one is valid."),
    }]

    expected_mutations = [{
        "verb": "deprecate",
        "target_kind": "relationship",
        "target_id": f"{s_id}|{rel}|{dup_obj_id}",
        "reason": "single-value constraint violation",
        "rationale": (f"Wikidata `single` constraint repair (revision {revision}): "
                      f"{s_name} had multiple {rel} values; deprecating the extra "
                      f"edge to {dup_name} preserves the canonical value ({kept_name})."),
    }]

    qa_pairs = [
        QAPair(
            q=f"What is the (single) {rel.lower().replace('_', ' ')} of {s_name}?",
            gold_node_ids=[s_id, kept_obj_id],
            gold_rel_triples=[[s_id, rel, kept_obj_id]],
        ),
        QAPair(
            q=f"Is {s_name} related to {kept_name}?",
            gold_node_ids=[s_id, kept_obj_id],
            gold_rel_triples=[[s_id, rel, kept_obj_id]],
        ),
    ]

    return TrainingScenario(
        scenario_type="stale_deprecation",
        theme="wikidata constraint repair (single)",
        graph_snapshot_cypher=graph_cypher,
        events_since_last_tick=events,
        expected_mutations=expected_mutations,
        qa_pairs=qa_pairs,
        rationale=(f"Wikidata `single` constraint repair: subject has multiple "
                   f"{rel} values when constraint requires at most one. Deprecating "
                   f"the extra edge preserves the canonical answer and removes the "
                   f"retrieval confound of two conflicting values."),
    )


def translate_single_file(path: Path, limit: int | None = None) -> Iterator[TrainingScenario]:
    """Translate a `single` constraint-corrections file to deprecate scenarios."""
    count = 0
    for cols in iter_bass_rows(path):
        if limit is not None and count >= limit:
            return
        try:
            scen = translate_single_row(cols)
        except Exception:
            continue
        if scen is None:
            continue
        yield scen
        count += 1
