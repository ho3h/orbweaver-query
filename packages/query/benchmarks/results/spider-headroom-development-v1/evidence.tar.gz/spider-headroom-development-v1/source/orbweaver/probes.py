"""ECHO-inspired probe layer — the graph teaches the head, for free.

Conceptual port from microsoft/echo-rl. ECHO adds a cross-entropy loss on
*environment-observation tokens* alongside the standard GRPO action loss,
so a policy learns world dynamics even from rollouts that earn zero reward.
orbweaver isn't RL, but the same wastage exists: every tick the spider
scores hundreds of candidate pairs, only the ~5 it stages as singleton
add_link / merge_entities become (:Edit) rows. Everything else — the
abstained pairs, the multi-element prediction sets, the unsupported-verb
escalations — vanishes. The graph evolves anyway: ingestion writes,
schema migrations, agent-memory's own :SAME_AS{status:'pending'} resolver,
later review sessions all keep merging entities and adding links.

A (:Probe) row records the spider's view of a candidate at scoring time.
A later pass (derive_weak_labels) walks the *current* canonical graph and
asks "did this pair end up merged / linked by something else?" — yes ⇒
weak positive label; no, both still distinct ⇒ weak abstain. These rows
join the training set at low weight (ECHO's world_model_coeff analog).

The reviewer's (:Edit) decision always wins: if an Applied/Rejected (:Edit)
exists for the same pair, the probe row is suppressed so the high-quality
human label isn't drowned by weak self-supervision.

## Discipline note (the ECHO bug willccbb confessed to)

Resist the temptation to *gate* probe weight by "would the reviewer agree?"
That folds reward into the env signal — exactly the trap ECHO avoided by
dropping the advantage term from the env loss. Probe rows train at a fixed
low weight regardless of how plausible reviewer agreement seems. Two
signals stacked, never blended.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

# Schema migration — call once via apply_probe_schema_migration() to install
# the constraint + indexes. Idempotent. (:Edit)'s schema migration in
# audit_log.py also references these so a single apply_schema_migration()
# call wires both up.
PROBE_SCHEMA_MIGRATION_CYPHER: list[str] = [
    "CREATE CONSTRAINT orbweaver_probe_id IF NOT EXISTS "
    "FOR (p:Probe) REQUIRE p.id IS UNIQUE",
    "CREATE INDEX orbweaver_probe_ts IF NOT EXISTS "
    "FOR (p:Probe) ON (p.ts)",
    "CREATE INDEX orbweaver_probe_pair IF NOT EXISTS "
    "FOR (p:Probe) ON (p.left_id, p.right_id)",
]

# Default weak-label weight. ECHO's world_model_coeff defaults positive but
# << 1.0; orbweaver picks 0.2 as a starting point. Tunable per experiment.
DEFAULT_PROBE_WEIGHT: float = 0.2

# How far forward to look for "the graph merged this pair via something
# else." Seconds. Default = 7 days. Short enough that probes stay relevant,
# long enough that ingestion / migration / later review can fire.
DEFAULT_LOOKAHEAD_SECS: float = 7 * 24 * 3600


@dataclass
class ProbeRow:
    """One scored candidate the spider saw this tick. Written regardless of
    whether the candidate was staged, abstained, or escalated."""
    probe_id: str
    left_id: str
    right_id: str
    blocker: str
    signals_json: str
    prediction_set_json: str
    top_verb: str
    top_prob: float
    graph_snapshot_cypher: str
    events_json: str
    spider_action: str            # "staged" | "abstained" | "unsupported_verb"
    ts: float = field(default_factory=time.time)
    tick_id: str = ""             # optional grouping per spider tick

    def to_props(self) -> dict[str, Any]:
        return {
            "id": self.probe_id,
            "left_id": self.left_id,
            "right_id": self.right_id,
            "blocker": self.blocker,
            "signals_json": self.signals_json,
            "prediction_set_json": self.prediction_set_json,
            "top_verb": self.top_verb,
            "top_prob": float(self.top_prob),
            "graph_snapshot_cypher": self.graph_snapshot_cypher,
            "events_json": self.events_json,
            "spider_action": self.spider_action,
            "ts": float(self.ts),
            "tick_id": self.tick_id,
        }


def new_probe_id() -> str:
    return f"prb-{int(time.time()*1000):014d}-{uuid.uuid4().hex[:10]}"


# ---------- write ----------

def apply_probe_schema_migration(driver_or_session) -> None:
    """Install the (:Probe) constraint + indexes. Idempotent."""
    sess = _coerce_session(driver_or_session)
    with sess as s:
        for stmt in PROBE_SCHEMA_MIGRATION_CYPHER:
            s.run(stmt)


def record_probe(driver_or_session, probe: ProbeRow) -> str:
    """Write a (:Probe) row. Returns the probe_id.

    Free of any (:Edit) cross-reference — probes record what the spider
    *saw*, not what got actioned. Joining to (:Edit) happens at weak-label
    time, not at probe-write time.
    """
    sess = _coerce_session(driver_or_session)
    with sess as s:
        s.run("CREATE (p:Probe $props)", props=probe.to_props())
    return probe.probe_id


# ---------- weak-label backfill ----------

@dataclass
class WeakLabel:
    """Result of looking forward from a probe to current canonical state."""
    probe_id: str
    left_id: str
    right_id: str
    label_verb: str               # "add_link" | "merge_entities" | "abstain"
    weight: float
    evidence: dict[str, Any]      # what we found in the graph that supports the label
    source_probe_ts: float
    graph_snapshot_cypher: str    # carried over from the probe (stage-time)
    events_json: str              # ditto


def derive_weak_labels(
    driver_or_session,
    *,
    lookahead_secs: float = DEFAULT_LOOKAHEAD_SECS,
    probe_weight: float = DEFAULT_PROBE_WEIGHT,
    now_ts: float | None = None,
    include_negative_abstain: bool = True,
    abstain_weight_factor: float = 0.5,
) -> list[WeakLabel]:
    """Walk (:Probe) rows older than `lookahead_secs` and weak-label them
    from the current canonical graph.

    Decision logic per pair (left_id, right_id):
      1. If an :Edit with Applied/Rejected status exists for this pair → SKIP
         (the reviewer's signal supersedes; weak label would only add noise).
      2. If the pair is now connected by a canonical :SAME_AS edge, OR one of
         the two nodes is deprecated and the other is the canonical_id →
         weak positive `merge_entities`.
      3. If the pair is now connected by ANY canonical non-SUGGESTED, non-
         SAME_AS edge → weak positive `add_link`.
      4. If both nodes still exist, neither is deprecated, and there is no
         link → weak abstain (optional, at reduced weight — controlled by
         include_negative_abstain / abstain_weight_factor).
      5. If either node is missing → SKIP (insufficient evidence).

    Returns a list of WeakLabel; deduplication by pair happens during export.
    """
    now = now_ts if now_ts is not None else time.time()
    cutoff = now - lookahead_secs
    sess = _coerce_session(driver_or_session)
    out: list[WeakLabel] = []

    with sess as s:
        rows = list(s.run(
            "MATCH (p:Probe) WHERE p.ts <= $cutoff "
            "RETURN p ORDER BY p.ts ASC",
            cutoff=float(cutoff),
        ))

        for r in rows:
            p = dict(r["p"])
            left_id, right_id = p["left_id"], p["right_id"]

            # Step 1: reviewer signal wins.
            edit_row = s.run(
                "MATCH (e:Edit) "
                "WHERE e.status IN ['Applied', 'Rejected'] "
                "  AND ( "
                "    e.target_id STARTS WITH ($l + '|') AND e.target_id ENDS WITH ('|' + $r) "
                "    OR e.target_id STARTS WITH ($r + '|') AND e.target_id ENDS WITH ('|' + $l) "
                "  ) "
                "RETURN e.id AS id LIMIT 1",
                l=left_id, r=right_id,
            ).single()
            if edit_row is not None:
                continue

            # Step 2-5: read canonical state.
            state = s.run(
                "OPTIONAL MATCH (a {id: $l}) "
                "OPTIONAL MATCH (b {id: $r}) "
                "OPTIONAL MATCH (a)-[same_as:SAME_AS]-(b) "
                "OPTIONAL MATCH (a)-[other]-(b) "
                "  WHERE NOT type(other) STARTS WITH 'SUGGESTED_' "
                "    AND type(other) <> 'SAME_AS' "
                "RETURN a IS NOT NULL AS a_exists, "
                "       b IS NOT NULL AS b_exists, "
                "       coalesce(a.deprecated, false) AS a_dep, "
                "       coalesce(b.deprecated, false) AS b_dep, "
                "       a.deprecated_canonical_id AS a_can_id, "
                "       b.deprecated_canonical_id AS b_can_id, "
                "       count(distinct same_as) AS n_same_as, "
                "       count(distinct other) AS n_other",
                l=left_id, r=right_id,
            ).single()

            if state is None:
                continue
            a_exists = bool(state["a_exists"])
            b_exists = bool(state["b_exists"])
            if not (a_exists or b_exists):
                continue  # both gone — no signal

            # Merge signal: SAME_AS edge, or deprecation pointing across.
            a_dep, b_dep = bool(state["a_dep"]), bool(state["b_dep"])
            a_can, b_can = state["a_can_id"], state["b_can_id"]
            merged_via_dep = (
                (a_dep and a_can == right_id)
                or (b_dep and b_can == left_id)
            )
            if int(state["n_same_as"]) > 0 or merged_via_dep:
                out.append(WeakLabel(
                    probe_id=p["id"],
                    left_id=left_id,
                    right_id=right_id,
                    label_verb="merge_entities",
                    weight=probe_weight,
                    evidence={"signal": "same_as_or_deprecation",
                              "n_same_as": int(state["n_same_as"]),
                              "merged_via_dep": merged_via_dep},
                    source_probe_ts=float(p["ts"]),
                    graph_snapshot_cypher=p.get("graph_snapshot_cypher", ""),
                    events_json=p.get("events_json", "[]"),
                ))
                continue

            # Link signal: any non-SUGGESTED, non-SAME_AS edge.
            if int(state["n_other"]) > 0:
                out.append(WeakLabel(
                    probe_id=p["id"],
                    left_id=left_id,
                    right_id=right_id,
                    label_verb="add_link",
                    weight=probe_weight,
                    evidence={"signal": "canonical_edge",
                              "n_other": int(state["n_other"])},
                    source_probe_ts=float(p["ts"]),
                    graph_snapshot_cypher=p.get("graph_snapshot_cypher", ""),
                    events_json=p.get("events_json", "[]"),
                ))
                continue

            # Negative abstain: both still distinct, no link.
            if include_negative_abstain and a_exists and b_exists and not a_dep and not b_dep:
                out.append(WeakLabel(
                    probe_id=p["id"],
                    left_id=left_id,
                    right_id=right_id,
                    label_verb="abstain",
                    weight=probe_weight * abstain_weight_factor,
                    evidence={"signal": "still_distinct_no_link"},
                    source_probe_ts=float(p["ts"]),
                    graph_snapshot_cypher=p.get("graph_snapshot_cypher", ""),
                    events_json=p.get("events_json", "[]"),
                ))

    return _dedupe_labels(out)


def _dedupe_labels(labels: list[WeakLabel]) -> list[WeakLabel]:
    """If multiple probes fired for the same pair, keep the LATEST positive
    signal; if only abstains, keep the latest. Positive > abstain."""
    seen: dict[tuple[str, str], WeakLabel] = {}
    for lbl in labels:
        key = tuple(sorted((lbl.left_id, lbl.right_id)))
        prev = seen.get(key)
        if prev is None:
            seen[key] = lbl
            continue
        prev_pos = prev.label_verb in ("merge_entities", "add_link")
        cur_pos = lbl.label_verb in ("merge_entities", "add_link")
        if cur_pos and not prev_pos:
            seen[key] = lbl
        elif cur_pos == prev_pos and lbl.source_probe_ts > prev.source_probe_ts:
            seen[key] = lbl
    return list(seen.values())


# ---------- training-row export ----------

def weak_label_to_training_row(lbl: WeakLabel) -> dict:
    """Convert a WeakLabel to the JSONL row shape consumed by
    classifier.build_classifier_examples().

    Mirrors retrain_runner._training_row() but with synthesized expected
    mutations and a probe-flavored _meta payload so trainers / audits can
    distinguish (:Edit)-derived rows from (:Probe)-derived ones.
    """
    if lbl.label_verb == "merge_entities":
        expected = [{
            "verb": "merge_entities",
            "dup_id": lbl.left_id,
            "canonical_id": lbl.right_id,
            "confidence": lbl.weight,
            "rationale": "probe_weak_label",
        }]
    elif lbl.label_verb == "add_link":
        expected = [{
            "verb": "add_link",
            "from_id": lbl.left_id,
            "to_id": lbl.right_id,
            "rel_type": "KNOWS",
            "weight": lbl.weight,
            "rationale": "probe_weak_label",
        }]
    else:  # abstain
        expected = []

    return {
        "id": f"probe-{lbl.probe_id}",
        "graph_snapshot_cypher": lbl.graph_snapshot_cypher,
        "events_since_last_tick": _json_list(lbl.events_json, default=[]),
        "expected_mutations": expected,
        "qa_pairs": [],
        "_meta": {
            "source": "probe_weak_label",
            "probe_id": lbl.probe_id,
            "weight": float(lbl.weight),
            "label_verb": lbl.label_verb,
            "evidence": lbl.evidence,
            "source_probe_ts": lbl.source_probe_ts,
        },
    }


def export_probe_rows(
    driver_or_session,
    out_path,
    *,
    lookahead_secs: float = DEFAULT_LOOKAHEAD_SECS,
    probe_weight: float = DEFAULT_PROBE_WEIGHT,
    now_ts: float | None = None,
    include_negative_abstain: bool = True,
    abstain_weight_factor: float = 0.5,
) -> int:
    """Run derive_weak_labels and write JSONL training rows to out_path.
    Returns the number of rows written."""
    from pathlib import Path
    labels = derive_weak_labels(
        driver_or_session,
        lookahead_secs=lookahead_secs,
        probe_weight=probe_weight,
        now_ts=now_ts,
        include_negative_abstain=include_negative_abstain,
        abstain_weight_factor=abstain_weight_factor,
    )
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with out_path.open("w") as f:
        for lbl in labels:
            row = weak_label_to_training_row(lbl)
            f.write(json.dumps(row) + "\n")
            n += 1
    return n


# ---------- maintenance ----------

def prune_probes(driver_or_session, *, older_than_secs: float,
                 now_ts: float | None = None) -> int:
    """Delete (:Probe) rows older than the given age. Returns rows deleted.

    Probes are bookkeeping — once their weak labels have been folded into a
    training set, they can go. Default policy: keep for 2× DEFAULT_LOOKAHEAD
    so a probe is always available to one extra retrain cycle as a backstop.
    """
    now = now_ts if now_ts is not None else time.time()
    cutoff = now - older_than_secs
    sess = _coerce_session(driver_or_session)
    with sess as s:
        row = s.run(
            "MATCH (p:Probe) WHERE p.ts < $cutoff "
            "WITH p, p.id AS id DELETE p RETURN count(id) AS n",
            cutoff=float(cutoff),
        ).single()
    return int(row["n"]) if row else 0


# ---------- helpers ----------

def _json_list(raw, *, default: list) -> list:
    if isinstance(raw, list):
        return raw
    if not raw:
        return default
    try:
        parsed = json.loads(raw)
    except (TypeError, ValueError):
        return default
    return parsed if isinstance(parsed, list) else default


def _coerce_session(x):
    if hasattr(x, "session"):
        return x.session()
    return x
