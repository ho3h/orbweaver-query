"""Hard-confusable training data per second compass artifact §3 stream B.

> "8-class mutation negatives (typo, within-type entity swap, cross-type
>  swap, relation swap, dangling reference, cardinality violation,
>  inverse-relation confusion, datatype/unit drift). Cantone et al.'s
>  domain-and-range-aware NS gives +10% MRR on standard benchmarks and
>  +150% on ontology-backed datasets vs random NS — directly applicable."

This is the MVP cut: 3 high-signal corruption classes + a no-op
abstain-strengthening generator. Each corruption takes a TrainingScenario
and produces a *new* TrainingScenario whose graph is corrupted in a
specific way, with `expected_mutations` updated to reflect the
appropriate fix.

The 3 we generate:

1. **typo (→ merge_entities)** — clone an existing entity with a
   misspelled id; the fix is to merge the typo'd id back to canonical.
2. **inverse-relation confusion (→ deprecate)** — reverse the direction
   of an existing edge; the fix is to deprecate the wrong-direction edge.
3. **abstain (→ no_op)** — strip the events from a regular scenario so
   nothing actively warrants a change; the fix is the empty list.

Each corruption preserves the qa_pairs gold sets so F1-filter still
works. Output rows are TrainingScenario-shaped JSON, ready to drop into
data/v1.5/staging/ for the existing ingest pipeline.
"""
from __future__ import annotations

import copy
import json
import random
import re
from pathlib import Path


def _typo_id(orig_id: str, rng: random.Random) -> str:
    """Produce a misspelled variant of an id (lowercase snake_case)."""
    if len(orig_id) < 4:
        return orig_id + "_x"
    # Pick a random non-underscore char to swap with its neighbour, OR drop a letter
    chars = list(orig_id)
    op = rng.choice(["swap", "drop", "double"])
    indices = [i for i, c in enumerate(chars) if c.isalpha()]
    if not indices:
        return orig_id + "_x"
    i = rng.choice(indices[1:-1] if len(indices) > 2 else indices)
    if op == "swap" and i + 1 < len(chars) and chars[i + 1].isalpha():
        chars[i], chars[i + 1] = chars[i + 1], chars[i]
    elif op == "drop":
        chars.pop(i)
    elif op == "double":
        chars.insert(i, chars[i])
    return "".join(chars)


def _all_ids_in_cypher(cypher: str) -> set[str]:
    """Extract every `id: '...'` value from a Cypher CREATE block."""
    return set(re.findall(r"id:\s*['\"]([a-z0-9_]+)['\"]", cypher))


def _entity_lines(cypher: str) -> list[tuple[str, str]]:
    """Parse `CREATE (var:Label {id:'...'...})` lines into (var, id) pairs."""
    lines = []
    for line in cypher.split(";\n"):
        m = re.search(r"CREATE\s*\(\s*(\w+)\s*:\s*\w+\s*\{[^}]*id:\s*['\"]([a-z0-9_]+)['\"]", line)
        if m:
            lines.append((m.group(1), m.group(2)))
    return lines


def _rels_in_cypher(cypher: str) -> list[tuple[str, str, str]]:
    """Parse `(varA)-[:REL{...}]->(varB)` lines into (a_var, rel, b_var)."""
    rels = []
    for line in cypher.split(";\n"):
        m = re.search(
            r"\((\w+)\)\s*-\s*\[\s*:\s*([A-Z_]+)\b[^\]]*\]\s*->\s*\((\w+)\)",
            line,
        )
        if m:
            rels.append((m.group(1), m.group(2), m.group(3)))
    return rels


# ---------- corruption: typo → merge_entities ----------

def make_typo_corruption(row: dict, rng: random.Random) -> dict | None:
    """Pick an entity, append a duplicate node with a typo'd id, and
    record the fix as merge_entities(typo_id → canonical_id)."""
    cypher = row["graph_snapshot_cypher"]
    entities = _entity_lines(cypher)
    if len(entities) < 2:
        return None
    canon_var, canon_id = rng.choice(entities)
    typo = _typo_id(canon_id, rng)
    if typo == canon_id or typo in _all_ids_in_cypher(cypher):
        return None

    # Append a duplicate node with the typo'd id and same label.
    # Easier than parsing labels: copy the original CREATE line and rename.
    label_match = re.search(
        rf"CREATE\s*\(\s*{canon_var}\s*:\s*(\w+)", cypher,
    )
    if not label_match:
        return None
    label = label_match.group(1)
    typo_var = canon_var + "t"
    new_node_line = f"CREATE ({typo_var}:{label} {{id: '{typo}', name: '{typo}'}})"

    # Add an event mentioning the typo as if it were a separate entity
    new_events = list(row.get("events_since_last_tick", []) or [])
    new_events.append({
        "t": "2026-04-24T12:00:00Z",
        "kind": "ingest_message",
        "entity_ids": [typo, canon_id],
        "text": (f"Recent ingest mentioned `{typo}`; cross-checking against canonical "
                 f"entries shows it matches `{canon_id}` (one-character drift)."),
    })

    new_cypher = cypher + ";\n" + new_node_line

    new_row = copy.deepcopy(row)
    new_row["id"] = "corrupt_typo_" + row["id"]
    new_row["graph_snapshot_cypher"] = new_cypher
    new_row["events_since_last_tick"] = new_events
    new_row["scenario_type"] = "duplicate_entity"
    new_row["theme"] = row.get("theme", "synthetic typo corruption")
    new_row["expected_mutations"] = [{
        "verb": "merge_entities",
        "dup_id": typo,
        "canonical_id": canon_id,
        "confidence": 0.9,
        "rationale": (f"`{typo}` is a one-character drift from canonical `{canon_id}` "
                      f"in the same scenario; merge to dedupe."),
    }]
    # Pydantic schema requires ≥2 qa_pairs; keep one from the original
    # if available for context, plus the merge-specific one.
    qa_seed = list(row.get("qa_pairs", []) or [])
    new_row["qa_pairs"] = [
        {
            "q": f"Are `{typo}` and `{canon_id}` the same entity?",
            "gold_node_ids": [typo, canon_id],
            "gold_rel_triples": [],
        },
        qa_seed[0] if qa_seed else {
            "q": f"What is the canonical id for `{canon_id}`?",
            "gold_node_ids": [canon_id],
            "gold_rel_triples": [],
        },
    ]
    new_row["rationale"] = ("Typo confusable: a duplicate entity was ingested with a "
                            "one-character variation. The fix is to merge the typo'd "
                            "id back to the canonical id.")
    return new_row


# ---------- corruption: inverse-relation confusion → deprecate ----------

def make_inverse_corruption(row: dict, rng: random.Random) -> dict | None:
    """Pick an existing relationship, add the REVERSED direction as a stale
    edge that should be deprecated."""
    cypher = row["graph_snapshot_cypher"]
    rels = _rels_in_cypher(cypher)
    if not rels:
        return None
    a_var, rel, b_var = rng.choice(rels)
    # Resolve var→id
    var_to_id = {v: i for v, i in _entity_lines(cypher)}
    if a_var not in var_to_id or b_var not in var_to_id:
        return None
    a_id, b_id = var_to_id[a_var], var_to_id[b_var]

    # Add reversed edge with low weight (stale)
    reversed_line = f"CREATE ({b_var})-[:{rel} {{weight: 0.3}}]->({a_var})"
    new_cypher = cypher + ";\n" + reversed_line

    new_events = list(row.get("events_since_last_tick", []) or [])
    new_events.append({
        "t": "2026-04-24T12:00:00Z",
        "kind": "audit_note",
        "entity_ids": [a_id, b_id],
        "text": (f"Audit found `{b_id} -[:{rel}]-> {a_id}` was created in error; "
                 f"the canonical direction is `{a_id} -[:{rel}]-> {b_id}` (already in graph)."),
    })

    new_row = copy.deepcopy(row)
    new_row["id"] = "corrupt_inverse_" + row["id"]
    new_row["graph_snapshot_cypher"] = new_cypher
    new_row["events_since_last_tick"] = new_events
    new_row["scenario_type"] = "stale_deprecation"
    new_row["theme"] = row.get("theme", "synthetic inverse corruption")
    new_row["expected_mutations"] = [{
        "verb": "deprecate",
        "target_kind": "relationship",
        "target_id": f"{b_id}|{rel}|{a_id}",
        "reason": "inverse-direction relationship created in error",
        "rationale": (f"The audit confirms `{b_id} -[:{rel}]-> {a_id}` is the wrong direction; "
                      f"deprecate to leave only the canonical `{a_id} -[:{rel}]-> {b_id}` edge."),
    }]
    qa_seed = list(row.get("qa_pairs", []) or [])
    new_row["qa_pairs"] = [
        {
            "q": f"Which direction of {rel} between {a_id} and {b_id} is canonical?",
            "gold_node_ids": [a_id, b_id],
            "gold_rel_triples": [[a_id, rel, b_id]],
        },
        qa_seed[0] if qa_seed else {
            "q": f"Is `{a_id}` related to `{b_id}` via {rel}?",
            "gold_node_ids": [a_id, b_id],
            "gold_rel_triples": [[a_id, rel, b_id]],
        },
    ]
    new_row["rationale"] = ("Inverse-relation confusable: the same relationship exists in "
                            "both directions but only one is canonical. Deprecate the "
                            "wrong direction.")
    return new_row


# ---------- corruption: empty-events → abstain ----------

def make_abstain_corruption(row: dict, rng: random.Random) -> dict | None:
    """Strip the events_since_last_tick to make a 'nothing to react to'
    abstain example. Only valid for scenarios where the original graph
    is internally consistent enough that no mutation is forced."""
    new_row = copy.deepcopy(row)
    new_row["id"] = "corrupt_abstain_" + row["id"]
    new_row["events_since_last_tick"] = [
        {
            "t": "2026-04-24T12:00:00Z",
            "kind": "routine_check",
            "entity_ids": [],
            "text": "Routine integrity scan; no anomalies surfaced.",
        }
    ]
    new_row["scenario_type"] = "no_op"
    new_row["theme"] = row.get("theme", "synthetic abstain")
    new_row["expected_mutations"] = []
    # Keep some qa_pairs but strip references to deprecated/expired things
    new_row["rationale"] = ("Abstain confusable: no event warrants a change. The graph is "
                            "already internally consistent.")
    return new_row


# ---------- driver ----------

CORRUPTORS = {
    "typo": make_typo_corruption,
    "inverse": make_inverse_corruption,
    "abstain": make_abstain_corruption,
}


def generate_corruptions(
    source_jsonl: str | Path, out_dir: str | Path,
    *, n_per_kind: int = 20, seed: int = 0,
) -> dict:
    """Read a TrainingScenario JSONL, apply each corruption to a random
    sample of rows, write each corrupted scenario to out_dir/<id>.json.

    Returns a count summary by corruption kind."""
    source = list(Path(source_jsonl).read_text().splitlines())
    rows = [json.loads(line) for line in source if line.strip()]
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    rng = random.Random(seed)
    counts: dict[str, int] = {}
    for kind, fn in CORRUPTORS.items():
        n = 0
        attempts = 0
        # Try up to 5n source rows to produce n corruptions
        sources = rng.sample(rows, min(len(rows), n_per_kind * 5))
        for src in sources:
            if n >= n_per_kind:
                break
            attempts += 1
            try:
                corrupted = fn(src, rng)
            except Exception:
                continue
            if corrupted is None:
                continue
            (out_path / f"{corrupted['id']}.json").write_text(
                json.dumps(corrupted, indent=2)
            )
            n += 1
        counts[kind] = n
    return counts


if __name__ == "__main__":
    import sys
    out = generate_corruptions(
        sys.argv[1] if len(sys.argv) > 1 else "data/v1.4/train_mixed.jsonl",
        sys.argv[2] if len(sys.argv) > 2 else "data/v1.5/staging",
        n_per_kind=int(sys.argv[3]) if len(sys.argv) > 3 else 20,
    )
    print(json.dumps(out, indent=2))
