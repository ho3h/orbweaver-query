"""Self-contained loader for orbweaver-qwen3-4b-spider-v0.1.

Mirrors SetFit's two-artifact pattern:
- the base model is referenced by name and loaded via mlx-lm.
- the head is loaded from this directory's head.safetensors.
- the calibration is loaded from calibration.json (CV+ APS scores).

## Usage

    from orbweaver_loader import load_spider, predict_set
    spider = load_spider(".")
    pset = predict_set(spider, scenario_dict, target_coverage=0.9)

`scenario_dict` is a TrainingScenario-shaped dict with at minimum
`graph_snapshot_cypher` and `events_since_last_tick`. `pset` is the
list of verbs in the prediction set, in descending probability order.
A singleton means the spider is confident; a multi-element set should
be escalated to human review.

## Dependencies

- mlx-lm >= 0.31.2 (for the base)
- mlx-community/Qwen3-4B-Instruct-2507-4bit (downloaded automatically)
- numpy
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

import mlx.core as mx
import mlx.nn as nn
import numpy as np
from mlx.utils import tree_unflatten


VERB_LABELS = ["add_link", "add_reflection", "merge_entities",
               "adjust_weight", "deprecate", "abstain"]
N_CLASSES = len(VERB_LABELS)


class ClassifierHead(nn.Module):
    def __init__(self, hidden_size: int, n_classes: int = N_CLASSES,
                 dropout: float = 0.1):
        super().__init__()
        self.norm = nn.LayerNorm(hidden_size)
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_size, n_classes)

    def __call__(self, last_hidden):
        x = self.norm(last_hidden)
        x = self.dropout(x)
        return self.classifier(x)


@dataclass
class Spider:
    base: any
    tokenizer: any
    head: ClassifierHead
    head_config: dict
    calibration_scores: list
    target_coverage: float


def load_spider(spider_dir: str = ".") -> Spider:
    spider_path = Path(spider_dir)
    config = json.loads((spider_path / "head_config.json").read_text())
    calibration = json.loads((spider_path / "calibration.json").read_text())

    from mlx_lm import load
    base, tokenizer = load(config["base_model"])
    base.freeze()

    head = ClassifierHead(
        config["in_features"],
        config["out_features"],
        dropout=config.get("dropout", 0.1),
    )
    weights = mx.load(str(spider_path / "head.safetensors"))
    head.update(tree_unflatten(list(weights.items())))
    mx.eval(head.parameters())
    head.eval()

    return Spider(
        base=base, tokenizer=tokenizer, head=head, head_config=config,
        calibration_scores=calibration["nonconformity_scores"],
        target_coverage=calibration["target_coverage"],
    )


def _build_user_prompt(scenario: dict) -> str:
    cy = scenario.get("graph_snapshot_cypher", "")
    events = scenario.get("events_since_last_tick", []) or []
    events_text = "\n".join(json.dumps(e, separators=(",", ":")) for e in events)
    return (
        f"## Current graph snapshot\n{cy}\n\n"
        f"## Events since last pass\n{events_text}\n\n"
        f"Emit the mutation array."
    )


# Keep this in sync with orbweaver/data.py SYSTEM_PROMPT.
SPIDER_SYSTEM_PROMPT = """\
You are orbweaver, a specialist graph-memory maintainer. Your only job is to
propose graph mutations that improve retrieval quality.

You may emit ONLY these verbs, as a JSON array of objects:
  - add_link     {verb, from_id, to_id, rel_type, weight, rationale}
  - add_reflection {verb, reflection_id, summary, source_ids[], rationale}
  - merge_entities {verb, dup_id, canonical_id, confidence, rationale}
  - adjust_weight  {verb, from_id, to_id, rel_type, delta, rationale}
  - deprecate      {verb, target_kind: "node"|"relationship", target_id, reason, rationale}

Invariants:
  - Never DELETE anything. `deprecate` is a soft flag.
  - Never overwrite user-asserted facts.
  - Every mutation must be reasonable given the snapshot and events.
  - Output MUST be a valid JSON array. No markdown fences. No commentary.

Output only the JSON array. Nothing before or after.
"""


def _last_hidden(spider: Spider, scenario: dict) -> np.ndarray:
    msgs = [
        {"role": "system", "content": SPIDER_SYSTEM_PROMPT},
        {"role": "user", "content": _build_user_prompt(scenario)},
    ]
    ids = spider.tokenizer.apply_chat_template(
        msgs, add_generation_prompt=True, tokenize=True,
    )
    if len(ids) > 4096:
        ids = ids[-4096:]
    x = mx.array([ids])
    hidden = spider.base.model(x)
    last = hidden[:, -1, :].astype(mx.float32)
    mx.eval(last)
    return np.array(last)[0]


def softmax(probs):
    a = np.asarray(probs); a = a - a.max(); e = np.exp(a)
    return (e / e.sum()).tolist()


def _aps_threshold(scores, target_coverage):
    n = len(scores)
    alpha = 1.0 - target_coverage
    sorted_s = sorted(scores)
    q_idx = max(0, min(n - 1, int(math.ceil((n + 1) * (1 - alpha))) - 1))
    return float(sorted_s[q_idx])


def predict_softmax(spider: Spider, scenario: dict) -> dict:
    """Return {verb: probability} for the scenario."""
    last = _last_hidden(spider, scenario)
    logits = spider.head(mx.array(last[None, :]))[0]
    mx.eval(logits)
    arr = np.array(logits)
    probs = softmax(arr.tolist())
    return {VERB_LABELS[i]: probs[i] for i in range(N_CLASSES)}


def predict_set(spider: Spider, scenario: dict,
                target_coverage: float | None = None) -> list:
    """Return the prediction-set as [(verb, prob), ...] in descending
    probability order. Empty inverse: a singleton means confident
    auto-applicable; multi-element should escalate to review."""
    cov = target_coverage if target_coverage is not None else spider.target_coverage
    tau = _aps_threshold(spider.calibration_scores, cov)
    sm = predict_softmax(spider, scenario)
    order = sorted(sm.items(), key=lambda kv: -kv[1])
    cum = 0.0
    out = []
    for verb, p in order:
        out.append((verb, p))
        if cum + p >= tau:
            return out
        cum += p
    return out
