"""Retrain loop — the addictive piece. Reads (:Edit) decisions from
Neo4j, folds them into the training set, kicks off train_classifier_v2.py
in a background subprocess, watches stdout, and atomically hot-swaps the
shipped head when training completes.

Wicked-simple boundaries:
  - One module-global RetrainState (the reviewer is single-user; no need
    for per-session state). Threading.Lock() guards mutations.
  - The "real" trainer is `train_classifier_v2.py` (existing single-file
    Karpathy-style). For dev/testing we ship a stub that simulates
    training in 5s; toggle via ORBWEAVER_RETRAIN_STUB=1.
  - The hot-swap is two atomic dir renames (POSIX). Old head archived
    to dist/<id>-archive-<ts>/ for rollback.

Decision-row format: each accepted (:Edit) becomes a training row of
the same shape as data/v1.5/train_mixed.jsonl. v1.1 stores the exact
stage-time graph snapshot, candidate event, prediction set, and mutation
payload on (:Edit), so retraining learns from what the reviewer actually
saw instead of a later, drifted graph state. Older rows fall back to
best-effort snapshot reconstruction.

Rejected decisions become abstain training rows: expected_mutations = [].
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from .spider import subgraph_snapshot
from .probes import (
    DEFAULT_LOOKAHEAD_SECS,
    export_probe_rows,
)

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_BASE_DATASET = REPO_ROOT / "data" / "v1.5" / "train_mixed.jsonl"
DEFAULT_DIST_CURRENT = REPO_ROOT / "dist" / "orbweaver-qwen3-4b-spider-v0.1"
REQUIRED_ARTIFACT_FILES = ("head.safetensors", "head_config.json", "calibration.json", "loader.py")

# v1.2 ECHO-inspired probes — opt-in via env so v1.1 retrains are unchanged.
ENV_PROBE_WEIGHT = "ORBWEAVER_PROBE_WEIGHT"
ENV_PROBE_LOOKAHEAD = "ORBWEAVER_PROBE_LOOKAHEAD_SECS"


@dataclass
class RetrainState:
    state: str = "idle"               # idle | running | complete | error
    started_ts: float = 0.0
    finished_ts: float = 0.0
    progress: float = 0.0             # 0..1
    log_tail: list[str] = field(default_factory=list)
    decisions_used: int = 0
    new_head_dir: str = ""            # set when state == complete
    error: str = ""

    def snapshot(self) -> dict:
        return {
            "state": self.state,
            "started_ts": self.started_ts,
            "finished_ts": self.finished_ts,
            "progress": self.progress,
            "log_tail": self.log_tail[-40:],
            "decisions_used": self.decisions_used,
            "new_head_dir": self.new_head_dir,
            "error": self.error,
        }


_state = RetrainState()
_lock = threading.Lock()
_thread: threading.Thread | None = None


# ---------- export ----------


def count_pending_decisions(driver, *, since_ts: float = 0.0) -> int:
    """How many (:Edit) decisions exist since `since_ts`. Drives the UI
    progress bar (decisions / target → button activates at target)."""
    sess = driver.session() if hasattr(driver, "session") else driver
    with sess as s:
        row = s.run(
            "MATCH (e:Edit) WHERE e.decided_ts >= $cutoff "
            "  AND e.status IN ['Applied', 'Rejected', 'Undone'] "
            "RETURN count(e) AS n",
            cutoff=float(since_ts),
        ).single()
    return int(row["n"]) if row else 0


def export_decisions(driver, *, since_ts: float = 0.0, out_path: Path) -> int:
    """Read (:Edit) decisions from Neo4j and write training-format JSONL.
    Returns the number of rows written."""
    sess = driver.session() if hasattr(driver, "session") else driver
    with sess as s:
        rows = list(s.run(
            "MATCH (e:Edit) WHERE e.decided_ts >= $cutoff "
            "  AND e.status IN ['Applied', 'Rejected'] "
            "RETURN e ORDER BY e.decided_ts ASC",
            cutoff=float(since_ts),
        ))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with out_path.open("w") as f:
        for r in rows:
            e = dict(r["e"])
            row = _edit_to_training_row(e)
            if row is None:
                row = _legacy_edit_to_training_row(driver, e)
            if row is None:
                continue
            f.write(json.dumps(row) + "\n")
            n += 1
    return n


def _edit_to_training_row(e: dict) -> dict | None:
    """Build a training row from the stage-time payload stored on (:Edit).

    Returns None for pre-v1.1 rows that do not carry a stored snapshot; the
    caller can then fall back to graph reconstruction.
    """
    snapshot = e.get("graph_snapshot_cypher") or ""
    if not snapshot:
        return None

    events = _json_list(e.get("events_json"), default=[])
    if not events:
        events = _fallback_events(e)

    expected: list[dict]
    if e.get("status") == "Applied":
        mutation = _json_dict(e.get("mutation_json"), default={})
        if mutation:
            expected = [mutation]
        else:
            staged_params = _json_dict(e.get("staged_params_json"), default={})
            expected = [_mutation_dict_for(e.get("verb", ""), staged_params)]
    else:
        expected = []

    return _training_row(e, snapshot=snapshot, events=events, expected=expected)


def _legacy_edit_to_training_row(driver, e: dict) -> dict | None:
    """Best-effort export for v1.0 Edit rows that lack stored context."""
    target_id = (e.get("target_id") or "").split("|")
    if len(target_id) < 1 or not target_id[0]:
        return None
    if len(target_id) == 3:
        left_id, _, right_id = target_id
    else:
        left_id, right_id = target_id[0], target_id[0]

    snapshot = subgraph_snapshot(driver, [left_id, right_id])
    if not snapshot:
        return None

    staged_params = _json_dict(e.get("staged_params_json"), default={})
    expected = (
        [_mutation_dict_for(e.get("verb", ""), staged_params)]
        if e.get("status") == "Applied"
        else []
    )
    return _training_row(e, snapshot=snapshot, events=_fallback_events(e), expected=expected)


def _training_row(e: dict, *, snapshot: str, events: list[dict],
                  expected: list[dict]) -> dict:
    prediction_set = _json_list(e.get("prediction_set_json"), default=[])
    meta = {
        "source": "decision_retrain",
        "edit_id": e["id"],
        "decided_by": e.get("decided_by", "reviewer"),
        "decided_ts": e.get("decided_ts"),
        "status": e["status"],
    }
    if prediction_set:
        meta["prediction_set"] = prediction_set
    return {
        "id": e["id"],
        "graph_snapshot_cypher": snapshot,
        "events_since_last_tick": events,
        "expected_mutations": expected,
        "qa_pairs": [],
        "_meta": meta,
    }


def _fallback_events(e: dict) -> list[dict]:
    parts = (e.get("target_id") or "").split("|")
    left_id = parts[0] if parts and parts[0] else ""
    right_id = parts[2] if len(parts) == 3 else left_id
    return [{
        "type": "candidate_pair_review",
        "left_id": left_id,
        "right_id": right_id,
        "from_decision": e.get("id"),
    }]


def _json_dict(raw, *, default: dict) -> dict:
    if isinstance(raw, dict):
        return raw
    if not raw:
        return default
    try:
        parsed = json.loads(raw)
    except (TypeError, ValueError):
        return default
    return parsed if isinstance(parsed, dict) else default


def _json_list(raw, *, default: list) -> list:
    if isinstance(raw, list):
        return raw
    if not raw:
        return default
    try:
        parsed = json.loads(raw)
    except (TypeError, ValueError):
        return default
    return parsed if isinstance(parsed, list) else default


def _mutation_dict_for(verb: str, staged_params: dict) -> dict:
    """Reconstruct the mutation dict from the staged_params that were
    passed to to_cypher. Only AddLink and MergeEntities are HITL-staged
    in v1.0."""
    if verb == "add_link":
        return {
            "verb": "add_link",
            "from_id": staged_params.get("from_id", ""),
            "to_id": staged_params.get("to_id", ""),
            "rel_type": staged_params.get("canonical_rel_type", "KNOWS"),
            "weight": staged_params.get("weight", 0.5),
            "rationale": "from_decision",
        }
    if verb == "merge_entities":
        return {
            "verb": "merge_entities",
            "dup_id": staged_params.get("dup", ""),
            "canonical_id": staged_params.get("can", ""),
            "confidence": staged_params.get("conf", 0.5),
            "rationale": "from_decision",
        }
    return {"verb": verb, "rationale": "from_decision"}


def merge_dataset(base_jsonl: Path, decisions_jsonl: Path, out_jsonl: Path,
                  *extra_sources: Path) -> int:
    """Concatenate base + decisions (+ any extra sources) to out, return
    total row count. Extra sources are appended in order, so the trainer
    sees [base, edits, probes, …]. Missing source files are silently
    skipped.
    """
    out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    sources = (base_jsonl, decisions_jsonl) + tuple(extra_sources)
    with out_jsonl.open("w") as out:
        for src in sources:
            if not src.exists():
                continue
            for line in src.read_text().splitlines():
                if line.strip():
                    out.write(line + "\n")
                    n += 1
    return n


def export_probe_decisions(driver, *, out_path: Path,
                           probe_weight: float | None = None,
                           lookahead_secs: float | None = None) -> int:
    """Wrapper around probes.export_probe_rows() that honors env-var
    overrides and returns the row count.

    Default behavior is OFF (probe_weight=0.0) so existing v1.1.x retrains
    see no change. Opt in by setting ORBWEAVER_PROBE_WEIGHT to the
    recommended starting value (probes.DEFAULT_PROBE_WEIGHT, currently 0.2)
    or any positive float. probe_weight=0.0 is the GRPO-baseline analog of
    ECHO's world_model_coeff=0.0.
    """
    weight = probe_weight if probe_weight is not None else float(
        os.environ.get(ENV_PROBE_WEIGHT, 0.0)
    )
    if weight <= 0.0:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text("")
        return 0
    lookahead = lookahead_secs if lookahead_secs is not None else float(
        os.environ.get(ENV_PROBE_LOOKAHEAD, DEFAULT_LOOKAHEAD_SECS)
    )
    return export_probe_rows(
        driver, out_path,
        probe_weight=weight,
        lookahead_secs=lookahead,
    )


# ---------- subprocess control ----------


def status() -> dict:
    """Snapshot of the current retrain state (thread-safe)."""
    with _lock:
        return _state.snapshot()


def is_running() -> bool:
    with _lock:
        return _state.state == "running"


def start_retrain(driver, *, since_ts: float = 0.0,
                  base_jsonl: Path | None = None,
                  out_dir: Path | None = None,
                  stub: bool | None = None) -> dict:
    """Kick off a retrain in a background thread (which spawns the
    trainer subprocess). Returns the new state snapshot.

    `stub`: if True (or if env ORBWEAVER_RETRAIN_STUB=1), run a fake
    trainer that sleeps 5s and writes a placeholder head. Useful for
    UI dev + CI."""
    global _thread
    with _lock:
        if _state.state == "running":
            return _state.snapshot()
        _state.state = "running"
        _state.started_ts = time.time()
        _state.finished_ts = 0.0
        _state.progress = 0.0
        _state.log_tail = []
        _state.decisions_used = 0
        _state.new_head_dir = ""
        _state.error = ""

    if stub is None:
        stub = os.getenv("ORBWEAVER_RETRAIN_STUB") in ("1", "true", "yes")
    base = base_jsonl or DEFAULT_BASE_DATASET
    out = out_dir or _next_candidate_dir()

    _thread = threading.Thread(
        target=_run_retrain_thread,
        args=(driver, since_ts, base, out, stub),
        daemon=True,
    )
    _thread.start()
    return status()


def _next_candidate_dir() -> Path:
    """dist/orbweaver-qwen3-4b-spider-v1.0-candidate-<ts>"""
    return REPO_ROOT / "dist" / f"orbweaver-qwen3-4b-spider-v1.0-candidate-{int(time.time())}"


def _run_retrain_thread(driver, since_ts, base_jsonl: Path,
                        out_dir: Path, stub: bool) -> None:
    try:
        # 1. Export decisions, merge with base.
        decisions_path = REPO_ROOT / "data" / f"v1.6-decisions-{int(time.time())}.jsonl"
        n_decisions = export_decisions(driver, since_ts=since_ts, out_path=decisions_path)
        with _lock:
            _state.decisions_used = n_decisions
            _state.log_tail.append(f"exported {n_decisions} decisions to {decisions_path.name}")
        if n_decisions == 0 and not stub:
            with _lock:
                _state.state = "error"
                _state.error = "no decisions to retrain on"
                _state.finished_ts = time.time()
            return

        # v1.2: optionally fold ECHO-style probe-derived weak labels in.
        probes_path = REPO_ROOT / "data" / f"v1.6-probes-{int(time.time())}.jsonl"
        try:
            n_probes = export_probe_decisions(driver, out_path=probes_path)
        except Exception as e:
            with _lock:
                _state.log_tail.append(f"probe export failed (continuing without probes): {e}")
            n_probes = 0
        with _lock:
            if n_probes:
                _state.log_tail.append(f"exported {n_probes} probe-derived weak labels to {probes_path.name}")

        merged = decisions_path.with_name(f"v1.6-merged-{int(time.time())}.jsonl")
        n_total = merge_dataset(base_jsonl, decisions_path, merged, probes_path)
        with _lock:
            base_n = n_total - n_decisions - n_probes
            _state.log_tail.append(
                f"merged dataset: {n_total} rows ({base_n} base + {n_decisions} decisions + {n_probes} probes)"
            )
            _state.progress = 0.05

        out_dir.mkdir(parents=True, exist_ok=True)

        # 2. Spawn the trainer.
        if stub:
            _run_stub_trainer(out_dir)
        else:
            _run_real_trainer(merged, out_dir)
            package_candidate_artifact(out_dir)
        validate_spider_artifact(out_dir)

        with _lock:
            _state.new_head_dir = str(out_dir)
            _state.state = "complete"
            _state.finished_ts = time.time()
            _state.progress = 1.0
            _state.log_tail.append(f"trainer complete → {out_dir.name}")
    except Exception as e:
        with _lock:
            _state.state = "error"
            _state.error = str(e)
            _state.finished_ts = time.time()
            _state.log_tail.append(f"error: {e}")


def _run_stub_trainer(out_dir: Path) -> None:
    """Fast simulation: 5s sleep + write a placeholder head that mirrors
    the v0.1 head's structure. Used for UI dev + CI."""
    for i in range(20):
        time.sleep(0.25)
        with _lock:
            _state.progress = 0.05 + 0.9 * (i + 1) / 20
            if i % 5 == 0:
                _state.log_tail.append(f"[stub] step {i*50}/1000  loss=0.{42-i:02d}")
    # Copy v0.1 head as a placeholder. The "new head" is the same weights;
    # the diff view will show no changes, which is honest for stub mode.
    src = DEFAULT_DIST_CURRENT
    if src.exists():
        for name in ("head.safetensors", "head_config.json", "calibration.json", "loader.py"):
            sf = src / name
            if sf.exists():
                shutil.copy2(sf, out_dir / name)
    (out_dir / "STUB").write_text("stub retrain — placeholder, weights identical to v0.1")
    with _lock:
        _state.log_tail.append("[stub] copied v0.1 head as placeholder")


def _run_real_trainer(merged_jsonl: Path, out_dir: Path) -> None:
    """Spawn train_classifier_v2.py via subprocess. Streams stdout into
    log_tail. The trainer expects DATASET_PATH as a module constant; we
    pass it via env var ORBWEAVER_TRAIN_DATASET (and rely on a small
    patch in the trainer that reads from env if set).

    Note: train_classifier_v2.py needs ~25 min on M-series for 1000 steps.
    This thread blocks until completion; UI polls /retrain-status to
    know when it's done."""
    env = os.environ.copy()
    env["ORBWEAVER_TRAIN_DATASET"] = str(merged_jsonl)
    env["ORBWEAVER_TRAIN_OUT"] = str(out_dir)
    cmd = [sys.executable, str(REPO_ROOT / "train_classifier_v2.py")]
    proc = subprocess.Popen(
        cmd, cwd=str(REPO_ROOT), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, bufsize=1,
    )
    assert proc.stdout is not None
    for line in proc.stdout:
        line = line.rstrip()
        with _lock:
            _state.log_tail.append(line)
            # Heuristic progress: parse "step N/M" if present.
            if "step " in line and "/" in line:
                try:
                    after = line.split("step ", 1)[1].split()[0]
                    cur, total = after.split("/")
                    _state.progress = 0.05 + 0.9 * float(cur) / float(total)
                except Exception:
                    pass
    code = proc.wait()
    if code != 0:
        raise RuntimeError(f"trainer exited with code {code}")


# ---------- artifact packaging ----------


def package_candidate_artifact(out_dir: Path, *,
                               current_dir: Path | None = None) -> None:
    """Normalize trainer output into the self-contained loader contract.

    `train_classifier_v2.py` writes a run-id safetensors file into the
    requested directory. The runtime loader expects SetFit-style names:
    head.safetensors + head_config.json + calibration.json + loader.py.
    """
    out_dir = Path(out_dir)
    current = current_dir or DEFAULT_DIST_CURRENT

    head_path = out_dir / "head.safetensors"
    if not head_path.exists():
        candidates = sorted(
            p for p in out_dir.glob("*.safetensors")
            if p.name != "head.safetensors"
        )
        if not candidates:
            raise FileNotFoundError(f"no safetensors head found in {out_dir}")
        shutil.copy2(candidates[-1], head_path)

    for name in ("head_config.json", "calibration.json", "loader.py"):
        dst = out_dir / name
        if dst.exists():
            continue
        src = current / name
        if not src.exists():
            raise FileNotFoundError(f"cannot package candidate; missing {src}")
        shutil.copy2(src, dst)

    _mark_candidate_version(out_dir / "head_config.json")


def _mark_candidate_version(config_path: Path) -> None:
    try:
        config = json.loads(config_path.read_text())
    except (FileNotFoundError, ValueError):
        return
    config["version"] = "v1.1-candidate"
    config.setdefault("training", {})
    config["training"]["packaged_by"] = "orbweaver.retrain_runner"
    config_path.write_text(json.dumps(config, indent=2) + "\n")


def validate_spider_artifact(spider_dir: Path) -> None:
    """Raise if a candidate cannot satisfy dist/loader.py's file contract."""
    spider_dir = Path(spider_dir)
    missing = [name for name in REQUIRED_ARTIFACT_FILES if not (spider_dir / name).exists()]
    if missing:
        raise FileNotFoundError(
            f"candidate spider artifact missing required files: {', '.join(missing)}"
        )

    config = json.loads((spider_dir / "head_config.json").read_text())
    calibration = json.loads((spider_dir / "calibration.json").read_text())
    if "base_model" not in config:
        raise ValueError("candidate head_config.json missing base_model")
    if "nonconformity_scores" not in calibration:
        raise ValueError("candidate calibration.json missing nonconformity_scores")


# ---------- hot swap ----------


def apply_new_head(*, dist_current: Path | None = None,
                   new_head_dir: Path | None = None) -> dict:
    """Atomically swap dist/<current> to the new head, archive old.
    Returns the swap record."""
    cur = dist_current or DEFAULT_DIST_CURRENT
    if new_head_dir is None:
        with _lock:
            if not _state.new_head_dir:
                return {"ok": False, "error": "no candidate head to apply"}
            new_head_dir = Path(_state.new_head_dir)
    new_head_dir = Path(new_head_dir)

    if not new_head_dir.exists():
        return {"ok": False, "error": f"candidate dir missing: {new_head_dir}"}
    try:
        validate_spider_artifact(new_head_dir)
    except Exception as e:
        return {"ok": False, "error": str(e)}

    # Archive the old head.
    archive_dir = cur.with_name(f"{cur.name}-archive-{int(time.time())}")
    if cur.exists():
        cur.rename(archive_dir)

    # Promote the candidate.
    new_head_dir.rename(cur)

    with _lock:
        _state.log_tail.append(f"applied: {new_head_dir.name} → {cur.name}")
        _state.state = "idle"
        _state.new_head_dir = ""

    return {
        "ok": True,
        "current": str(cur),
        "archive": str(archive_dir) if archive_dir.exists() else "",
    }
