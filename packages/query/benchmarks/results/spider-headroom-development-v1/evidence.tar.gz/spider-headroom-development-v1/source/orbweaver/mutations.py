"""Five-verb mutation vocabulary for orbweaver.

Every mutation must be invertible. No DELETE. No overwriting user-asserted
properties. The whole grammar lives here — if it's not in this file, orbweaver
cannot emit it.

Design choice: Pydantic discriminated union over a plain dict. Gives us
validation at parse time, clean serialisation for training data, and
IDE-friendly typing in the code that consumes mutations.
"""
from __future__ import annotations

import json
from typing import Annotated, Any, Literal, Union

from pydantic import BaseModel, Field, ValidationError


# ---------- verbs ----------

class AddLink(BaseModel):
    verb: Literal["add_link"] = "add_link"
    from_id: str
    to_id: str
    rel_type: str = Field(description="UPPER_SNAKE cypher relationship type")
    weight: float = Field(default=1.0, ge=0.0, le=1.0)
    rationale: str = ""


class AddReflection(BaseModel):
    verb: Literal["add_reflection"] = "add_reflection"
    reflection_id: str = Field(description="stable id for the new :Reflection node")
    summary: str
    source_ids: list[str] = Field(min_length=1, description="nodes being reflected on")
    embedding: list[float] | None = None
    rationale: str = ""


class MergeEntities(BaseModel):
    verb: Literal["merge_entities"] = "merge_entities"
    dup_id: str
    canonical_id: str
    confidence: float = Field(ge=0.0, le=1.0)
    rationale: str = ""


class AdjustWeight(BaseModel):
    verb: Literal["adjust_weight"] = "adjust_weight"
    # Neo4j relationships don't have stable ids by default. We identify via
    # endpoint ids + rel_type, matching the uniqueness guarantee orbweaver's
    # migrations create.
    from_id: str
    to_id: str
    rel_type: str
    delta: float = Field(description="additive change; clamped to [0,1] on apply")
    rationale: str = ""


class Deprecate(BaseModel):
    verb: Literal["deprecate"] = "deprecate"
    target_kind: Literal["node", "relationship"]
    target_id: str = Field(description="for relationships use <from>|<type>|<to>")
    reason: str
    rationale: str = ""


Mutation = Annotated[
    Union[AddLink, AddReflection, MergeEntities, AdjustWeight, Deprecate],
    Field(discriminator="verb"),
]


# ---------- parse / validate ----------

def validate_array(raw: str | list[dict[str, Any]]) -> list[Mutation]:
    """Parse and validate a mutation array produced by orbweaver. Never raises
    on valid-looking-but-unknown fields — Pydantic drops unknowns because
    models aren't configured with `extra='forbid'`, which is intentional for
    forward-compat with future verbs.
    """
    if isinstance(raw, str):
        raw = json.loads(raw)
    if not isinstance(raw, list):
        raise TypeError("expected a JSON array")

    out: list[Mutation] = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ValueError(f"mutation at index {i} is not an object: {item!r}")
        try:
            out.append(_dispatch(item))
        except ValidationError as e:
            raise ValueError(f"mutation at index {i} invalid: {e}") from e
    return out


def _dispatch(item: dict[str, Any]) -> Mutation:
    verb = item.get("verb")
    cls: type[BaseModel] | None = {
        "add_link": AddLink,
        "add_reflection": AddReflection,
        "merge_entities": MergeEntities,
        "adjust_weight": AdjustWeight,
        "deprecate": Deprecate,
    }.get(verb)
    if cls is None:
        raise ValueError(f"unknown verb: {verb!r}")
    return cls.model_validate(item)  # type: ignore[return-value]


# ---------- cypher emission ----------

# v1.0 HITL convention: when a mutation is staged for human review, the
# canonical graph is NOT mutated. Instead a SUGGESTED_<TYPE> rel (or a
# proposal property) is written so the canonical state is unchanged until
# `to_promote_cypher` runs. This is what makes the (:Edit) audit row
# auditable BEFORE the change lands. See docs/PROTOCOL.md.

def to_cypher(
    m: Mutation,
    *,
    tick_id: str,
    applied_by: str = "orbweaver",
    staged: bool = False,
    edit_id: str | None = None,
    signals_json: str = "{}",
) -> tuple[str, dict[str, Any]]:
    """Return (cypher, params) for a single mutation. Caller is responsible
    for wrapping these in a transaction and appending a ledger entry.

    When `staged=True`, returns Cypher that writes a *proposal* — for
    AddLink and MergeEntities this is a SUGGESTED_<TYPE> rel carrying the
    `edit_id` and the blocker `signals_json`. The canonical edge is NOT
    written. Promotion runs `to_promote_cypher`; rejection runs
    `to_reject_cypher`. Other verbs raise NotImplementedError under
    staged=True for v1.0; they apply directly via the trust-fall path.
    """
    if staged and edit_id is None:
        raise ValueError("staged=True requires edit_id")

    if isinstance(m, AddLink):
        if staged:
            cy = (
                "MATCH (a {id:$from_id}), (b {id:$to_id}) "
                f"MERGE (a)-[r:SUGGESTED_{_safe_rel(m.rel_type)} {{edit_id:$edit_id}}]->(b) "
                "ON CREATE SET r.weight=$weight, r.created_at=datetime(), "
                "               r.created_by=$applied_by, r.tick_id=$tick_id, "
                "               r.signals_json=$signals_json, "
                "               r.canonical_rel_type=$canonical_rel_type"
            )
            return cy, {
                "from_id": m.from_id, "to_id": m.to_id, "weight": m.weight,
                "applied_by": applied_by, "tick_id": tick_id,
                "edit_id": edit_id, "signals_json": signals_json,
                "canonical_rel_type": _safe_rel(m.rel_type),
            }
        cy = (
            "MATCH (a {id:$from_id}), (b {id:$to_id}) "
            f"MERGE (a)-[r:{_safe_rel(m.rel_type)}]->(b) "
            "ON CREATE SET r.weight=$weight, r.created_at=datetime(), "
            "               r.created_by=$applied_by, r.tick_id=$tick_id "
            "ON MATCH SET  r.weight=coalesce(r.weight, 0.0) + 0  // no-op on match"
        )
        return cy, {
            "from_id": m.from_id, "to_id": m.to_id, "weight": m.weight,
            "applied_by": applied_by, "tick_id": tick_id,
        }

    if isinstance(m, AddReflection):
        if staged:
            raise NotImplementedError("staged AddReflection lands in v1.0 week 2")
        cy = (
            "CREATE (r:Reflection {id:$rid, summary:$summary, "
            "                     source_ids:$src, created_by:$applied_by, "
            "                     created_at:datetime(), tick_id:$tick_id}) "
            "WITH r "
            "UNWIND $src AS sid "
            "MATCH (s {id: sid}) "
            "MERGE (r)-[:REFLECTS_ON {created_at: datetime()}]->(s)"
        )
        return cy, {
            "rid": m.reflection_id, "summary": m.summary, "src": m.source_ids,
            "applied_by": applied_by, "tick_id": tick_id,
        }

    if isinstance(m, MergeEntities):
        if staged:
            cy = (
                "MATCH (d {id:$dup}), (c {id:$can}) "
                "MERGE (d)-[r:SUGGESTED_SAME_AS {edit_id:$edit_id}]->(c) "
                "ON CREATE SET r.confidence=$conf, r.created_by=$applied_by, "
                "               r.created_at=datetime(), r.tick_id=$tick_id, "
                "               r.signals_json=$signals_json"
            )
            return cy, {
                "dup": m.dup_id, "can": m.canonical_id, "conf": m.confidence,
                "applied_by": applied_by, "tick_id": tick_id,
                "edit_id": edit_id, "signals_json": signals_json,
            }
        cy = (
            "MATCH (d {id:$dup}), (c {id:$can}) "
            "MERGE (d)-[r:SAME_AS]->(c) "
            "ON CREATE SET r.confidence=$conf, r.created_by=$applied_by, "
            "               r.created_at=datetime(), r.tick_id=$tick_id, "
            "               r.status='merged'"
        )
        return cy, {
            "dup": m.dup_id, "can": m.canonical_id, "conf": m.confidence,
            "applied_by": applied_by, "tick_id": tick_id,
        }

    if isinstance(m, AdjustWeight):
        if staged:
            raise NotImplementedError("staged AdjustWeight lands in v1.0 week 2")
        cy = (
            f"MATCH (a {{id:$from_id}})-[r:{_safe_rel(m.rel_type)}]->(b {{id:$to_id}}) "
            "SET r.weight = CASE "
            "    WHEN coalesce(r.weight, 1.0) + $delta < 0.0 THEN 0.0 "
            "    WHEN coalesce(r.weight, 1.0) + $delta > 1.0 THEN 1.0 "
            "    ELSE coalesce(r.weight, 1.0) + $delta END, "
            "    r.last_adjusted_at = datetime(), r.last_adjusted_by = $applied_by, "
            "    r.tick_id = $tick_id "
            "RETURN r.weight AS new_weight"
        )
        return cy, {
            "from_id": m.from_id, "to_id": m.to_id, "delta": m.delta,
            "applied_by": applied_by, "tick_id": tick_id,
        }

    if isinstance(m, Deprecate):
        if staged:
            raise NotImplementedError("staged Deprecate lands in v1.0 week 2")
        if m.target_kind == "node":
            cy = (
                "MATCH (n {id:$tid}) SET n.deprecated=true, n.deprecated_reason=$reason, "
                "n.deprecated_at=datetime(), n.deprecated_by=$applied_by, n.tick_id=$tick_id"
            )
            return cy, {
                "tid": m.target_id, "reason": m.reason,
                "applied_by": applied_by, "tick_id": tick_id,
            }
        # relationship: id is "<from>|<type>|<to>"
        parts = m.target_id.split("|")
        if len(parts) != 3:
            raise ValueError("relationship target_id must be '<from>|<type>|<to>'")
        from_id, rel_type, to_id = parts
        cy = (
            f"MATCH (a {{id:$from_id}})-[r:{_safe_rel(rel_type)}]->(b {{id:$to_id}}) "
            "SET r.deprecated=true, r.deprecated_reason=$reason, "
            "r.deprecated_at=datetime(), r.deprecated_by=$applied_by, r.tick_id=$tick_id"
        )
        return cy, {
            "from_id": from_id, "to_id": to_id, "reason": m.reason,
            "applied_by": applied_by, "tick_id": tick_id,
        }

    raise TypeError(f"unknown mutation: {m!r}")


# ---------- staged → canonical (HITL promote/reject) ----------

def to_promote_cypher(m: Mutation, *, edit_id: str, applied_by: str = "orbweaver",
                      tick_id: str = "promote") -> tuple[str, dict[str, Any]]:
    """Translate a staged proposal (SUGGESTED_<TYPE> rel) into the canonical
    edge, in one transaction. Run when a reviewer accepts the suggestion.
    """
    if isinstance(m, AddLink):
        rel = _safe_rel(m.rel_type)
        cy = (
            f"MATCH (a {{id:$from_id}})-[r:SUGGESTED_{rel} {{edit_id:$edit_id}}]->(b {{id:$to_id}}) "
            f"MERGE (a)-[c:{rel}]->(b) "
            "ON CREATE SET c.weight=r.weight, c.created_at=datetime(), "
            "               c.created_by=$applied_by, c.tick_id=$tick_id, "
            "               c.from_edit_id=$edit_id "
            "DELETE r"
        )
        return cy, {
            "from_id": m.from_id, "to_id": m.to_id,
            "edit_id": edit_id, "applied_by": applied_by, "tick_id": tick_id,
        }
    if isinstance(m, MergeEntities):
        cy = (
            "MATCH (d {id:$dup})-[r:SUGGESTED_SAME_AS {edit_id:$edit_id}]->(c {id:$can}) "
            "MERGE (d)-[s:SAME_AS]->(c) "
            "ON CREATE SET s.confidence=r.confidence, s.created_at=datetime(), "
            "               s.created_by=$applied_by, s.tick_id=$tick_id, "
            "               s.from_edit_id=$edit_id, s.status='merged' "
            "DELETE r"
        )
        return cy, {
            "dup": m.dup_id, "can": m.canonical_id,
            "edit_id": edit_id, "applied_by": applied_by, "tick_id": tick_id,
        }
    raise NotImplementedError(f"to_promote_cypher for {type(m).__name__} lands in v1.0 week 2")


def to_reject_cypher(m: Mutation, *, edit_id: str) -> tuple[str, dict[str, Any]]:
    """Delete the SUGGESTED_<TYPE> artifacts when a reviewer rejects. The
    canonical graph is unchanged because staged Cypher never wrote it.
    """
    if isinstance(m, AddLink):
        rel = _safe_rel(m.rel_type)
        cy = (
            f"MATCH (a {{id:$from_id}})-[r:SUGGESTED_{rel} {{edit_id:$edit_id}}]->(b {{id:$to_id}}) "
            "DELETE r"
        )
        return cy, {"from_id": m.from_id, "to_id": m.to_id, "edit_id": edit_id}
    if isinstance(m, MergeEntities):
        cy = (
            "MATCH (d {id:$dup})-[r:SUGGESTED_SAME_AS {edit_id:$edit_id}]->(c {id:$can}) "
            "DELETE r"
        )
        return cy, {"dup": m.dup_id, "can": m.canonical_id, "edit_id": edit_id}
    raise NotImplementedError(f"to_reject_cypher for {type(m).__name__} lands in v1.0 week 2")


# ---------- inverses (for undo ledger) ----------

def invert(m: Mutation) -> Mutation:
    """Return the mutation that undoes this one. Call BEFORE apply so the
    inverse captures current state where needed.
    """
    if isinstance(m, AddLink):
        return Deprecate(
            target_kind="relationship",
            target_id=f"{m.from_id}|{m.rel_type}|{m.to_id}",
            reason="inverse of add_link",
        )
    if isinstance(m, AddReflection):
        return Deprecate(target_kind="node", target_id=m.reflection_id, reason="inverse of add_reflection")
    if isinstance(m, MergeEntities):
        return Deprecate(
            target_kind="relationship",
            target_id=f"{m.dup_id}|SAME_AS|{m.canonical_id}",
            reason="inverse of merge_entities",
        )
    if isinstance(m, AdjustWeight):
        return AdjustWeight(
            from_id=m.from_id, to_id=m.to_id, rel_type=m.rel_type,
            delta=-m.delta, rationale="inverse of adjust_weight",
        )
    if isinstance(m, Deprecate):
        # Inverse of a soft-delete is un-deprecation. Modelled as a distinct
        # verb in a future revision; for now we return a placeholder that the
        # apply layer knows to translate to "remove deprecation flags".
        return Deprecate(
            target_kind=m.target_kind, target_id=m.target_id,
            reason="__undeprecate__",
        )
    raise TypeError(f"unknown mutation: {m!r}")


# ---------- helpers ----------

_REL_ALLOWED = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789")

def _safe_rel(rel_type: str) -> str:
    """Defensive rel-type check. Cypher doesn't allow parameterising rel types
    in MATCH/MERGE, so we have to inline them — which means we MUST refuse
    anything that could be a cypher-injection payload.
    """
    if not rel_type or not rel_type[0].isalpha():
        raise ValueError(f"bad rel_type (must start with letter): {rel_type!r}")
    if any(ch not in _REL_ALLOWED for ch in rel_type):
        raise ValueError(f"bad rel_type (chars outside A-Z/0-9/_): {rel_type!r}")
    return rel_type


# ---------- schema migration ----------

SCHEMA_MIGRATION_CYPHER = [
    # Reflection node label
    "CREATE CONSTRAINT reflection_id IF NOT EXISTS FOR (r:Reflection) REQUIRE r.id IS UNIQUE",
    # MutationLedgerEntry
    "CREATE CONSTRAINT mutation_ledger_id IF NOT EXISTS FOR (m:MutationLedgerEntry) REQUIRE m.id IS UNIQUE",
    # Indexes that help orbweaver reads
    "CREATE INDEX reflection_created_at IF NOT EXISTS FOR (r:Reflection) ON (r.created_at)",
    "CREATE INDEX deprecated_nodes IF NOT EXISTS FOR (n) ON (n.deprecated)",
]
"""Apply once per target graph before orbweaver starts tending."""
