"""CV+ jackknife with Adaptive Prediction Sets per third compass artifact §1.

> "Use CV+ (jackknife+ with K=10) with Adaptive Prediction Sets scoring
>  over all 354 examples; refitting a 17K-parameter head ten times is
>  free."

The trick that makes K=10 refits cheap: the base is frozen, so we
precompute the 354 last-token hidden states ONCE (~5 min total), cache
them as a [354, hidden_size] matrix, then re-train the tiny
ClassifierHead on each fold using just those vectors. Per-fold training
becomes pure 17K-parameter linear-stack optimisation.

## APS scoring (Romano, Sesia, Candès 2020)

For an example with true class y* and softmax probabilities π:
  score = Σ_{i: π_i > π_y*} π_i  +  u · π_y*
where u ~ Uniform(0, 1) is a tie-breaker. Lower score = model is more
"right" (true class near the top of the ranking).

At target coverage 1−α, the threshold τ̂ is the (1−α)-quantile of the
calibration set's nonconformity scores. The prediction set for a new
example is built by adding classes in descending π order until cumulative
mass first exceeds τ̂. This achieves marginal coverage ≥ 1−α
distribution-free.

## Adaptive Conformal Inference (Gibbs & Candès 2021, JMLR 2024)

The threshold drifts online: τ̂_t+1 = τ̂_t + γ · (1{y_t ∉ Ĉ(x_t)} − α)
with γ ≈ 0.005. Maintains long-run coverage even when the graph
distribution drifts. Implemented as `ACIThresholdTracker`.

## Two predict_set implementations — by design

This module's `aps_predict_set` is the *randomized* APS variant from the
Romano-Sesia-Candès paper: a uniform random tie-breaker (`u`) gives the
true marginal-coverage guarantee. It's used by the offline calibration
script (`calibrate_classifier.py`) to compute nonconformity scores that
match the published guarantee.

The shipped *production* path uses `dist/.../loader.py:predict_set`,
which is fully **deterministic** — same input always produces the same
prediction set. This is intentional: a reviewer needs reproducible
decisions for the same graph state, and the deterministic version is
strictly more cautious (slightly larger sets in tie cases) than the
randomized one. The trade is "publication-faithful coverage guarantee"
vs "demo-grade reproducibility"; v1.1 picks the latter for the user-
facing surface.

If you're writing inference code that ships, prefer the loader's
`predict_set`. If you're computing calibration thresholds offline,
use the randomized version here.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence

import numpy as np


# ---------- APS scoring ----------

def aps_score(probs: np.ndarray, true_class: int, *,
              rng: np.random.Generator | None = None) -> float:
    """Adaptive Prediction Set nonconformity score.

    `probs` is a [n_classes] softmax distribution; `true_class` is the
    integer label. Lower score = model ranks the true class higher.
    """
    if rng is None:
        rng = np.random.default_rng()
    p_true = float(probs[true_class])
    # Sum of probabilities of all classes strictly above the true class
    higher_mass = float(probs[probs > p_true].sum())
    # Random tie-breaker uniformly within the true-class probability
    u = float(rng.uniform(0.0, 1.0))
    return higher_mass + u * p_true


def aps_predict_set(probs: np.ndarray, tau: float, *,
                    rng: np.random.Generator | None = None) -> list[int]:
    """Build a prediction set by adding classes in descending π order
    until cumulative mass first exceeds τ̂.

    Returns the list of class indices in the prediction set, in
    descending probability order. Always non-empty.
    """
    if rng is None:
        rng = np.random.default_rng()
    order = np.argsort(-probs)
    cum = 0.0
    result: list[int] = []
    for k, idx in enumerate(order):
        result.append(int(idx))
        # Randomized inclusion at the last step (Romano et al.)
        p_idx = float(probs[idx])
        if cum + p_idx >= tau:
            # Decide whether to drop the last (randomised threshold)
            u = float(rng.uniform(0.0, 1.0))
            if u * p_idx > tau - cum:
                # Drop the just-added last class — but only if we've at least one
                if len(result) > 1:
                    result.pop()
            return result
        cum += p_idx
    return result


# ---------- threshold from calibration scores ----------

def aps_threshold(calibration_scores: Sequence[float], target_coverage: float) -> float:
    """Compute τ̂ as the ⌈(n+1)(1-α)⌉-th smallest nonconformity score
    where α = 1 - target_coverage. The +1 finite-sample correction is
    Vovk et al.'s standard."""
    n = len(calibration_scores)
    if n == 0:
        return 1.0
    alpha = 1.0 - target_coverage
    sorted_scores = sorted(calibration_scores)
    # Index for the (1-α)-quantile with finite-sample correction
    q_idx = int(np.ceil((n + 1) * (1 - alpha))) - 1
    q_idx = max(0, min(q_idx, n - 1))
    return float(sorted_scores[q_idx])


# ---------- Adaptive Conformal Inference (Gibbs–Candès) ----------

@dataclass
class ACIThresholdTracker:
    """Online τ̂ updater per Gibbs & Candès 2021.

    On each new (x_t, y_t):
      miss = 1 if y_t ∉ Ĉ(x_t) else 0
      τ̂_t+1 = τ̂_t + γ · (miss − α)
    Maintains long-run coverage 1−α even under distribution drift.
    """
    target_coverage: float = 0.9
    gamma: float = 0.005
    tau: float = 1.0
    history: list[dict] = field(default_factory=list)

    @property
    def alpha(self) -> float:
        return 1.0 - self.target_coverage

    def update(self, miss: bool) -> float:
        delta = self.gamma * ((1.0 if miss else 0.0) - self.alpha)
        self.tau = max(0.0, min(1.0, self.tau + delta))
        self.history.append({"miss": int(miss), "tau": self.tau})
        return self.tau

    def to_json(self) -> str:
        return json.dumps({
            "target_coverage": self.target_coverage,
            "gamma": self.gamma,
            "tau": self.tau,
            "n_updates": len(self.history),
        })


# ---------- precompute hidden states ----------

def precompute_hidden_states(
    base_model, tokenizer, examples: list[tuple[list[int], int]],
) -> tuple[np.ndarray, np.ndarray]:
    """Run the FROZEN base on each example, return (X, y) where X is a
    [n, hidden_size] np.ndarray of last-token hidden states and y is
    [n] int labels."""
    import mlx.core as mx
    Xs: list[np.ndarray] = []
    ys: list[int] = []
    for ids, label in examples:
        x = mx.array([ids])
        hidden = base_model.model(x)        # [1, T, H], typically bf16
        last = hidden[:, -1, :]              # [1, H]
        # Cast to float32 before numpy conversion — mlx bf16 doesn't
        # round-trip through np.asarray on every platform.
        last_f32 = last.astype(mx.float32)
        mx.eval(last_f32)
        Xs.append(np.array(last_f32)[0])
        ys.append(int(label))
    X = np.stack(Xs).astype(np.float32)
    y = np.array(ys, dtype=np.int32)
    return X, y


# ---------- K-fold training of ClassifierHead on cached hiddens ----------

def kfold_calibrate(
    X: np.ndarray, y: np.ndarray, *,
    head_factory, k_folds: int = 10, n_classes: int = 6,
    steps_per_fold: int = 200, lr: float = 1e-2, batch: int = 8,
    class_balanced: bool = True, seed: int = 0,
) -> tuple[list[float], list[int], list[int]]:
    """K-fold CV+: for each fold, train a fresh head on the other folds'
    cached (X, y) and emit the held-out fold's APS nonconformity scores.

    Returns (scores, true_labels, predicted_labels) of length n.
    `head_factory()` should return a fresh ClassifierHead.
    """
    import mlx.core as mx
    import mlx.nn as nn
    import mlx.optimizers as optim

    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(y))
    fold_size = len(y) // k_folds

    scores: list[float] = [0.0] * len(y)
    preds: list[int] = [0] * len(y)
    true_labels: list[int] = [0] * len(y)

    for fold in range(k_folds):
        held_out = perm[fold * fold_size : (fold + 1) * fold_size]
        if fold == k_folds - 1:
            held_out = perm[fold * fold_size :]
        train_mask = np.ones(len(y), dtype=bool)
        train_mask[held_out] = False
        Xtr, ytr = X[train_mask], y[train_mask]
        Xte, yte = X[held_out], y[held_out]

        # Class-balanced sampler
        if class_balanced:
            by_class = [np.where(ytr == c)[0] for c in range(n_classes)]
            by_class = [b if len(b) > 0 else np.array([0]) for b in by_class]

        head = head_factory()
        mx.eval(head.parameters())
        opt = optim.AdamW(learning_rate=lr, betas=(0.9, 0.95), weight_decay=0.01)

        # Class weights
        counts = np.bincount(ytr, minlength=n_classes).astype(np.float32)
        raw_w = 1.0 / np.maximum(counts, 1)
        mean_w = raw_w.mean()
        weights = np.minimum(5.0, raw_w / mean_w)
        cw = mx.array(weights.tolist(), dtype=mx.float32)

        def loss_fn(model, x_arr, y_arr):
            logits = model(x_arr)
            per_ex = nn.losses.cross_entropy(logits, y_arr, reduction="none")
            wts = cw[y_arr]
            return mx.sum(per_ex * wts) / mx.maximum(mx.sum(wts), mx.array(1e-6))

        loss_and_grad = nn.value_and_grad(head, loss_fn)

        for step in range(steps_per_fold):
            if class_balanced:
                cls = step % n_classes
                idxs = rng.choice(by_class[cls], size=batch, replace=True)
            else:
                idxs = rng.choice(len(Xtr), size=batch, replace=False)
            xb = mx.array(Xtr[idxs])
            yb = mx.array(ytr[idxs].astype(np.int32))
            _, grads = loss_and_grad(head, xb, yb)
            opt.update(head, grads)
            mx.eval(head.parameters(), opt.state)

        # Predict on held-out
        head.eval()
        for i_local, i_global in enumerate(held_out):
            xv = mx.array(Xte[i_local:i_local + 1])
            logits = head(xv)
            mx.eval(logits)
            arr = np.asarray(logits[0])
            arr = arr - arr.max()
            probs = np.exp(arr) / np.exp(arr).sum()
            true_c = int(yte[i_local])
            pred_c = int(np.argmax(probs))
            scores[i_global] = aps_score(probs, true_c, rng=rng)
            preds[i_global] = pred_c
            true_labels[i_global] = true_c

    return scores, true_labels, preds


# ---------- save / load calibration ----------

@dataclass
class CalibrationArtifact:
    nonconformity_scores: list[float]
    target_coverage: float = 0.9
    method: str = "CV+ APS"
    k_folds: int = 10
    n_classes: int = 6
    notes: str = ""

    def threshold_for(self, target_coverage: float | None = None) -> float:
        return aps_threshold(self.nonconformity_scores,
                             target_coverage or self.target_coverage)

    def to_json(self) -> str:
        return json.dumps({
            "method": self.method,
            "k_folds": self.k_folds,
            "n_classes": self.n_classes,
            "target_coverage": self.target_coverage,
            "n_calibration": len(self.nonconformity_scores),
            "tau_at_target": self.threshold_for(),
            "nonconformity_scores": self.nonconformity_scores,
            "notes": self.notes,
        }, indent=2)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json())

    @classmethod
    def load(cls, path: str | Path) -> "CalibrationArtifact":
        d = json.loads(Path(path).read_text())
        return cls(
            nonconformity_scores=d["nonconformity_scores"],
            target_coverage=d.get("target_coverage", 0.9),
            method=d.get("method", "CV+ APS"),
            k_folds=d.get("k_folds", 10),
            n_classes=d.get("n_classes", 6),
            notes=d.get("notes", ""),
        )
