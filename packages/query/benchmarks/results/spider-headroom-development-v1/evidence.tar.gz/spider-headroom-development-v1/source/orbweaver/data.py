"""SFT dataset: JSONL rows -> tokenised, loss-masked, padded batches.

Qwen3 chat template wraps (system, user, assistant). Loss mask is 1 only
over the assistant span, so the model is trained to emit mutation arrays,
not to reproduce the schema description or the graph snapshot.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

import numpy as np


SYSTEM_PROMPT = """\
You are orbweaver, a specialist graph-memory maintainer. Your only job is to
propose graph mutations that improve retrieval quality.

You may emit ONLY these verbs, as a JSON array of objects:
  - add_link     {verb, from_id, to_id, rel_type, weight, rationale}
  - add_reflection {verb, reflection_id, summary, source_ids[], rationale}
  - merge_entities {verb, dup_id, canonical_id, confidence, rationale}
  - adjust_weight  {verb, from_id, to_id, rel_type, delta, rationale}
  - deprecate      {verb, target_kind: "node"|"relationship", target_id, reason, rationale}

Invariants:
  - Never DELETE anything. `deprecate` is a soft flag.
  - Never overwrite user-asserted facts.
  - Every mutation must be reasonable given the snapshot and events.
  - Output MUST be a valid JSON array. No markdown fences. No commentary.

Output only the JSON array. Nothing before or after.
"""


@dataclass
class Example:
    id: str
    graph_snapshot_cypher: str
    events: list[dict]
    expected_mutations: list[dict]

    @classmethod
    def from_jsonl_line(cls, line: str) -> "Example":
        row = json.loads(line)
        return cls(
            id=row["id"],
            graph_snapshot_cypher=row["graph_snapshot_cypher"],
            events=row.get("events_since_last_tick", []),
            expected_mutations=row["expected_mutations"],
        )


def build_chat_messages(ex: Example) -> list[dict]:
    user = (
        "## Current graph snapshot\n"
        f"{ex.graph_snapshot_cypher}\n\n"
        "## Events since last pass\n"
        + "\n".join(json.dumps(e, separators=(",", ":")) for e in ex.events)
        + "\n\nEmit the mutation array."
    )
    assistant = json.dumps(ex.expected_mutations, separators=(",", ":"))
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user},
        {"role": "assistant", "content": assistant},
    ]


# ---------- tokenisation ----------

def tokenize_example(tokenizer, ex: Example, *, max_len: int = 8192) -> dict:
    """Returns {input_ids, labels, loss_mask} as numpy arrays.

    `labels == input_ids` except positions where loss_mask==0 are set to -100
    so cross-entropy ignores them. This is redundant with loss_mask but
    matches the convention used by HF Trainer / mlx-lm.

    ## Qwen3-Instruct-2507 chat-template quirk

    `apply_chat_template(msgs, add_generation_prompt=False)` on a message
    list with assistant content injects an empty `<think>\\n\\n</think>\\n\\n`
    wrapper at the start of every assistant turn — regardless of
    `enable_thinking=False`. The non-thinking variant was post-trained with
    this wrapper present in history, so the template hardcodes it.

    If we let this wrapper into training data, the loss-masked span starts
    at `<think>` and the model is trained to emit the wrapper first. But
    `add_generation_prompt=True` (used at inference) does NOT append the
    wrapper — it ends at `<|im_start|>assistant\\n`. The mismatch means the
    trained model sees a different prefix at inference than at training,
    and its first-token distribution collapses to either `<|im_end|>`
    (empty output) or tool-call artifacts.

    Fix: bypass `apply_chat_template` for the full sequence. Build the
    prefix via `add_generation_prompt=True` (matches inference exactly),
    tokenize the raw JSON assistant content, and terminate with
    `<|im_end|>`. No think wrapper anywhere. The base model's natural
    distribution already emits `[` directly after `<|im_start|>assistant\\n`,
    so training aligns with — rather than fights — that prior.
    """
    import json as _json

    prefix_ids: list[int] = tokenizer.apply_chat_template(
        build_chat_messages(ex)[:-1],
        add_generation_prompt=True, tokenize=True,
    )

    assistant_text = _json.dumps(ex.expected_mutations, separators=(",", ":"))
    # mlx-lm's TokenizerWrapper exposes .encode(); it does not add BOS
    # on plain text for Qwen3, so we don't need an add_special_tokens flag.
    assistant_ids: list[int] = list(tokenizer.encode(assistant_text))

    im_end_id = tokenizer.convert_tokens_to_ids("<|im_end|>")
    full_ids: list[int] = list(prefix_ids) + list(assistant_ids) + [im_end_id]

    # Truncate from the LEFT if needed — we always want to keep the assistant tail.
    if len(full_ids) > max_len:
        overflow = len(full_ids) - max_len
        full_ids = full_ids[overflow:]
        prefix_len = max(0, len(prefix_ids) - overflow)
    else:
        prefix_len = len(prefix_ids)

    loss_mask = np.zeros(len(full_ids), dtype=np.int32)
    loss_mask[prefix_len:] = 1

    input_ids = np.array(full_ids, dtype=np.int32)
    labels = input_ids.copy()
    labels[loss_mask == 0] = -100
    return {"input_ids": input_ids, "labels": labels, "loss_mask": loss_mask}


class MutationDataset:
    """Simple JSONL-backed dataset. Tokenises on access to keep memory bounded;
    for a 10k-example set this is ~100 MB of int32 IDs which easily fits, but
    we prefer the generator interface so this also works for larger corpora.
    """

    def __init__(self, path: str | Path, tokenizer, max_len: int = 8192):
        self.path = Path(path)
        self.tokenizer = tokenizer
        self.max_len = max_len
        self._examples: list[Example] = []
        with self.path.open() as f:
            for line in f:
                line = line.strip()
                if line:
                    self._examples.append(Example.from_jsonl_line(line))

    def __len__(self) -> int:
        return len(self._examples)

    def __getitem__(self, idx: int) -> dict:
        return tokenize_example(self.tokenizer, self._examples[idx], max_len=self.max_len)

    def __iter__(self) -> Iterator[dict]:
        for i in range(len(self)):
            yield self[i]


def collate_packed(batch: list[dict], pad_id: int) -> dict:
    """Right-pad to the longest sequence in the batch. Returns arrays of shape
    (B, T). Keeps it simple; switching to best-fit packing is a later win.
    """
    max_t = max(len(x["input_ids"]) for x in batch)
    B = len(batch)
    inp = np.full((B, max_t), pad_id, dtype=np.int32)
    lab = np.full((B, max_t), -100, dtype=np.int32)
    msk = np.zeros((B, max_t), dtype=np.int32)
    for i, x in enumerate(batch):
        L = len(x["input_ids"])
        inp[i, :L] = x["input_ids"]
        lab[i, :L] = x["labels"]
        msk[i, :L] = x["loss_mask"]
    return {"input_ids": inp, "labels": lab, "loss_mask": msk}
