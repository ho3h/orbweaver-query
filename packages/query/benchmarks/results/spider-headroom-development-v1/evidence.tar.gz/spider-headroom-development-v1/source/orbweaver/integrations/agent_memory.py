"""One-function entry point that `neo4j-labs/agent-memory` (or any
plugin wrapping it) can import to wire orbweaver into its lifecycle.

Wicked-simple integration model: orbweaver does NOT ship an OpenClaw
plugin in v1.0. Anyone who wants one writes ~100 LOC in their own repo
that calls `tend(memory_client)` from this module. The plugin owns its
own scheduling, error handling, and surface area; orbweaver owns the
classifier + the audit log + the reviewer UI.

Typical wiring inside an OpenClaw plugin:

    from orbweaver.integrations.agent_memory import tend

    def on_token_threshold(memory_client):
        '''Fires when the agent's context hits ~30K tokens — the existing
        agent-memory hook for "summarize / consolidate".'''
        result = tend(memory_client)
        if result.staged > 0:
            log.info(f'orbweaver staged {result.staged} suggestions; '
                     f'open `orbweaver review` to triage')

The function is idempotent at the (:Edit) level — active suggestions are
deduped by verb + target_id. Re-running tend on the same graph state is safe.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import Any

from ..spider import TickResult, tick

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_SPIDER_DIR = REPO_ROOT / "dist" / "orbweaver-qwen3-4b-spider-v0.1"


def tend(memory_client: Any, *,
         spider_dir: Path | None = None,
         max_candidates: int = 50,
         max_stage: int = 20,
         target_coverage: float | None = None) -> TickResult:
    """Run one orbweaver tick against the graph backing `memory_client`.

    `memory_client` is expected to expose a `.driver` attribute (the
    neo4j-py GraphDatabase driver) — this is the convention
    `neo4j-labs/agent-memory`'s MemoryClient already follows. If your
    client is differently shaped, pass `memory_client=client.driver`
    directly; we accept either.

    Returns the same TickResult the standalone CLI returns (counts of
    candidates_seen / staged / skipped_*). Suggestions land as
    `(:Edit {status:'Staged'})` rows + `:SUGGESTED_<TYPE>` edges in the
    same graph; the reviewer surface (`orbweaver review`) reads these
    directly.
    """
    driver = getattr(memory_client, "driver", memory_client)

    spider_path = spider_dir or DEFAULT_SPIDER_DIR
    loader_file = Path(spider_path) / "loader.py"
    if not loader_file.exists():
        raise FileNotFoundError(f"no spider loader at {loader_file}")
    if "orbweaver_loader" not in sys.modules:
        spec = importlib.util.spec_from_file_location("orbweaver_loader", loader_file)
        mod = importlib.util.module_from_spec(spec)
        sys.modules["orbweaver_loader"] = mod
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
    loader = sys.modules["orbweaver_loader"]
    spider = loader.load_spider(str(spider_path))
    if target_coverage is not None:
        spider.target_coverage = float(target_coverage)

    return tick(driver, spider, max_candidates=max_candidates, max_stage=max_stage)
