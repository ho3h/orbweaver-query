"""Single-file reviewer http server. Serves review.html + a small JSON API
that the page polls. No FastAPI, no Vite, no React. ~80 LOC of
http.server.BaseHTTPRequestHandler is the whole surface.

Endpoints:
  GET  /            → review.html
  GET  /queue       → list of staged edits (pollable, ~2s tick)
  POST /promote/{id}  → audit_log.promote (JSON body: {"decided_by":"..."})
  POST /reject/{id}   → audit_log.reject  (JSON body: {"decided_by":"...","reason":"..."})
  POST /undo/{id}     → audit_log.undo
  GET  /stats       → counts by status + reversal_rate_24h

The driver is shared across requests (cheap; the underlying neo4j-py
driver is thread-safe). One server instance per CLI run.
"""
from __future__ import annotations

import json
import logging
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from . import audit_log, retrain_runner

log = logging.getLogger("orbweaver.review")
HTML_PATH = Path(__file__).resolve().parent / "review.html"

# Threshold of new decisions before the Retrain button activates. Set via
# query param ?retrain_threshold=N or env ORBWEAVER_RETRAIN_THRESHOLD.
DEFAULT_RETRAIN_THRESHOLD = int(__import__("os").environ.get("ORBWEAVER_RETRAIN_THRESHOLD", "20"))

# Cutoff for "new" decisions — initialized at server start. Decisions with
# decided_ts >= this count toward the progress bar.
_session_started_ts = 0.0


class ReviewerHandler(BaseHTTPRequestHandler):
    # Set by start_server() before serving.
    driver = None  # type: ignore[assignment]

    def _send(self, status: int, body: bytes, ctype: str = "application/json"):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, status: int, payload):
        self._send(status, json.dumps(payload).encode("utf-8"))

    def log_message(self, format, *args):  # quiet the default per-request log
        pass

    # ---- routing ----

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            try:
                self._send(200, HTML_PATH.read_bytes(), "text/html; charset=utf-8")
            except FileNotFoundError:
                self._send(500, b"review.html missing", "text/plain")
            return
        if path == "/queue":
            staged = audit_log.list_staged(self.driver, limit=200)
            return self._send_json(200, {"staged": staged})
        if path == "/audit":
            # Recent edits across all statuses — feeds the unified queue+history view.
            with self.driver.session() as s:
                rows = list(s.run(
                    "MATCH (e:Edit) RETURN e ORDER BY e.ts DESC LIMIT $n",
                    n=200,
                ))
            return self._send_json(200, {"edits": [dict(r["e"]) for r in rows]})
        if path == "/stats":
            return self._send_json(200, {
                "by_status": audit_log.stats(self.driver),
                "reversal_rate_24h": audit_log.reversal_rate_24h(self.driver),
            })
        if path == "/decisions-progress":
            n = retrain_runner.count_pending_decisions(
                self.driver, since_ts=_session_started_ts,
            )
            return self._send_json(200, {
                "decisions_since_session": n,
                "threshold": DEFAULT_RETRAIN_THRESHOLD,
                "session_started_ts": _session_started_ts,
                "ready": n >= DEFAULT_RETRAIN_THRESHOLD and not retrain_runner.is_running(),
            })
        if path == "/decision-curve":
            # Time-ordered reviewer decisions for the live curve panel.
            # Feeds two derived series client-side: cumulative-decisions and
            # rolling-window accept rate. The endpoint stays dumb (raw rows);
            # all smoothing happens in the browser so the same shape works
            # for tools/launch_chart.py too.
            with self.driver.session() as s:
                rows = list(s.run(
                    "MATCH (e:Edit) "
                    "WHERE e.status IN ['Applied', 'Rejected', 'Undone'] "
                    "  AND e.decided_ts IS NOT NULL "
                    "RETURN e.decided_ts AS ts, e.status AS status, "
                    "       e.verb AS verb, e.confidence AS confidence "
                    "ORDER BY e.decided_ts ASC"
                ))
            return self._send_json(200, {
                "decisions": [
                    {"ts": float(r["ts"]), "status": r["status"],
                     "verb": r["verb"],
                     "confidence": float(r["confidence"] or 0.0)}
                    for r in rows
                ],
                "session_started_ts": _session_started_ts,
            })
        if path == "/retrain-status":
            return self._send_json(200, retrain_runner.status())
        return self._send(404, b"not found", "text/plain")

    def do_POST(self):
        path = urlparse(self.path).path
        body = self._read_body()

        if path.startswith("/promote/"):
            edit_id = path[len("/promote/"):]
            try:
                audit_log.promote(self.driver, edit_id,
                                  decided_by=body.get("decided_by", "reviewer"))
                return self._send_json(200, {"ok": True, "edit_id": edit_id, "status": "Applied"})
            except Exception as e:
                return self._send_json(400, {"ok": False, "error": str(e)})

        if path.startswith("/reject/"):
            edit_id = path[len("/reject/"):]
            try:
                audit_log.reject(self.driver, edit_id,
                                 decided_by=body.get("decided_by", "reviewer"),
                                 reason=body.get("reason", ""))
                return self._send_json(200, {"ok": True, "edit_id": edit_id, "status": "Rejected"})
            except Exception as e:
                return self._send_json(400, {"ok": False, "error": str(e)})

        if path.startswith("/undo/"):
            edit_id = path[len("/undo/"):]
            try:
                audit_log.undo(self.driver, edit_id,
                               decided_by=body.get("decided_by", "reviewer"))
                return self._send_json(200, {"ok": True, "edit_id": edit_id, "status": "Undone"})
            except Exception as e:
                return self._send_json(400, {"ok": False, "error": str(e)})

        if path == "/retrain":
            try:
                stub = bool(body.get("stub", False))
                snap = retrain_runner.start_retrain(
                    self.driver, since_ts=_session_started_ts, stub=stub,
                )
                return self._send_json(200, {"ok": True, "status": snap})
            except Exception as e:
                return self._send_json(400, {"ok": False, "error": str(e)})

        if path == "/apply-new-head":
            try:
                result = retrain_runner.apply_new_head()
                return self._send_json(200, result)
            except Exception as e:
                return self._send_json(400, {"ok": False, "error": str(e)})

        return self._send(404, b"not found", "text/plain")

    def _read_body(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}


def start_server(driver, *, host: str = "127.0.0.1", port: int = 7475) -> ThreadingHTTPServer:
    """Bind the driver onto the handler class and start the server.
    Returns the server so the CLI can shut it down on Ctrl-C."""
    global _session_started_ts
    import time as _time
    _session_started_ts = _time.time()
    ReviewerHandler.driver = driver
    server = ThreadingHTTPServer((host, port), ReviewerHandler)
    return server
