"""Agent-teacher path — dataset generation by a Claude Code agent instead of
API calls.

Split from `dataset_build.py` so both paths coexist cleanly. The agent writes
one scenario-per-file into a staging directory; this module validates each,
runs the F1-delta filter, and finalises train/val/test + manifest.

Advantages over the API-call path:
- Zero incremental API spend for Claude Code subscription users
- Real-time human supervision (watch in chat, intervene, regenerate)
- Agent has MCP + Bash + Write tools; can self-check against existing
  pilot data to avoid name collisions

Workflow:
    orbweaver task-list --out-version v1.1 --per-type 10
        → writes data/v1.1/tasks.jsonl (60 tasks)

    [agent reads tasks.jsonl, composes scenario JSON, writes
     data/v1.1/staging/<custom_id>.json via Write tool — repeat 60x]

    orbweaver ingest-staged --out-version v1.1
        → validates each staged JSON, runs F1 filter, writes
          train.jsonl + val.jsonl + test.jsonl + manifest.json
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Iterator

from .dataset_build import FilteredExample, filter_scenario, write_splits
from .teacher import SCENARIO_TYPES, SYSTEM_PROMPT, THEMES, TrainingScenario


# ---------- task list generation ----------

def generate_tasks(per_type: int) -> list[dict]:
    """Produce the list of (custom_id, scenario_type, theme) triples the
    agent should work through. Identical coverage to `dataset_build.build_plan`
    but without the Anthropic-specific request payload."""
    tasks = []
    for stype in SCENARIO_TYPES:
        for i in range(per_type):
            theme = THEMES[i % len(THEMES)]
            tasks.append({
                "custom_id": f"{stype}_{i:04d}",
                "scenario_type": stype,
                "theme": theme,
            })
    return tasks


def write_task_list(tasks: list[dict], out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / "tasks.jsonl"
    with path.open("w") as f:
        for t in tasks:
            f.write(json.dumps(t, separators=(",", ":")) + "\n")
    return path


def read_task_list(out_dir: Path) -> list[dict]:
    path = out_dir / "tasks.jsonl"
    if not path.exists():
        raise FileNotFoundError(f"task list not found: {path}")
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


# ---------- kickoff prompt ----------

def build_kickoff_prompt(out_version: str, per_type: int) -> str:
    """Self-contained prompt a fresh Claude Code session can follow end-to-end.

    Emits a plain-text prompt that references repo files (README, teacher.py
    SYSTEM_PROMPT, teacher_examples.md) rather than inlining them — keeps the
    prompt compact and lets the agent read the authoritative source.
    """
    return f"""\
You are generating orbweaver training data via Claude Code — NOT via API calls.
Your goal is to produce {per_type * len(SCENARIO_TYPES)} training scenarios for the
{out_version} dataset and have them pass the F1-delta filter.

# First, load context
1. Read README.md — what orbweaver is
2. Read docs/DECISIONS.md — architecture choices, especially D-003 (five-verb
   vocabulary), D-010 (staged pipeline), D-012 (single-DB consolidation)
3. Read orbweaver/teacher.py — SYSTEM_PROMPT defines the scenario schema
4. Read orbweaver/teacher_examples.md — three validated worked examples

# Then, set up
Verify Neo4j Desktop is up:
    lsof -i :7689

Generate the task list (60 tasks for per-type=10):
    orbweaver task-list --out-version {out_version} --per-type {per_type}

This writes data/{out_version}/tasks.jsonl with 60 rows of
(custom_id, scenario_type, theme).

# Then, for EACH task
For each row in tasks.jsonl:

1. Compose a TrainingScenario JSON following SYSTEM_PROMPT's schema
   exactly. CRITICAL:
   - Invent fresh names and ids; DO NOT reuse anything from
     teacher_examples.md (priya_raman, svc_ingest, raman_lab, marsh_lab,
     etc. are off-limits)
   - For no_op scenarios, expected_mutations MUST be []
   - Every id in expected_mutations and qa_pairs MUST exist in the
     graph_snapshot_cypher (or be a new reflection_id)
   - Use POLE+O labels: Person, Org, Place, Event, Object, Message,
     Fact (no Reflection — orbweaver creates those)

2. Write the JSON to data/{out_version}/staging/<custom_id>.json using
   the Write tool.

3. Continue to the next task. Do NOT validate inline — batch validation
   runs once at the end.

# Finally, validate + finalise
After all 60 staged files exist:

    orbweaver ingest-staged --out-version {out_version}

This runs Pydantic validation + F1-delta filter on each, splits 80/10/10,
and writes train/val/test JSONL + manifest.json. Expect 30-50% drop rate.

# Report
Commit + push the manifest and report the result to the user following
docs/ROADMAP.md Phase 3b.1 gate criteria:
- Drop rate < 50% across all scenario types
- Mean F1-delta on kept > +0.03
- No invalid-mutation drops

If gate fails, document findings and propose SYSTEM_PROMPT adjustments.
"""


# ---------- ingestion / validation ----------

def iter_staged(staging_dir: Path) -> Iterator[tuple[str, dict]]:
    """Yield (custom_id, raw_dict) for every .json file in the staging dir.
    `custom_id` is derived from the filename."""
    if not staging_dir.exists():
        return
    for p in sorted(staging_dir.glob("*.json")):
        try:
            raw = json.loads(p.read_text())
            yield p.stem, raw
        except Exception as e:
            yield p.stem, {"_error": f"parse failed: {e}"}


def ingest(out_version: str, *, teacher_model: str = "claude-code-agent") -> dict:
    """Scan `data/<out_version>/staging/`, validate each scenario, F1-filter,
    write train/val/test + manifest. Returns the manifest dict."""
    repo_root = Path(__file__).resolve().parent.parent
    out_dir = repo_root / "data" / out_version
    staging = out_dir / "staging"
    if not staging.exists():
        raise FileNotFoundError(f"staging dir missing: {staging} — run task-list first?")

    prompt_hash = "sha256:" + hashlib.sha256(SYSTEM_PROMPT.encode()).hexdigest()[:16]
    t0 = time.time()

    kept: list[FilteredExample] = []
    drop_parse = drop_invalid = drop_f1 = 0
    seen_ids = set()

    for custom_id, raw in iter_staged(staging):
        if custom_id in seen_ids:
            continue  # duplicate filename
        seen_ids.add(custom_id)

        if "_error" in raw:
            drop_parse += 1
            print(f"[ingest] {custom_id}: {raw['_error']}", flush=True)
            continue

        try:
            scen = TrainingScenario.model_validate(raw)
        except Exception as e:
            drop_invalid += 1
            print(f"[ingest] {custom_id}: schema invalid: {e}", flush=True)
            continue

        fx = filter_scenario(custom_id, scen, teacher_model=teacher_model,
                             prompt_hash=prompt_hash)
        if fx is None:
            drop_f1 += 1
            continue
        kept.append(fx)
        print(f"[ingest] {custom_id}: KEPT  f1_delta={fx.teacher_f1_delta:+.3f}",
              flush=True)

    counts = write_splits(kept, out_dir)
    manifest = {
        "version": out_version,
        "teacher_model": teacher_model,
        "teacher_prompt_hash": prompt_hash,
        "mode": "agent-teacher",
        "staged_seen": len(seen_ids),
        "drop_parse": drop_parse,
        "drop_invalid": drop_invalid,
        "drop_f1_filter": drop_f1,
        "kept_total": len(kept),
        "split_counts": counts,
        "f1_delta_mean": (sum(e.teacher_f1_delta for e in kept) / max(1, len(kept))),
        "wall_clock_s": int(time.time() - t0),
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"\n[ingest] DONE  kept={len(kept)}  splits={counts}  -> {out_dir}",
          flush=True)
    return manifest
