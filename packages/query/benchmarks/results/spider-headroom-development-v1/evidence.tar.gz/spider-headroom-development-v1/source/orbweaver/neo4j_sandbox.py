"""Local Neo4j sandbox. Python controls lifecycle via subprocess and resets
the DB between experiments.

Design: one long-running Neo4j instance on the host machine (installed via
`brew install neo4j`). Each `sandbox()` context manager call wipes the
default database clean at entry and at exit. This means experiments are
SEQUENTIAL, not parallel — Community Edition doesn't support CREATE
DATABASE, so we can't isolate by database. Set
`ORBWEAVER_REQUIRE_ENTERPRISE=1` to use per-experiment databases if you
have Enterprise.

Keep the interface narrow — we may later swap the backend for
`@johnymontana/neo4j-local` without touching callers.
"""
from __future__ import annotations

import os
import secrets
import shutil
import subprocess
import time
from contextlib import contextmanager
from dataclasses import dataclass

from neo4j import GraphDatabase, Driver, Session

from .mutations import Mutation, to_cypher, invert, SCHEMA_MIGRATION_CYPHER


@dataclass(frozen=True)
class SandboxHandle:
    driver: Driver
    database: str
    bolt_uri: str
    username: str
    password: str

    def session(self) -> Session:
        return self.driver.session(database=self.database)


# ---------- lifecycle ----------

def ensure_neo4j_running(*, timeout_s: int = 30) -> None:
    """Make sure a local Neo4j is up. Idempotent.

    We assume `brew install neo4j` gave us the `neo4j` CLI. If it's already
    running, this is a no-op. Otherwise we `neo4j start` and wait for the
    bolt port to open.
    """
    if _bolt_port_open():
        return
    if shutil.which("neo4j") is None:
        raise RuntimeError(
            "neo4j CLI not found. Install with: brew install neo4j && "
            "then enable APOC via the Neo4j config."
        )
    subprocess.run(["neo4j", "start"], check=True)
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        if _bolt_port_open():
            return
        time.sleep(0.5)
    raise RuntimeError(f"neo4j did not come up within {timeout_s}s")


def _bolt_port_open(host: str = "localhost", port: int = 7687) -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.25)
        return s.connect_ex((host, port)) == 0


def _admin_driver() -> Driver:
    """Admin driver against the `system` database. Used to create/drop
    experiment-scoped databases.
    """
    uri = os.getenv("ORBWEAVER_BOLT", "bolt://localhost:7688")
    user = os.getenv("ORBWEAVER_NEO4J_USER", "neo4j")
    pw = os.getenv("ORBWEAVER_NEO4J_PASS", "orbweaver-dev")
    return GraphDatabase.driver(uri, auth=(user, pw))


# ---------- main context manager ----------

@contextmanager
def sandbox(
    *,
    name_prefix: str = "orb",
    migrate: bool = True,
    keep_on_exit: bool = False,
):
    """Yield a handle to a wiped default database. Wipes again at exit
    (unless `keep_on_exit`).

    Uses the default `neo4j` database because Community Edition doesn't
    support per-experiment CREATE DATABASE. This is fine for sequential
    experiments; for parallel you need Enterprise and the
    `_enterprise_sandbox` path below.
    """
    ensure_neo4j_running()

    use_enterprise = os.getenv("ORBWEAVER_REQUIRE_ENTERPRISE") == "1"
    if use_enterprise:
        yield from _enterprise_sandbox(name_prefix, migrate, keep_on_exit)
        return

    uri = os.getenv("ORBWEAVER_BOLT", "bolt://localhost:7688")
    user = os.getenv("ORBWEAVER_NEO4J_USER", "neo4j")
    pw = os.getenv("ORBWEAVER_NEO4J_PASS", "orbweaver-dev")
    driver = GraphDatabase.driver(uri, auth=(user, pw))

    handle = SandboxHandle(driver=driver, database="neo4j", bolt_uri=uri,
                           username=user, password=pw)

    def _wipe():
        with handle.session() as s:
            # Drop all nodes + relationships.
            s.run("MATCH (n) DETACH DELETE n")
            # Drop orbweaver-specific constraints/indexes so migration is idempotent.
            try:
                for name in ("reflection_id", "mutation_ledger_id",
                             "reflection_created_at", "deprecated_nodes"):
                    s.run(f"DROP CONSTRAINT {name} IF EXISTS")
                    s.run(f"DROP INDEX {name} IF EXISTS")
            except Exception:
                pass

    try:
        _wipe()
        if migrate:
            with handle.session() as s:
                for stmt in SCHEMA_MIGRATION_CYPHER:
                    try:
                        s.run(stmt)
                    except Exception:
                        pass
        yield handle
    finally:
        try:
            if not keep_on_exit:
                _wipe()
        finally:
            driver.close()


def _enterprise_sandbox(name_prefix: str, migrate: bool, keep_on_exit: bool):
    """Enterprise-only: per-experiment isolated database. Not tested in the
    Community default path but kept around for later.
    """
    db_name = f"{name_prefix}{secrets.token_hex(4)}"
    admin = _admin_driver()
    try:
        with admin.session(database="system") as s:
            s.run(f"CREATE DATABASE `{db_name}` WAIT")
    except Exception:
        admin.close()
        raise

    uri = os.getenv("ORBWEAVER_BOLT", "bolt://localhost:7688")
    user = os.getenv("ORBWEAVER_NEO4J_USER", "neo4j")
    pw = os.getenv("ORBWEAVER_NEO4J_PASS", "orbweaver-dev")
    driver = GraphDatabase.driver(uri, auth=(user, pw))
    handle = SandboxHandle(driver=driver, database=db_name, bolt_uri=uri,
                           username=user, password=pw)
    try:
        if migrate:
            with handle.session() as s:
                for stmt in SCHEMA_MIGRATION_CYPHER:
                    s.run(stmt)
        yield handle
    finally:
        driver.close()
        try:
            if not keep_on_exit:
                with admin.session(database="system") as s:
                    s.run(f"DROP DATABASE `{db_name}` IF EXISTS WAIT")
        finally:
            admin.close()


# ---------- ops ----------

def load_cypher(handle: SandboxHandle, cypher: str) -> None:
    """Run the entire cypher block as a single query.

    The teacher's output shape is a sequence of CREATE statements separated
    by `;\\n` where later relationship creates refer to variables bound in
    earlier node creates (e.g. `CREATE (p1)-[:EMPLOYED_BY]->(o1)` assumes
    p1 and o1 were bound). Splitting on `;` and running each statement in
    its own tx loses those bindings, and Cypher silently creates anonymous
    duplicate nodes for the relationship endpoints — we measured 48 ghost
    nodes on a 17-real-node scenario before this fix.

    The fix: strip `;` separators and run the whole block as one query.
    Cypher allows chained CREATE/MATCH clauses with variable scope across
    the whole query. For scenarios with separate hand-authored statement
    blocks (benchmarks/small.cypher), splitting on `\\n\\n` or similar
    paragraph boundaries is safer — that file writes each statement
    independently with MATCH prefixes.
    """
    # Detect the teacher format (`;\n` between statements with shared vars)
    # vs the hand-authored format (`;` terminated, each statement standalone
    # with MATCH prefixes). Teacher statements never contain `MATCH`, the
    # small-benchmark ones do.
    if "MATCH" in cypher:
        # Hand-authored style: run each statement in its own tx.
        stmts = [s.strip() for s in cypher.split(";\n") if s.strip()]
        with handle.session() as s:
            for stmt in stmts:
                s.run(stmt)
    else:
        # Teacher style: run the whole block as one query so variable
        # bindings persist.
        single = cypher.replace(";", " ")
        with handle.session() as s:
            s.run(single)


def apply_mutations(
    handle: SandboxHandle,
    muts: list[Mutation],
    *,
    tick_id: str,
    ledger: bool = True,
    dry_run: bool = False,
) -> list[dict]:
    """Apply mutations in a single write transaction. Returns per-mutation
    result summary. If `ledger=True`, also writes a MutationLedgerEntry for
    each mutation with its inverse payload, so `rollback()` can undo.
    """
    results = []
    with handle.session() as s:
        def _work(tx):
            for m in muts:
                inv = invert(m)
                cy, params = to_cypher(m, tick_id=tick_id)
                if not dry_run:
                    tx.run(cy, **params)
                if ledger and not dry_run:
                    tx.run(
                        "CREATE (l:MutationLedgerEntry {id:$id, tick_id:$tid, verb:$verb, "
                        "payload_json:$payload, inverse_json:$inverse, applied_at:datetime()})",
                        id=f"{tick_id}:{len(results)}",
                        tid=tick_id,
                        verb=m.verb,
                        payload=m.model_dump_json(),
                        inverse=inv.model_dump_json(),
                    )
                results.append({"verb": m.verb, "ok": True})
        if dry_run:
            # Transaction auto-rolls-back on exit when we raise; simpler: use
            # a read transaction and call write queries that return nothing.
            with s.begin_transaction() as tx:
                try:
                    _work(tx)
                finally:
                    tx.rollback()
        else:
            s.execute_write(_work)
    return results


def rollback_tick(handle: SandboxHandle, tick_id: str) -> int:
    """Undo all mutations from a tick via the ledger. Returns count inverted."""
    # Read ledger entries, replay their inverses in reverse order.
    with handle.session() as s:
        rows = s.run(
            "MATCH (l:MutationLedgerEntry {tick_id:$tid}) "
            "RETURN l.id AS id, l.inverse_json AS inv ORDER BY l.id DESC",
            tid=tick_id,
        ).data()
    from .mutations import validate_array
    import json
    inverses = [validate_array([json.loads(r["inv"])])[0] for r in rows]
    apply_mutations(handle, inverses, tick_id=f"{tick_id}:rollback", ledger=False)
    return len(inverses)


def node_count(handle: SandboxHandle) -> int:
    with handle.session() as s:
        return s.run("MATCH (n) WHERE coalesce(n.deprecated,false)=false RETURN count(n) AS c").single()["c"]


def relationship_count(handle: SandboxHandle) -> int:
    with handle.session() as s:
        return s.run(
            "MATCH ()-[r]->() WHERE coalesce(r.deprecated,false)=false RETURN count(r) AS c"
        ).single()["c"]
