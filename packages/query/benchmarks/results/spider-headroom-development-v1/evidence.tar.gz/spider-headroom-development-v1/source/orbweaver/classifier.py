"""Classifier-head pivot per second compass artifact §5 path (h+i).

Pivots from autoregressive verb-emission ("[{...}]<|im_end|>") to a 6-way
classification head over the last-token hidden state of the prompt.

  hidden_state(prompt[-1])  →  LayerNorm → Linear → 6 classes

The 6 classes are the 5 orbweaver verbs + 'abstain' (subsumes no_op).

Per the second compass artifact §1, ≤4B autoregressive LoRA fine-tunes
plateau at 10-15% on multi-hop semantic discrimination because format
saturates fast and verb selection does not. Section §6 prescribes
**classifier head + reasoning-distilled backbone + retrieval + abstention**
as the engineering integration of well-proven components for this size
class. This module is the classifier-head leg.

Argument extraction (slot-fill given the chosen verb) is a separate
sub-task; see `slot_extraction.py` (Phase 3c-follow-up).
"""
from __future__ import annotations

import json
from pathlib import Path

import mlx.core as mx
import mlx.nn as nn

from .data import Example, build_chat_messages


# ---------- label space ----------

VERB_LABELS: list[str] = [
    "add_link",
    "add_reflection",
    "merge_entities",
    "adjust_weight",
    "deprecate",
    "abstain",          # subsumes no_op + low-confidence FLAG_FOR_REVIEW
]
LABEL_TO_IDX: dict[str, int] = {v: i for i, v in enumerate(VERB_LABELS)}
IDX_TO_LABEL: dict[int, str] = {i: v for v, i in LABEL_TO_IDX.items()}
N_CLASSES: int = len(VERB_LABELS)


# Map a TrainingScenario.scenario_type (from teacher) to the primary
# verb the model should emit. `no_op` → `abstain`. Bass-translated rows
# carry their scenario_type as `implicit_link` / `stale_deprecation` etc.
SCENARIO_TYPE_TO_VERB: dict[str, str] = {
    "implicit_link": "add_link",
    "duplicate_entity": "merge_entities",
    "cluster_reflection": "add_reflection",
    "weight_reinforcement": "adjust_weight",
    "stale_deprecation": "deprecate",
    "no_op": "abstain",
}


def scenario_to_label_idx(row: dict) -> int:
    """Determine the verb-class label for a TrainingScenario row.

    Priority: (1) scenario_type (in `_meta` if present), (2) parse from
    custom_id stem (e.g. `weight_reinforcement_0001` → `weight_reinforcement`),
    (3) the `verb` of the first expected mutation, (4) fall back to abstain.
    """
    expected = row.get("expected_mutations", []) or []

    # 1) scenario_type from _meta
    meta = row.get("_meta", {})
    stype = meta.get("scenario_type")

    # 2) parse from id
    if stype is None:
        rid = row.get("id", "")
        # bass-translated rows have stem `bass_type_NNNN` / `bass_single_NNNN`
        if rid.startswith("bass_type_"):
            stype = "implicit_link"
        elif rid.startswith("bass_single_"):
            stype = "stale_deprecation"
        else:
            # standard custom_id format: <scenario_type>_<NNNN>
            # adjust_weight has TWO underscores in the stem, so try the longest
            # known stem first.
            for candidate_stem in (
                "weight_reinforcement", "cluster_reflection",
                "stale_deprecation", "implicit_link",
                "duplicate_entity", "no_op",
                # v1.3+ targeted custom_ids
                "adjust_weight", "add_reflection",
            ):
                if rid.startswith(candidate_stem + "_"):
                    # Map the targeted-custom_id verbs back onto the scenario
                    # types they correspond to (so the label space stays clean):
                    if candidate_stem == "adjust_weight":
                        stype = "weight_reinforcement"
                    elif candidate_stem == "add_reflection":
                        stype = "cluster_reflection"
                    else:
                        stype = candidate_stem
                    break

    if stype:
        verb = SCENARIO_TYPE_TO_VERB.get(stype)
        if verb:
            return LABEL_TO_IDX[verb]

    # 3) fall back to the first mutation's verb
    if expected:
        verb = expected[0].get("verb")
        if verb in LABEL_TO_IDX:
            return LABEL_TO_IDX[verb]

    # 4) abstain
    return LABEL_TO_IDX["abstain"]


# ---------- the head ----------

class ClassifierHead(nn.Module):
    """LayerNorm → Dropout → Linear projection to N_CLASSES.

    Operates on the last-token hidden state (shape [B, hidden_size]).
    """
    def __init__(self, hidden_size: int, n_classes: int = N_CLASSES,
                 dropout: float = 0.1):
        super().__init__()
        self.norm = nn.LayerNorm(hidden_size)
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_size, n_classes)

    def __call__(self, last_hidden: mx.array) -> mx.array:
        # last_hidden: [B, hidden_size] → logits [B, n_classes]
        x = self.norm(last_hidden)
        x = self.dropout(x)
        return self.classifier(x)


# ---------- dataset preparation ----------

def build_classifier_examples(
    jsonl_path: str | Path, tokenizer, *, max_len: int = 4096,
    return_weights: bool = False,
):
    """Yield (prompt_input_ids, label_idx) for every row in a JSONL.

    Uses the same prompt prefix as inference: system + user, then
    `add_generation_prompt=True` so the prompt ends at
    `<|im_start|>assistant\\n` and the *last token* is the natural
    classification slot.

    Long prompts are LEFT-truncated (preserving the tail) which keeps
    `<|im_start|>assistant\\n` intact — that's what the head reads from.

    When `return_weights=True`, yields (ids, label_idx, weight) — `weight`
    comes from `row['_meta']['weight']` (default 1.0). This is the ECHO-
    inspired per-row weighting hook: probe-derived weak labels arrive at
    weight < 1.0 so they augment the (:Edit)-derived signal without
    drowning it. Default False preserves the v1.1 (ids, label) shape for
    existing callers.
    """
    rows = []
    for line in Path(jsonl_path).read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))

    samples: list = []
    for row in rows:
        label_idx = scenario_to_label_idx(row)
        ex = Example(
            id=row["id"],
            graph_snapshot_cypher=row["graph_snapshot_cypher"],
            events=row.get("events_since_last_tick", []),
            expected_mutations=[],
        )
        msgs = build_chat_messages(ex)[:-1]    # drop assistant placeholder
        ids: list[int] = tokenizer.apply_chat_template(
            msgs, add_generation_prompt=True, tokenize=True,
        )
        if len(ids) > max_len:
            ids = ids[-max_len:]
        if return_weights:
            weight = float(row.get("_meta", {}).get("weight", 1.0))
            samples.append((ids, label_idx, weight))
        else:
            samples.append((ids, label_idx))
    return samples


# ---------- forward helper (frozen-base mode) ----------

def encode_prompt(base_model, input_ids: mx.array) -> mx.array:
    """Run base.model(input_ids) → hidden states, return the LAST token's
    hidden vector [B, hidden_size]. Compatible with mlx-lm Qwen3 layout
    where `base_model.model` returns [B, T, hidden]."""
    hidden = base_model.model(input_ids)
    return hidden[:, -1, :]


# ---------- save/load ----------

def save_head(head: ClassifierHead, path: str | Path) -> None:
    from mlx.utils import tree_flatten
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    flat = dict(tree_flatten(head.parameters()))
    mx.save_safetensors(str(p), flat)


def load_head(hidden_size: int, n_classes: int, path: str | Path) -> ClassifierHead:
    from mlx.utils import tree_unflatten
    head = ClassifierHead(hidden_size, n_classes)
    weights = mx.load(str(path))
    head.update(tree_unflatten(list(weights.items())))
    mx.eval(head.parameters())
    return head
