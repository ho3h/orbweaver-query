"""Retrieval-augmented inference per second compass artifact §5 path (g).

> "Retrieve the top-k canonical-edit exemplars from the customer's prior
>  corrections (HippoRAG-2 over phrase nodes; LightRAG for incremental
>  updates; ~80ms query latency). Model conditions on retrieved exemplars
>  and either copies the verb or transforms. RoG ablations show retrieval
>  is worth +25pp on multi-hop graph tasks at 7B."

For the MVP we use TF-IDF over the (graph_snapshot_cypher + events) text
because (a) sklearn is already a project dep, (b) ~5ms cosine similarity
on a 354-row index, (c) zero new model dependencies, (d) the compass
explicitly notes retrieval design choice has limited sensitivity at this
scale (the LIFT comes from conditioning on past exemplars at all,
not from any specific embedding choice).

The richer alternative — embedding via the base model's hidden states —
slots in via the `Embedder` protocol; just implement `__call__(text) ->
np.ndarray` and pass it to `RetrievalIndex(embedder=...)`.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Protocol


class Embedder(Protocol):
    def __call__(self, text: str): ...


class RetrievalIndex:
    """In-memory TF-IDF index over training scenarios for k-NN exemplar lookup.

    At fit time, indexes the (graph_snapshot_cypher + events_text + theme)
    corpus. At query time, `top_k(query)` returns the indices of the top-k
    most-similar training scenarios.
    """

    def __init__(self, *, embedder: Embedder | None = None):
        self.embedder = embedder
        self._rows: list[dict] = []
        self._matrix = None
        self._vectorizer = None

    @staticmethod
    def _row_text(row: dict) -> str:
        """Project a TrainingScenario row to a single retrieval-text blob."""
        events = row.get("events_since_last_tick", []) or []
        events_txt = " ".join(
            (e.get("text", "") + " " + " ".join(e.get("entity_ids", []) or []))
            for e in events
        )
        theme = row.get("_meta", {}).get("theme", "")
        if not theme and "theme" in row:
            theme = row["theme"]
        return (
            f"{theme}\n"
            f"{row.get('graph_snapshot_cypher', '')}\n"
            f"{events_txt}"
        )

    def fit(self, jsonl_paths: Iterable[str | Path]) -> "RetrievalIndex":
        """Build the index over a list of training JSONL files."""
        from sklearn.feature_extraction.text import TfidfVectorizer

        rows: list[dict] = []
        for path in jsonl_paths:
            for line in Path(path).read_text().splitlines():
                if line.strip():
                    rows.append(json.loads(line))
        self._rows = rows

        texts = [self._row_text(r) for r in rows]
        if self.embedder is None:
            # TF-IDF default: 1-2 grams on word tokens, lowercase, strip cypher syntax noise
            self._vectorizer = TfidfVectorizer(
                ngram_range=(1, 2),
                min_df=2,
                max_df=0.95,
                token_pattern=r"[a-zA-Z_][a-zA-Z0-9_]+",
                lowercase=True,
                sublinear_tf=True,
                max_features=20000,
            )
            self._matrix = self._vectorizer.fit_transform(texts)
        else:
            import numpy as np
            self._matrix = np.array([self.embedder(t) for t in texts])
        return self

    def top_k(self, query_row: dict, k: int = 3,
              *, exclude_self: bool = True) -> list[tuple[int, float]]:
        """Return [(row_idx, similarity)] for the top-k matches."""
        if self._matrix is None:
            raise RuntimeError("RetrievalIndex.fit() must be called first")

        query_text = self._row_text(query_row)
        if self._vectorizer is not None:
            from sklearn.metrics.pairwise import cosine_similarity
            qv = self._vectorizer.transform([query_text])
            sims = cosine_similarity(qv, self._matrix).ravel()
        else:
            import numpy as np
            qv = self.embedder(query_text)
            sims = (self._matrix @ qv) / (
                np.linalg.norm(self._matrix, axis=1) * np.linalg.norm(qv) + 1e-9
            )

        # argsort descending; optionally drop the self-match (sim=1.0)
        order = sims.argsort()[::-1]
        results: list[tuple[int, float]] = []
        for idx in order:
            sim = float(sims[idx])
            if exclude_self and sim > 0.999:
                continue
            results.append((int(idx), sim))
            if len(results) >= k:
                break
        return results

    def get_row(self, idx: int) -> dict:
        return self._rows[idx]


# ---------- prompt augmentation ----------

def augment_prompt_with_exemplars(
    user_prompt: str, exemplars: list[dict], *, max_chars: int = 6000,
) -> str:
    """Prepend retrieved-exemplar context to the user prompt.

    Each exemplar contributes (theme, scenario_type, expected_mutations).
    Truncate from the bottom if the combined block would exceed
    `max_chars`. Prepends a clear separator so the model can see what's
    exemplar vs. what's the live query.
    """
    blocks: list[str] = []
    blocks.append("## Past similar corrections (for reference)\n")
    used = sum(len(b) for b in blocks)
    for i, ex in enumerate(exemplars):
        meta = ex.get("_meta", {})
        stype = meta.get("scenario_type") or "?"
        muts = ex.get("expected_mutations", [])
        muts_compact = json.dumps(muts, separators=(",", ":"))[:600]
        block = (
            f"\n### Exemplar {i+1} ({stype})\n"
            f"Mutations: {muts_compact}\n"
        )
        if used + len(block) > max_chars:
            break
        blocks.append(block)
        used += len(block)
    blocks.append("\n## Live query\n")
    blocks.append(user_prompt)
    return "".join(blocks)
