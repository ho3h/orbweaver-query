"""Blocking — generate candidate pairs from a Neo4j graph for the spider
to classify. Two cheap heuristics for v1.0:

  SharedOneHopBlocker — pairs that share ≥1 1-hop neighbor. Catches both
                        duplicate candidates (two "Alice Smith" nodes both
                        linked to Acme Corp) and link-suggestion candidates
                        (two engineers both attending the same all-hands).

  TokenOverlapBlocker — pairs whose name strings share ≥N normalized tokens.
                        Catches duplicates with shared phrasing ("Alice
                        Smith" vs "Alice M Smith") and entity references
                        across different node types ("Project Atlas" the
                        Org and "Atlas project" the Event).

Each blocker yields CandidatePair(left_id, right_id, blocker, signals).
The signals dict carries the *evidence the blocker saw* — that's what the
reviewer UI renders as plain-English bullets, no Bayes-factor math.

Recall is the goal here, not precision. The classifier filters for us.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterator


_WORD = re.compile(r"[a-zA-Z][a-zA-Z0-9]+")


def _tokens(s: str | None) -> set[str]:
    if not s:
        return set()
    return {t.lower() for t in _WORD.findall(s) if len(t) > 2}


@dataclass(frozen=True)
class CandidatePair:
    left_id: str
    right_id: str
    blocker: str
    signals: dict = field(default_factory=dict)

    def normalized_pair(self) -> tuple[str, str]:
        """Stable ordering so (a,b) and (b,a) dedupe correctly."""
        return (self.left_id, self.right_id) if self.left_id < self.right_id \
            else (self.right_id, self.left_id)


# ---------- blockers ----------


def shared_one_hop(driver_or_session, *, limit: int = 200,
                   exclude_labels: tuple[str, ...] = ("Edit", "Reflection")
                   ) -> Iterator[CandidatePair]:
    """Yield pairs that share ≥1 1-hop neighbor. Excludes ledger/audit
    nodes by default (we don't reconcile our own bookkeeping). Skips
    pairs where the canonical edge already exists.
    """
    sess = _coerce_session(driver_or_session)
    excl = " AND ".join(f"NOT n:{lbl}" for lbl in exclude_labels) or "true"
    q = (
        f"MATCH (a)-[]-(n)-[]-(b) "
        f"WHERE a.id < b.id AND a.id IS NOT NULL AND b.id IS NOT NULL "
        f"  AND {excl} "
        f"  AND coalesce(n.deprecated, false) = false "
        f"  AND NOT (a)-[:SAME_AS|SUGGESTED_SAME_AS]-(b) "
        f"WITH a, b, collect(distinct n.id) AS shared "
        f"WHERE size(shared) >= 1 "
        f"RETURN a.id AS left_id, b.id AS right_id, "
        f"       shared[..5] AS shared_ids "
        f"ORDER BY size(shared) DESC "
        f"LIMIT $limit"
    )
    with sess as s:
        for row in s.run(q, limit=int(limit)):
            yield CandidatePair(
                left_id=row["left_id"],
                right_id=row["right_id"],
                blocker="shared_one_hop",
                signals={
                    "shared_neighbors": list(row["shared_ids"]),
                    "shared_count": len(row["shared_ids"]),
                },
            )


def token_overlap(driver_or_session, *, limit: int = 200,
                  min_overlap: int = 2,
                  name_props: tuple[str, ...] = ("name", "title", "summary")
                  ) -> Iterator[CandidatePair]:
    """Yield pairs whose name strings share ≥`min_overlap` normalized
    tokens. Cheap pre-filter via Cypher (substring of one shared token),
    exact overlap computed in Python. Excludes pairs where canonical
    SAME_AS already exists.
    """
    sess = _coerce_session(driver_or_session)
    seen: set[tuple[str, str]] = set()

    # Pull a window of candidate name strings; tokenization happens in Python.
    name_expr = " + ' ' + ".join(f"coalesce(n.{p}, '')" for p in name_props)
    q = (
        f"MATCH (n) "
        f"WHERE n.id IS NOT NULL AND coalesce(n.deprecated,false)=false "
        f"  AND NOT n:Edit "
        f"RETURN n.id AS id, ({name_expr}) AS text"
    )
    with sess as s:
        rows = [(r["id"], r["text"] or "") for r in s.run(q)]

    by_token: dict[str, set[str]] = {}
    for nid, text in rows:
        for t in _tokens(text):
            # Dedupe: multiple nodes can share the same id property
            # across scenarios (load_pilot doesn't namespace), and a
            # self-pair (a==b) is meaningless.
            by_token.setdefault(t, set()).add(nid)

    pair_overlap: dict[tuple[str, str], set[str]] = {}
    for tok, ids_set in by_token.items():
        if len(ids_set) > 50:  # extremely common tokens are noise
            continue
        ids_list = sorted(ids_set)
        for i in range(len(ids_list)):
            for j in range(i + 1, len(ids_list)):
                a, b = ids_list[i], ids_list[j]
                if a == b:
                    continue
                pair_overlap.setdefault((a, b), set()).add(tok)

    out = sorted(
        ((p, toks) for p, toks in pair_overlap.items() if len(toks) >= min_overlap),
        key=lambda kv: -len(kv[1]),
    )[:limit]
    for (a, b), toks in out:
        if (a, b) in seen:
            continue
        seen.add((a, b))
        yield CandidatePair(
            left_id=a, right_id=b, blocker="token_overlap",
            signals={"shared_tokens": sorted(toks)[:8],
                     "overlap_count": len(toks)},
        )


def all_blockers(driver_or_session, *, limit_per_blocker: int = 100
                 ) -> Iterator[CandidatePair]:
    """Run all v1.0 blockers in sequence, dedupe by normalized pair. When
    multiple blockers fire on the same pair, signals are merged and the
    blocker field becomes a +-joined list ("shared_one_hop+token_overlap")."""
    seen: dict[tuple[str, str], CandidatePair] = {}
    for fn in (shared_one_hop, token_overlap):
        for cp in fn(driver_or_session, limit=limit_per_blocker):
            if cp.left_id == cp.right_id:
                continue
            key = cp.normalized_pair()
            if key in seen:
                prior = seen[key]
                prior_blockers = prior.signals.get("blockers", [prior.blocker])
                merged_signals = dict(prior.signals)
                merged_signals.update(cp.signals)
                merged_signals["blockers"] = prior_blockers + [cp.blocker]
                seen[key] = CandidatePair(
                    left_id=key[0], right_id=key[1],
                    blocker=f"{prior.blocker}+{cp.blocker}",
                    signals=merged_signals,
                )
            else:
                # Always carry the blocker name in signals so the reviewer
                # UI doesn't have to read it from the dataclass field.
                signals = dict(cp.signals)
                signals.setdefault("blocker_name", cp.blocker)
                seen[key] = CandidatePair(
                    left_id=cp.left_id, right_id=cp.right_id,
                    blocker=cp.blocker, signals=signals,
                )
    yield from seen.values()


# ---------- helpers ----------


def _coerce_session(x):
    if hasattr(x, "session"):
        return x.session()
    return x
