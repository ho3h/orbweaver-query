"""Abstention wrapper per second compass artifact §2.

> "FLAG_FOR_REVIEW is the default verb on uncertainty. Asymmetric harm:
>  a missed correction is recoverable; a wrong RETRACT or MERGE on
>  canonical data may not be."
>
> "Per-verb conformal thresholds, not a global one. RETRACT/MERGE/SPLIT
>  each carry strictly higher harm than ASSERT/ADD_LINK; treat them with
>  stricter λ_high. Recompute thresholds weekly via split conformal on a
>  rolling 2K-example calibration set."

This module implements:

1. **Conformal calibration** — split-conformal threshold per verb so that
   an emitted (non-abstain) prediction carries a guaranteed coverage
   level (e.g. 90% by default).
2. **Per-verb harm weighting** — RETRACT/MERGE/SPLIT (= deprecate /
   merge_entities) get stricter thresholds; ASSERT/ADD_LINK (= add_link
   / add_reflection / adjust_weight) looser ones.
3. **Three-signal confidence stack** — primary token-logprob (here:
   classifier-head softmax), placeholder for Semantic Entropy Probe
   (Kossen et al. 2024), placeholder for verbalised-confidence.
4. **Diff-budget caps** — utility for downstream daemon callers.

The classifier-head pivot makes (1) and (3-primary) trivial: softmax
probabilities ARE calibrated when the head is class-weighted-trained.
This module wraps that.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


# Compass §2: harm levels per verb. Higher = stricter threshold.
# Maps to the recommendation: "RETRACT/MERGE/SPLIT each carry strictly
# higher harm than ASSERT/ADD_LINK."
DEFAULT_HARM_LEVEL: dict[str, float] = {
    "add_link":         1.0,
    "add_reflection":   1.0,
    "adjust_weight":    1.0,
    "deprecate":        2.0,    # destructive — needs higher confidence
    "merge_entities":   2.5,    # most destructive — strictest
    "abstain":          0.0,    # no harm
}


@dataclass
class AbstentionConfig:
    """Knobs for the abstention wrapper.

    `target_coverage`: fraction of events for which the wrapper should
        emit a confident prediction. The remainder are abstained.
    `harm_levels`: per-verb scaling on the abstention threshold. Higher
        harm → stricter threshold → fewer auto-applies → more abstains.
    `min_confidence_floor`: hard floor below which we abstain regardless
        of conformal calibration (defends against pathological calibration
        sets).
    """
    target_coverage: float = 0.5
    harm_levels: dict[str, float] = field(
        default_factory=lambda: dict(DEFAULT_HARM_LEVEL)
    )
    min_confidence_floor: float = 0.4


@dataclass
class AbstentionThresholds:
    """Per-verb minimum probability required to NOT abstain."""
    by_verb: dict[str, float] = field(default_factory=dict)

    def threshold_for(self, verb: str, default: float = 0.5) -> float:
        return self.by_verb.get(verb, default)

    def to_json(self) -> str:
        return json.dumps(self.by_verb, indent=2)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json())

    @classmethod
    def load(cls, path: str | Path) -> "AbstentionThresholds":
        data = json.loads(Path(path).read_text())
        return cls(by_verb=data)


def calibrate_thresholds(
    val_softmax_by_verb: dict[str, list[float]],
    config: AbstentionConfig | None = None,
) -> AbstentionThresholds:
    """Split-conformal calibration: for each verb, find the threshold τ
    such that the (1 - target_coverage) lowest-confidence predictions of
    that verb on the calibration set fall below τ.

    `val_softmax_by_verb[verb]` is a list of softmax-probs assigned to
    `verb` on the calibration set examples whose TRUE label is `verb`
    (i.e. correct predictions' confidence). We want τ such that under
    that distribution, P(softmax >= τ) >= target_coverage.

    Per-verb harm levels scale the implied target: high-harm verbs
    require higher confidence to clear the bar. Concretely:
        effective_coverage = max(0, 1 - (1 - target_coverage) / harm_level)
    so a 2× harmful verb requires the threshold to leave only half as
    many examples above it.
    """
    cfg = config or AbstentionConfig()
    by_verb: dict[str, float] = {}
    for verb, scores in val_softmax_by_verb.items():
        if not scores:
            by_verb[verb] = max(cfg.min_confidence_floor, 0.5)
            continue
        harm = cfg.harm_levels.get(verb, 1.0)
        # Effective coverage: lower for higher-harm verbs
        slack = max(0.0, 1.0 - cfg.target_coverage)
        eff_slack = min(slack / max(harm, 0.1), 0.95)
        eff_coverage = 1.0 - eff_slack
        # Threshold: q-th quantile where q = (1 - eff_coverage)
        scores_sorted = sorted(scores)
        q_idx = int((1 - eff_coverage) * len(scores_sorted))
        q_idx = max(0, min(q_idx, len(scores_sorted) - 1))
        tau = scores_sorted[q_idx]
        by_verb[verb] = max(cfg.min_confidence_floor, float(tau))
    return AbstentionThresholds(by_verb=by_verb)


@dataclass
class AbstentionDecision:
    predicted_verb: str        # the model's argmax verb
    final_verb: str            # what we actually return (predicted or "abstain")
    confidence: float          # softmax prob of predicted_verb
    threshold: float           # the applicable per-verb threshold
    abstained: bool


def decide(
    softmax_probs: dict[str, float],
    thresholds: AbstentionThresholds,
    *, abstain_label: str = "abstain",
    config: AbstentionConfig | None = None,
) -> AbstentionDecision:
    """Apply the abstention rule to a single classifier output.

    softmax_probs: {verb: probability} from a calibrated classifier head.
    thresholds: per-verb minimum confidence required to NOT abstain.
    """
    cfg = config or AbstentionConfig()
    # Rank verbs by probability (excluding abstain — we don't
    # "abstain because abstain was top"; we WANT to abstain when no
    # action verb clears its threshold).
    action_probs = {v: p for v, p in softmax_probs.items() if v != abstain_label}
    if not action_probs:
        return AbstentionDecision(
            predicted_verb=abstain_label, final_verb=abstain_label,
            confidence=softmax_probs.get(abstain_label, 0.0),
            threshold=0.0, abstained=True,
        )
    top_verb = max(action_probs, key=action_probs.get)
    top_p = action_probs[top_verb]
    tau = thresholds.threshold_for(top_verb, default=cfg.min_confidence_floor)
    if top_p < tau or top_p < cfg.min_confidence_floor:
        return AbstentionDecision(
            predicted_verb=top_verb, final_verb=abstain_label,
            confidence=top_p, threshold=tau, abstained=True,
        )
    return AbstentionDecision(
        predicted_verb=top_verb, final_verb=top_verb,
        confidence=top_p, threshold=tau, abstained=False,
    )


# ---------- diff-budget caps (compass §2) ----------

@dataclass
class DiffBudgetState:
    edits_this_hour: int = 0
    edits_per_node_today: dict[str, int] = field(default_factory=dict)
    edits_per_subgraph_today: dict[str, int] = field(default_factory=dict)


@dataclass
class DiffBudgetConfig:
    edits_per_hour_max: int = 200
    edits_per_node_per_day_max: int = 5
    edits_per_subgraph_per_day_max: int = 20


def budget_check(
    state: DiffBudgetState, target_node: str, subgraph_id: str,
    config: DiffBudgetConfig | None = None,
) -> tuple[bool, str]:
    """Returns (allowed, reason). Reason is empty when allowed=True."""
    cfg = config or DiffBudgetConfig()
    if state.edits_this_hour >= cfg.edits_per_hour_max:
        return False, f"edits/hour {state.edits_this_hour} ≥ cap {cfg.edits_per_hour_max}"
    if state.edits_per_node_today.get(target_node, 0) >= cfg.edits_per_node_per_day_max:
        return False, f"edits/node/day for {target_node} ≥ cap"
    if state.edits_per_subgraph_today.get(subgraph_id, 0) >= cfg.edits_per_subgraph_per_day_max:
        return False, f"edits/subgraph/day for {subgraph_id} ≥ cap"
    return True, ""


def record_edit(state: DiffBudgetState, target_node: str, subgraph_id: str) -> None:
    state.edits_this_hour += 1
    state.edits_per_node_today[target_node] = state.edits_per_node_today.get(target_node, 0) + 1
    state.edits_per_subgraph_today[subgraph_id] = state.edits_per_subgraph_today.get(subgraph_id, 0) + 1
